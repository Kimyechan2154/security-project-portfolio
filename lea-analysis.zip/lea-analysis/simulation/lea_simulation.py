"""LEA first addition, low byte only; adapted statistics from PEPSI AES code.
Synthetic single-point leakage, not a hardware trace experiment.
Run: python lea_simulation.py
"""
import json
from pathlib import Path
import numpy as np

rng = np.random.default_rng(20260926)
hw = np.array([i.bit_count() for i in range(256)], dtype=np.float64)
ns = [100, 500, 1000, 3000]
repeats = 20
results = {n: [0, 0] for n in ns}
for trial in range(repeats):
    a, b = map(int, rng.integers(0, 256, 2))
    p, q = rng.integers(0, 256, (2, max(ns)), dtype=np.uint16)
    z = ((p ^ a) + (q ^ b)) & 255
    leakage = hw[z] + rng.normal(0, 2, max(ns))
    scores = {n: np.zeros((2, 65536)) for n in ns}
    for start in range(0, 65536, 1024):
        keys = np.arange(start, start + 1024, dtype=np.uint32)
        v = ((p[None, :] ^ (keys >> 8)[:, None]) +
             (q[None, :] ^ (keys & 255)[:, None])) & 255
        models = [((v >> 7) & 1).astype(float), hw[v]]
        for n in ns:
            y = leakage[:n]
            yc = y - y.mean()
            s = models[0][:, :n]
            count = s.sum(axis=1)
            dot = np.einsum('ij,j->i', s, y)
            scores[n][0, start:start+1024] = np.abs(dot / count - (y.sum()-dot)/(n-count))
            h = models[1][:, :n]
            hc = h - h.mean(axis=1, keepdims=True)
            scores[n][1, start:start+1024] = np.abs(np.einsum('ij,j->i', hc, yc) / np.sqrt((hc*hc).sum(axis=1) * (yc*yc).sum()))
    for n in ns:
        dpa_class = [(aa << 8) | bb for aa in [a, a^128] for bb in [b, b^128]]
        cpa_class = [(a << 8)|b, ((a^128)<<8)|(b^128)]
        for m, cls in enumerate([dpa_class, cpa_class]):
            results[n][m] += int(np.max(scores[n][m, cls]) >= scores[n][m].max()-1e-10)
    print('trial', trial+1, flush=True)
out = {'seed':20260926, 'repeats':repeats, 'sigma':2,
       'metric':'true equivalence class reaches maximum score; NOT unique key recovery',
       'dpa_class_size':4, 'cpa_class_size':2, 'counts':results}
Path(__file__).with_name('lea_results.json').write_text(json.dumps(out, indent=2))
print(json.dumps(out, indent=2))
