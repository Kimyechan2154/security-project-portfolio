"""Run in the folder containing LEA_1000tr_2361pt.h5."""
import h5py
import numpy as np

with h5py.File("LEA_1000tr_2361pt.h5", "r") as f:
    plaintext = f["textin"][:]
    waves = f["waves"][:]

if plaintext.shape != (1000, 16) or waves.shape != (1000, 2361):
    raise ValueError(f"Unexpected shapes: {plaintext.shape}, {waves.shape}")

plaintext.astype(np.uint8).tofile("lea_plain.bin")
waves.astype("<f4").tofile("lea_waves.bin")
print("Saved lea_plain.bin and lea_waves.bin (1000 traces, 2361 points).")
print("The keys dataset was not read.")
