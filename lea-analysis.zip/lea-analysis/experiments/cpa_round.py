"""Candidate round-key recovery using shared-word hypotheses and addition CPA.
No keys dataset is read. Per-byte greedy search is provisional until validation.
"""
import itertools
import json
import time
import h5py
import numpy as np

with h5py.File('LEA_1000tr_2361pt.h5', 'r') as f:
    p = f['textin'][:].astype(np.uint16)
    w = f['waves'][:].astype(np.float64)

hw = np.array([x.bit_count() for x in range(256)], dtype=np.float64)
wc = w - w.mean(axis=0)
wn = np.sqrt(np.sum(wc * wc, axis=0))
W = np.divide(wc, wn, out=np.zeros_like(wc), where=wn > 0)
guesses = np.arange(256, dtype=np.uint16)

# Common XOR-CPA classes across RK1, RK3, RK5; include both complements.
shared_options = [(0x06, 0xF9), (0x0E, 0xF1), (0x6B, 0x94),
                  (0x74, 0x8B, 0x75, 0x8A)]
# Wide provisional windows include addition and subsequent rotated-value use.
branches = [(0, 4, 220, 780), (4, 8, 1010, 1590), (8, 12, 1795, 2361)]

def recover_word(shared, left, right, start, end):
    carry = np.zeros(len(p), dtype=np.uint16)
    recovered, details = [], []
    for byte in range(4):
        # Unknown left key byte; the right key word is a shared-word hypothesis.
        sums = ((p[:, left + byte][None, :] ^ guesses[:, None])
                + (p[:, right + byte][None, :] ^ shared[byte])
                + carry[None, :])
        h = hw[sums & 255]
        h -= h.mean(axis=1, keepdims=True)
        hn = np.sqrt(np.sum(h * h, axis=1, keepdims=True))
        H = np.divide(h, hn, out=np.zeros_like(h), where=hn > 0)
        corr = H @ W[:, start:end]
        scores = np.max(np.abs(corr), axis=1)
        best = int(np.argmax(scores))
        point = int(np.argmax(np.abs(corr[best])))
        recovered.append(best)
        details.append(dict(byte=byte, key=best, abs_r=float(scores[best]),
                            sample=start + point,
                            signed_r=float(corr[best, point])))
        # Carry into the next byte is trace-dependent, not a single constant.
        carry = (sums[best] >> 8).astype(np.uint16)
    return recovered, details

def hexbytes(values):
    return ' '.join(f'{x:02X}' for x in values)

begin = time.perf_counter()
results = []
shared_guesses = list(itertools.product(*shared_options))
for number, shared in enumerate(shared_guesses, 1):
    words, evidence = [], []
    for left, right, start, end in branches:
        word, details = recover_word(shared, left, right, start, end)
        words.append(word)
        evidence.append(details)
    correlations = [d['abs_r'] for branch in evidence for d in branch]
    results.append(dict(shared=list(shared), rk0=words[0], rk2=words[1],
                        rk4=words[2], score=float(sum(correlations)),
                        minimum_correlation=float(min(correlations)), evidence=evidence))
    print(f'{number}/{len(shared_guesses)} shared={hexbytes(shared)} '
          f'sum |r|={sum(correlations):.6f}', flush=True)

results.sort(key=lambda x: x['score'], reverse=True)
with open('round_candidates.json', 'w', encoding='utf-8') as f:
    json.dump(results, f, indent=2)

best = results[0]
round_key = [best['rk0'], best['shared'], best['rk2'],
             best['shared'], best['rk4'], best['shared']]
with open('round_result.txt', 'w', encoding='utf-8') as f:
    def emit(line):
        print(line)
        f.write(line + '\n')
    emit('\nTop 5 shared-word hypotheses (little-endian bytes)')
    for candidate in results[:5]:
        emit(f"shared={hexbytes(candidate['shared'])}; sum |r|={candidate['score']:.6f}; "
             f"minimum |r|={candidate['minimum_correlation']:.6f}")
    emit('\nBest provisional round-key candidate (little-endian byte order)')
    for i, word in enumerate(round_key):
        emit(f'RK{i}: {hexbytes(word)}')
    emit('\nEvidence by addition branch and byte')
    for branch, details in enumerate(best['evidence']):
        for d in details:
            emit(f"branch={branch}, byte={d['byte']}, key={d['key']:02X}, "
                 f"|r|={d['abs_r']:.6f}, sample={d['sample']}")
    emit('\nNot yet verified. Greedy byte choices and shared candidate pruning can miss the key.')
    emit(f'Elapsed seconds: {time.perf_counter() - begin:.2f}')
print('Saved round_candidates.json and round_result.txt')
