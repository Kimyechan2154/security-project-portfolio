import h5py
import numpy as np
import matplotlib.pyplot as plt

with h5py.File('LEA_1000tr_2361pt.h5', 'r') as f:
    p = f['textin'][:]
    waves = f['waves'][:].astype(np.float64)

hw = np.array([x.bit_count() for x in range(256)], dtype=np.float64)
wc = waves - waves.mean(axis=0)
norm = np.sqrt(np.sum(wc * wc, axis=0))
W = np.divide(wc, norm, out=np.zeros_like(wc), where=norm > 0)
records = []
fig, axes = plt.subplots(4, 1, figsize=(12, 10), sharex=True)

# Only 128 representatives: HW(p XOR (k XOR FF)) = 8 - HW(p XOR k).
# Complementary keys have opposite signed correlations, equal magnitudes.
guesses = np.arange(128, dtype=np.uint8)
for byte in range(16):
    h = hw[p[:, byte][None, :] ^ guesses[:, None]]
    h -= h.mean(axis=1, keepdims=True)
    hn = np.sqrt(np.sum(h * h, axis=1, keepdims=True))
    H = np.divide(h, hn, out=np.zeros_like(h), where=hn > 0)
    corr = H @ W
    score = np.max(np.abs(corr), axis=1)
    order = np.argsort(-score)[:6]
    print(f'\nPlaintext byte {byte} (word X{byte // 4}, byte {byte % 4})')
    for rank, k in enumerate(order, 1):
        point = int(np.argmax(np.abs(corr[k])))
        signed = float(corr[k, point])
        print(f'{rank}: {k:02X}/{k ^ 255:02X}, |r|={score[k]:.6f}, '
              f'sample={point}, signed_r={signed:.6f}')
        records.append((byte, rank, int(k), int(k ^ 255), float(score[k]), point, signed))
    best = int(order[0])
    axes[byte // 4].plot(corr[best], linewidth=0.7,
                         label=f'p[{byte}]: {best:02X}/{best ^ 255:02X}')

np.savetxt('xor_candidates.csv', np.array(records), delimiter=',',
           header='plaintext_byte,rank,key,complement,abs_r,sample,signed_r',
           comments='', fmt=['%d', '%d', '%d', '%d', '%.10f', '%d', '%.10f'])
for word, ax in enumerate(axes):
    ax.set_title(f'X{word} XOR HW-CPA candidate curves')
    ax.set_ylabel('Correlation')
    ax.legend(fontsize=8)
axes[-1].set_xlabel('Sample index')
fig.tight_layout()
fig.savefig('xor_cpa_result.png', dpi=150)
print('\nSaved xor_candidates.csv and xor_cpa_result.png.')
print('Candidates require operation-window identification and further verification.')
plt.show()
