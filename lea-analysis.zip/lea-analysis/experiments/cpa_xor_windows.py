import h5py
import numpy as np

with h5py.File('LEA_1000tr_2361pt.h5', 'r') as f:
    p = f['textin'][:]
    waves = f['waves'][:].astype(np.float64)

hw = np.array([x.bit_count() for x in range(256)], dtype=np.float64)
wc = waves - waves.mean(axis=0)
wn = np.sqrt(np.sum(wc * wc, axis=0))
W = np.divide(wc, wn, out=np.zeros_like(wc), where=wn > 0)
guesses = np.arange(128, dtype=np.uint8)

# Exploratory windows inferred from the observed peaks and xor32 call order.
# Bounds are hypotheses, not confirmed instruction boundaries.
operations = [
    ('RK0', 0, 0, 125),
    ('RK1', 4, 125, 220),
    ('RK2', 4, 800, 910),
    ('RK3', 8, 910, 1010),
    ('RK4', 8, 1590, 1695),
    ('RK5', 12, 1695, 1795),
]
rows = []
with open('xor_windows_result.txt', 'w', encoding='utf-8') as out:
    def emit(line):
        print(line)
        out.write(line + '\n')
    emit('Exploratory XOR CPA candidates; these are not recovered round keys.')
    for name, offset, start, end in operations:
        emit(f'\n{name}: samples [{start}, {end})')
        for byte in range(4):
            h = hw[p[:, offset + byte][None, :] ^ guesses[:, None]]
            h -= h.mean(axis=1, keepdims=True)
            hn = np.sqrt(np.sum(h * h, axis=1, keepdims=True))
            H = np.divide(h, hn, out=np.zeros_like(h), where=hn > 0)
            corr = H @ W[:, start:end]
            score = np.max(np.abs(corr), axis=1)
            for rank, k in enumerate(np.argsort(-score)[:4], 1):
                t = int(np.argmax(np.abs(corr[k])))
                signed = float(corr[k, t])
                emit(f'byte={byte}, rank={rank}, key={k:02X}/{k ^ 255:02X}, '
                     f'|r|={score[k]:.6f}, sample={start + t}, r={signed:.6f}')
                rows.append((name, byte, rank, f'{k:02X}', f'{k ^ 255:02X}',
                             float(score[k]), start + t, signed))

import csv
with open('xor_windows_candidates.csv', 'w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerow(['round_key', 'byte', 'rank', 'key_hex', 'complement_hex',
                     'abs_r', 'sample', 'signed_r'])
    writer.writerows(rows)
print('\nSaved xor_windows_result.txt and xor_windows_candidates.csv')
