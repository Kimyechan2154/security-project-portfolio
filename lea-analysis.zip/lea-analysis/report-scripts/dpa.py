from pathlib import Path
Path("결과").mkdir(exist_ok=True)
import h5py
import numpy as np
import matplotlib.pyplot as plt

with h5py.File("LEA_1000tr_2361pt.h5", "r") as f:
    p = f["textin"][:]
    traces = f["waves"][:].astype(np.float64)

n = len(traces)

# 전체 평균을 빼도 두 집단의 평균 차는 그대로입니다.
centered = traces - traces.mean(axis=0)

scores = []
best_score = -1
best_trace = None
best_pair = None

# 절댓값 DPA에서는 (a,b)의 최상위 비트를 뒤집은
# 네 후보가 같은 점수를 냅니다.
# 따라서 a,b < 128인 대표 후보 16,384개만 계산합니다.
for a in range(128):
    b = np.arange(128, dtype=np.uint16)

    # 첫 덧셈의 최하위 바이트: 캐리 입력 없음
    z = (
        (p[:, 0].astype(np.uint16)[None, :] ^ a)
        + (p[:, 4].astype(np.uint16)[None, :] ^ b[:, None])
    ) & 255

    # 예측 중간값의 MSB가 1인 파형을 선택
    group1 = ((z >> 7) & 1).astype(np.float64)
    n1 = group1.sum(axis=1)
    n0 = n - n1
    valid = (n1 > 0) & (n0 > 0)

    # 1집단 평균 - 0집단 평균
    diff = np.zeros((128, traces.shape[1]))
    diff[valid] = (
        (group1[valid] @ centered)
        * (n / (n1[valid] * n0[valid]))[:, None]
    )

    # 각 후보의 모든 시점 중 가장 큰 절댓값
    batch_scores = np.max(np.abs(diff), axis=1)
    scores.extend(
        (float(batch_scores[k]), a, k) for k in range(128)
    )

    winner = int(np.argmax(batch_scores))
    if batch_scores[winner] > best_score:
        best_score = float(batch_scores[winner])
        best_pair = (a, winner)
        best_trace = diff[winner].copy()

    if (a + 1) % 16 == 0:
        print(f"진행: {a + 1}/128", flush=True)

scores.sort(reverse=True)

print("\n상위 5개 대표 후보")
for score, a, b in scores[:5]:
    print(f"a={a:02X}, b={b:02X}, 점수={score:.6f}")

a, b = best_pair
peak = int(np.argmax(np.abs(best_trace)))

print("\n최고 점수와 동률인 네 후보")
for ka, kb in [
    (a, b), (a ^ 128, b),
    (a, b ^ 128), (a ^ 128, b ^ 128)
]:
    print(f"a={ka:02X}, b={kb:02X}")

print(f"최대 차이 시점: {peak} (0부터 시작)")
print(f"최대 절대 평균 차이: {best_score:.6f}")

np.savetxt(
    "결과/dpa_scores.csv",
    np.array([(a, b, s) for s, a, b in scores]),
    delimiter=",",
    header="a,b,score",
    comments="",
    fmt=["%d", "%d", "%.8f"]
)

plt.figure(figsize=(12, 4))
plt.plot(best_trace, linewidth=0.8)
plt.axvline(peak, color="red", linestyle="--")
plt.xlabel("Sample index")
plt.ylabel("Mean difference")
plt.title(f"MSB-DPA: a={a:02X}, b={b:02X}")
plt.tight_layout()
plt.savefig("결과/dpa_result.png", dpi=150)
plt.show()

peak = int(np.argmax(np.abs(best_trace)))

print("최고 키 후보:", best_pair)
print("탐색 중 기록한 점수:", best_score)
print("그래프의 최대 절대 차이:", abs(best_trace[peak]))
print("그래프의 최대 차이 시점:", peak)