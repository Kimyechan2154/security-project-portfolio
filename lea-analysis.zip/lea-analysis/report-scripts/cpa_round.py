import h5py
import numpy as np
from itertools import product

with h5py.File("LEA_1000tr_2361pt.h5", "r") as f:
    p = f["textin"][:].astype(np.uint16)
    waves = f["waves"][:].astype(float)

hw = np.array([i.bit_count() for i in range(256)])

# 파형을 평균 0, 제곱합 1로 정규화
waves -= waves.mean(axis=0)
norm = np.sqrt((waves ** 2).sum(axis=0))
waves /= np.where(norm == 0, 1, norm)

# RK1 = RK3 = RK5의 바이트별 후보
candidates = [
    [0x06, 0xF9],
    [0x0E, 0xF1],
    [0x6B, 0x94],
    [0x74, 0x8B, 0x75, 0x8A]
]

# 평문 위치와 분석 구간: 경계는 파형에서 추정한 값
branches = [
    (0, 4, 220, 780),
    (4, 8, 1010, 1590),
    (8, 12, 1795, 2361)
]

guesses = np.arange(256)[:, None]
best_score = -1

for count, shared in enumerate(product(*candidates), 1):
    words = []
    total_score = 0

    for left, right, start, end in branches:
        carry = np.zeros(len(p), dtype=np.uint16)
        word = []

        for byte in range(4):
            value = (
                (p[:, left + byte] ^ guesses)
                + (p[:, right + byte] ^ shared[byte])
                + carry
            )

            model = hw[value & 255].astype(float)
            model -= model.mean(axis=1, keepdims=True)

            norm = np.sqrt((model ** 2).sum(axis=1, keepdims=True))
            model /= np.where(norm == 0, 1, norm)

            correlation = model @ waves[:, start:end]
            scores = np.abs(correlation).max(axis=1)
            key = int(scores.argmax())

            word.append(key)
            total_score += scores[key]
            carry = value[key] >> 8

        words.append(word)

    print(f"진행: {count}/32", flush=True)

    if total_score > best_score:
        best_score = total_score
        best_words = words
        best_shared = list(shared)

round_key = [
    best_words[0], best_shared,
    best_words[1], best_shared,
    best_words[2], best_shared
]

print("\n라운드키 후보 — 바이트는 little-endian 순서")
for i, word in enumerate(round_key):
    print(f"RK{i}:", " ".join(f"{b:02X}" for b in word))

print("상관계수 절댓값 합:", best_score)
print("정답 검증은 아직 하지 않았습니다.")
from pathlib import Path
Path("결과").mkdir(exist_ok=True)
with open("결과/round_candidate.txt", "w", encoding="utf-8") as f:
    for i, word in enumerate(round_key):
        f.write(f"RK{i}: " + " ".join(f"{b:02X}" for b in word) + "\n")
    f.write(f"sum_abs_r: {best_score}\n")
print("후보 저장: 결과/round_candidate.txt")
