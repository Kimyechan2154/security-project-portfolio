from pathlib import Path
Path("결과").mkdir(exist_ok=True)
import h5py
import numpy as np
import matplotlib.pyplot as plt

# Same addition as the previous DPA. Do not read the keys dataset.
with h5py.File('LEA_1000tr_2361pt.h5', 'r') as f:
    p = f['textin'][:].astype(np.uint16)
    traces = f['waves'][:].astype(np.float64)

hw = np.array([x.bit_count() for x in range(256)], dtype=np.float64)
centered = traces - traces.mean(axis=0)
norm = np.sqrt(np.sum(centered ** 2, axis=0))
normalized = np.divide(centered, norm, out=np.zeros_like(centered), where=norm > 0)

best_score = -1.0
best_pair = None
best_curve = None
results = []

# (a,b) and (a^128,b^128) produce identical low-byte sums.
# a<128 and all 256 values of b cover all 65536 guesses.
for a in range(128):
    b = np.arange(256, dtype=np.uint16)
    z = ((p[:, 0][None, :] ^ a) + (p[:, 4][None, :] ^ b[:, None])) & 255
    model = hw[z]
    model -= model.mean(axis=1, keepdims=True)
    model_norm = np.sqrt(np.sum(model ** 2, axis=1, keepdims=True))
    model = np.divide(model, model_norm, out=np.zeros_like(model), where=model_norm > 0)
    corr = model @ normalized
    scores = np.max(np.abs(corr), axis=1)
    points = np.argmax(np.abs(corr), axis=1)
    for k in range(256):
        results.append((a, k, float(scores[k]), int(points[k])))
    k = int(np.argmax(scores))
    if scores[k] > best_score:
        best_score = float(scores[k])
        best_pair = (a, k)
        best_curve = corr[k].copy()
    if (a + 1) % 8 == 0:
        print(f'Progress: {a + 1}/128', flush=True)

results.sort(key=lambda row: row[2], reverse=True)
print('\nTop 5 representatives (hexadecimal key bytes)')
for ka, kb, score, point in results[:5]:
    print(f'a={ka:02X}, b={kb:02X}, |r|={score:.6f}, sample={point}')
ka, kb = best_pair
peak = int(np.argmax(np.abs(best_curve)))
print('\nBest candidate and its identical-sum partner:')
print(f'({ka:02X}, {kb:02X}), ({ka ^ 128:02X}, {kb ^ 128:02X})')
print(f'Peak |r|={best_score:.6f}, sample={peak} (zero-based)')
print('These are candidates, not verified keys or a complete round key.')

np.savetxt('결과/cpa_scores.csv', np.array(results), delimiter=',',
           header='a,b,absolute_correlation,peak_sample', comments='',
           fmt=['%d', '%d', '%.10f', '%d'])
np.savetxt('결과/cpa_curve.csv', np.column_stack((np.arange(len(best_curve)), best_curve)),
           delimiter=',', header='sample,correlation', comments='', fmt=['%d', '%.10f'])
plt.figure(figsize=(12, 4))
plt.plot(best_curve, linewidth=0.8)
plt.scatter([peak], [best_curve[peak]], color='red', zorder=5, label=f'Peak at {peak}')
plt.xlabel('Sample index')
plt.ylabel('Pearson correlation')
plt.title(f'Addition HW-CPA: a={ka:02X}, b={kb:02X}')
plt.legend()
plt.tight_layout()
plt.savefig('결과/cpa_result.png', dpi=150)
plt.show()
