from pathlib import Path
import json
import numpy as np
import h5py

root = Path(__file__).parent
with h5py.File(root / 'LEA_1000tr_2361pt.h5', 'r') as f:
    p = f['textin'][:].astype(np.uint16)
    waves = f['waves'][:].astype(float)
z = ((p[:, 0] ^ 0x72) + (p[:, 4] ^ 0x05)) & 255
g = ((z >> 7) & 1).astype(bool)
dpa = waves[g].mean(axis=0) - waves[~g].mean(axis=0)
cpa = np.loadtxt(root / '結果' / 'cpa_curve.csv', delimiter=',', skiprows=1) if (root / '結果').exists() else np.loadtxt(root / '결과' / 'cpa_curve.csv', delimiter=',', skiprows=1)
(root / 'chart_data.json').write_text(json.dumps({'dpa': dpa.tolist(), 'cpa': cpa[:, 1].tolist(), 'shape': list(waves.shape)}), encoding='utf-8')
print('shape', waves.shape, 'DPA peak', np.abs(dpa).argmax(), 'CPA peak', np.abs(cpa[:,1]).argmax())
