"""Resolve final-byte MSB alternatives using plaintext/ciphertext, not keys."""
from itertools import product
from pathlib import Path
import h5py

MASK = 0xFFFFFFFF
DELTA = [0xC3EFE9DB, 0x44626B02, 0x79E27C8A, 0x78DF30EC]

def rol(x, n):
    x &= MASK
    n %= 32
    return ((x << n) | (x >> ((32 - n) % 32))) & MASK

def master_from_round(words):
    return [(rol(v, 32 - r) - rol(DELTA[0], j)) & MASK
            for j, (v, r) in enumerate(zip(words, [1, 3, 6, 11]))]

def expand(master):
    t = master.copy()
    rounds = []
    for i in range(24):
        for j, shift in enumerate([1, 3, 6, 11]):
            t[j] = rol(t[j] + rol(DELTA[i % 4], i + j), shift)
        rounds.append([t[0], t[1], t[2], t[1], t[3], t[1]])
    return rounds

def encrypt(plain, rounds):
    x = [int.from_bytes(plain[i:i + 4], 'little') for i in range(0, 16, 4)]
    for k in rounds:
        x = [rol((x[0] ^ k[0]) + (x[1] ^ k[1]), 9),
             rol((x[1] ^ k[2]) + (x[2] ^ k[3]), 27),
             rol((x[2] ^ k[4]) + (x[3] ^ k[5]), 29), x[0]]
    return b''.join(v.to_bytes(4, 'little') for v in x)

def main():
    import sys
    folder = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('.')
    with h5py.File(folder / 'LEA_1000tr_2361pt.h5', 'r') as f:
        plaintext = [bytes(row) for row in f['textin'][:]]
        ciphertext = [bytes(row) for row in f['textout'][:]]

    # Four independent words, in key-schedule order T0,T1,T2,T3.
    candidate_path = folder / '결과' / 'round_candidate.txt'
    if not candidate_path.exists():
        raise FileNotFoundError('먼저 python cpa_round.py를 실행하세요.')
    candidate = {}
    for line in candidate_path.read_text(encoding='utf-8').splitlines():
        label, value = line.split(':', 1)
        if label.startswith('RK'):
            candidate[int(label[2:])] = value.strip()
    if candidate[1] != candidate[3] or candidate[1] != candidate[5]:
        raise ValueError('RK1, RK3, RK5가 일치해야 합니다.')
    recovered = [candidate[i] for i in [0, 1, 2, 4]]
    base = [int.from_bytes(bytes.fromhex(s), 'little') for s in recovered]
    survivors = []
    for flips in product([0, 1], repeat=4):
        words = [v ^ (flip << 31) for v, flip in zip(base, flips)]
        master = master_from_round(words)
        rounds = expand(master)
        if encrypt(plaintext[0], rounds) != ciphertext[0]:
            continue
        matches = sum(encrypt(p, rounds) == c for p, c in zip(plaintext, ciphertext))
        if matches == len(plaintext):
            survivors.append((rounds[0], matches))

    lines = ['검증에 keys 데이터는 사용하지 않았습니다.',
             '각 독립 키 워드의 bit 31을 바꾼 16가지 후보를 검사했습니다.',
             f'모든 암호문과 일치한 후보 수: {len(survivors)}']
    if len(survivors) == 1:
        rk, matches = survivors[0]
        lines.append(f'평문 재암호화 검증: {matches}/{len(plaintext)} 일치')
        lines.append('첫 라운드키 little-endian 바이트 순서')
        for i, word in enumerate(rk):
            lines.append(f"RK{i}: {word.to_bytes(4, 'little').hex(' ').upper()}")
        lines.append('RK0 마지막 바이트의 MSB 모호함은 암호문 검증으로 해결했습니다.')
    else:
        lines.append('키를 확정할 수 없습니다. CPA 후보를 확대해야 합니다.')
    result = '\n'.join(lines)
    print(result)
    # Save beside the script so running from another folder is safe.
    (folder / '결과' / 'key_result.txt').write_text(result, encoding='utf-8')

if __name__ == '__main__':
    main()
