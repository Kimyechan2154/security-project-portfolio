#include <stdio.h>

typedef unsigned char byte;

byte GF256_add(byte a, byte b)
{
    return (byte)(a ^ b);
}

byte GF256_xtime(byte a)
{
    byte result = (byte)(a << 1);

    if ((a & 0x80) != 0) {
        result ^= 0x1b;
    }

    return result;
}

byte GF256_mul(byte a, byte b)
{
    byte h = 0x00;

    for (int i = 7; i >= 0; --i) {
        h = GF256_xtime(h);
        if (((a >> i) & 0x01) != 0) {
            h = GF256_add(h, b);
        }
    }

    return h;
}

byte GF256_mul_table(byte x, byte y,
                     const byte ExpTable[256],
                     const int LogTable[256])
{
    int k;

    if (x == 0 || y == 0) {
        return 0;
    }

    k = (LogTable[x] + LogTable[y]) % 255;
    if (k == 0) {
        k = 255;
    }

    return ExpTable[k];
}

int main(void)
{
    byte value = 1;
    byte ExpTable[256] = {0};
    int LogTable[256] = {0};

    LogTable[0] = -1;

    /* alpha = 0x03, ExpTable[k] = alpha^k (1 <= k <= 255) */
    for (int k = 1; k <= 255; ++k) {
        value = GF256_mul(value, 0x03);
        ExpTable[k] = value;
        LogTable[value] = k;
    }

    for (int k = 1; k <= 255; ++k) {
        printf("ExpTable[%3d] = 0x%02x, LogTable[0x%02x] = %3d\n",
               k, ExpTable[k], ExpTable[k], LogTable[ExpTable[k]]);
    }

    printf("\n0xa1 * 0x63 = 0x%02x\n",
           GF256_mul_table(0xa1, 0x63, ExpTable, LogTable));

    return 0;
}
