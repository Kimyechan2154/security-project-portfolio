﻿#include <stdio.h>

#define MAX_SIZE 16
#define NEARLY_ZERO 1e-10 //0.몇 이런거는 걍 0으로 봄

//행렬을 나타내는 구조체

typedef struct {
	int M[MAX_SIZE][MAX_SIZE];
	int row;
	int col;
} Matrix;

//행렬 출력
void Matrix_print(Matrix A) {
	for (int i = 0; i < A.row; i++) {
		printf("[");
		for (int j = 0; j < A.col; j++) {
			if ((A.M[i][j] < NEARLY_ZERO) && (A.M[i][j] > -NEARLY_ZERO)){
				printf(" %d", 0);
			}
			else {
				printf(" %d", A.M[i][j]);
			}
		}
		printf("]\n");
	}
	printf("\n");
}

//행렬 초기화 쓰레기값을 반환하지 않기 위해
Matrix Matrix_init()
{
	Matrix A;
	A.row = 1; A.col = 1;
	A.M[0][0] = 0.0;
	return A;
}
// 행렬 덧셈
Matrix Matrix_Add(Matrix A, Matrix B) {
	
		Matrix C;
		C = Matrix_init();

		if ((A.col != B.col) || (A.row != B.row))
		{ 
			printf("행 열 길이 각각 다름\n");
			return C;
		}

		C.row = A.row;
		C.col = A.col;
		for (int i = 0; i < A.row; i++) {
			for (int j = 0; j < A.col; j++) {
				C.M[i][j] = A.M[i][j] ^ B.M[i][j];
			}
		}
		return C;
}

// 행렬 곱셈
Matrix Matrix_Mul(Matrix A, Matrix B) {

	Matrix C;
	C = Matrix_init();

	//A[m,k] B[k,n] --> C[m,n]
	//크기 검증 (A 열 개수 == B 행 개수) 
	if (A.col != B.row) {
		printf("(행렬 곱) 행렬 사이즈 에러!\n");
		return C;
	}

	C.row = A.row;
	C.col = B.col;

	for (int i = 0; i < C.row; i++) {
		for (int j = 0; j < C.col; j++) {
			C.M[i][j] = 0.0;
			for (int t = 0; t < A.col; t++) {
				C.M[i][j] ^= A.M[i][t] * B.M[t][j];
			}
		}
	}
	return C;
}

//역행렬 구하기 위한 기본 연산
//두행 바꾸기(참조 기호 &)
void Mat_Exchange_Row(Matrix& A, int row1, int row2) {
	int temp;

	for (int j = 0; j < A.col; j++) {
		temp = A.M[row1][j];
		A.M[row1][j] = A.M[row2][j];
		A.M[row2][j] = temp;
	}
}

//한 행 상수배
void Mat_Scalar_Row(Matrix& A, double k, int row) {
	for (int j = 0; j < A.col; j++) {
		A.M[row][j] *= k;
	}
}

//한 행 생수배를 다른 행에 더하기
void Mat_Row_Add(Matrix& A, int k, int row_src, int row_target) {
	for (int j = 0; j < A.col; j++) {
		A.M[row_target][j] ^= (k & 1) * A.M[row_src][j];
	}
}

//역행렬 구하기
Matrix Matrix_Inverse(Matrix A) {
	Matrix InvA;
	InvA = Matrix_init();

	if (A.row != A.col) {
		printf("행렬이 정사각 행렬이 아니다");
		return InvA;
	}

	//AA
	Matrix AA;
	AA.row = A.row;
	AA.col = A.col*2;
	for (int i = 0; i < A.row; i++) {
		for (int j = 0; j < A.col; j++) {
			AA.M[i][j] = A.M[i][j];
			AA.M[i][A.col + j] = (i == j) ? 1 : 0;
		}
	}

	Matrix_print(AA);

	//합쳐서 왼쪽 단위행렬 만들기
	int pivot_row; //첫번째 열에 0이 나오지 않게
	for (int j = 0; j < A.col; j++) {
		pivot_row = -1;
		for (int i = j; i < A.row; i++) {
			//if (AA.M[i][j] != 0.0) {
			if(AA.M[i][j] > NEARLY_ZERO || AA.M[i][j] < -NEARLY_ZERO)
			{
				pivot_row = i;
				break;
			}
		}
		if (pivot_row == -1) { //역행렬 존재 안함
			printf("역행렬이 없어\n");
			return InvA;
		}
		if (pivot_row != j) {//자리 바꾸기
			Mat_Exchange_Row(AA, j, pivot_row);
		}
		// Mat_Scalar_Row(AA, 1. / AA.M[j][j], j); // 1./AA.M[j][j] 1로 만들어줌

		for (int i = 0; i < AA.row; i++) {
			if (i != j) { //자기 자신 제외 0 이 되게 함
				Mat_Row_Add(AA, AA.M[i][j], j, i);
			}
		}
		Matrix_print(AA);
	}

	InvA.row = A.row;
	InvA.col = A.col;

	for (int i = 0; i < A.row; i++) {
		for (int j = 0; j < A.col; j++) {
			InvA.M[i][j] = AA.M[i][A.col + j];
		}
	}

	return InvA;
}

void test_print() {
    Matrix A;
    A.row = 8;
    A.col = 8;
    int Mat[8][8] = {
        {1,0,0,0,1,1,1,1},
        {1,1,0,0,0,1,1,1},
        {1,1,1,0,0,0,1,1},
        {1,1,1,1,0,0,0,1},
        {1,1,1,1,1,0,0,0},
        {0,1,1,1,1,1,0,0},
        {0,0,1,1,1,1,1,0},
        {0,0,0,1,1,1,1,1}
    };
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            A.M[i][j] = Mat[i][j];
        }
    }
    printf("A =\n");
    Matrix_print(A);
    Matrix D;
    D = Matrix_Inverse(A);
    printf("invA =\n");
    Matrix_print(D);
    printf("A * invA =\n");
    Matrix C = Matrix_Mul(A, D);
    Matrix_print(C);
}

int main() {
    test_print();
    return 0;
}
