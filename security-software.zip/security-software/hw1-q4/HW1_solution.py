"""HW1 problems 3-6. Python 3, standard library only.
Run: python HW1_solution.py
Problems 1 and 2 are worked by hand in the accompanying explanation.
All byte outputs are hexadecimal; polynomial coefficients are in GF(2).
"""

A = [[int(c) for c in row] for row in (
    '10001111', '11000111', '11100011', '11110001',
    '11111000', '01111100', '00111110', '00011111')]


def xtime(a):
    return ((a << 1) ^ (0x1B if a & 0x80 else 0)) & 0xFF


def gf_mul(a, b):
    result = 0
    for _ in range(8):
        if b & 1:
            result ^= a
        a = xtime(a)
        b >>= 1
    return result


def gf_pow(a, n):
    result = 1
    while n:
        if n & 1:
            result = gf_mul(result, a)
        a = gf_mul(a, a)
        n >>= 1
    return result


def inverse_map(a):
    # AES convention: map zero to zero; zero has no field inverse.
    return gf_pow(a, 254) if a else 0


def poly_mul(a, b):
    result = 0
    while b:
        if b & 1:
            result ^= a
        a <<= 1
        b >>= 1
    return result


def poly_divmod(a, b):
    if b == 0:
        raise ZeroDivisionError
    q = 0
    while a and a.bit_length() >= b.bit_length():
        shift = a.bit_length() - b.bit_length()
        q ^= 1 << shift
        a ^= b << shift
    return q, a


def poly(a):
    return ' + '.join('1' if i == 0 else 'x' if i == 1 else f'x^{i}'
                      for i in range(a.bit_length()-1, -1, -1)
                      if (a >> i) & 1) or '0'


def problem3():
    print('3(a):', poly(0xBC))
    r0, r1 = 0x11B, 0xBC
    s0, s1, t0, t1 = 0, 1, 1, 0
    print('3(b): polynomial extended Euclidean algorithm')
    while r1:
        q, r = poly_divmod(r0, r1)
        print(f'({poly(r0)}) = ({poly(q)}) * ({poly(r1)}) + ({poly(r)})')
        r0, r1 = r1, r
        s0, s1 = s1, s0 ^ poly_mul(q, s1)
        t0, t1 = t1, t0 ^ poly_mul(q, t1)
    assert poly_mul(s0, 0xBC) ^ poly_mul(t0, 0x11B) == 1
    print(f'1 = ({poly(s0)}) * a + ({poly(t0)}) * m')
    print(f'inverse(BC) = {s0:02X}')
    for a in (0xBC, 0xBD):
        order = next(k for k in range(1, 256) if gf_pow(a, k) == 1)
        print(f'3(c/d): a={a:02X}, order={order}, inverse={gf_pow(a, order-1):02X}')


def print_matrix(matrix):
    for row in matrix:
        print('[ ' + ' '.join(str(x) for x in row) + ' ]')
    print()


def problem4():
    print('4: A =')
    print_matrix(A)
    aug = [A[i][:] + [int(i == j) for j in range(8)] for i in range(8)]
    print('Initial [A | I]:')
    print_matrix(aug)
    for col in range(8):
        pivot = next((r for r in range(col, 8) if aug[r][col]), None)
        if pivot is None:
            raise ValueError('Singular matrix')
        if pivot != col:
            aug[col], aug[pivot] = aug[pivot], aug[col]
            print(f'Swap rows {col+1} and {pivot+1}')
        for row in range(8):
            if row != col and aug[row][col]:
                aug[row] = [x ^ y for x, y in zip(aug[row], aug[col])]
        print(f'After pivot column {col+1}:')
        print_matrix(aug)
    inverse = [row[8:] for row in aug]
    print('invA =')
    print_matrix(inverse)
    for i in range(8):
        for j in range(8):
            assert sum(A[i][k] * inverse[k][j] for k in range(8)) % 2 == (i == j)
    return inverse


def affine(w, shift=0):
    # LSB-first vectors. Only rows of A rotate; b=0x63 stays unchanged.
    y = 0x63
    for i in range(8):
        bit = 0
        for j in range(8):
            bit ^= A[(i + shift) % 8][j] & ((w >> j) & 1)
        y ^= bit << i
    return y


def points(f):
    fixed, anti = [], []
    for x in range(256):
        y = f(x)
        if y == x:
            fixed.append(x)
        if y == (x ^ 0xFF):
            anti.append(x)
    return fixed, anti


def show_points(label, f):
    fixed, anti = points(f)
    fmt = lambda values: ', '.join(f'{v:02X}' for v in values) or 'none'
    print(f'{label}: fixed=[{fmt(fixed)}]; anti=[{fmt(anti)}]')


def problem5():
    print('5: fixed and anti-fixed points')
    show_points('5(a) AES', lambda x: affine(inverse_map(x)))
    show_points('5(b) inverse only', inverse_map)
    for k in range(1, 8):
        show_points(f'5(c) A{k}', lambda x, k=k: affine(inverse_map(x), k))
    assert affine(inverse_map(0)) == 0x63
    assert affine(inverse_map(0x53)) == 0xED


def make_tables(alpha=0x03):
    # Problem 6(c) uses k=1..255. Index 0 is unused.
    exp = [0] * 256
    log = [-1] * 256  # log(0) is undefined.
    value = 1
    for k in range(1, 256):
        value = gf_mul(value, alpha)
        if log[value] != -1:
            raise ValueError('alpha is not a generator')
        exp[k] = value
        log[value] = k
    assert value == 1 and log[1] == 255
    return exp, log


def table_mul(x, y, exp, log):
    if x == 0 or y == 0:
        return 0
    k = (log[x] + log[y]) % 255
    return exp[255 if k == 0 else k]


def problem6():
    exp, log = make_tables()
    print('6(a): each row gives k, then alpha^k through alpha^(k+15).')
    exp0 = [1] + exp[1:255]
    for start in range(0, 255, 16):
        print(f'{start:3d}: ' + ' '.join(f'{v:02X}' for v in exp0[start:start+16]))
    print(f'6(b): log(A1)={log[0xA1]}, log(63)={log[0x63]}, '
          f'sum mod 255={(log[0xA1]+log[0x63])%255}, '
          f'product={table_mul(0xA1, 0x63, exp, log):02X}')
    print('6(c): k, ExpTable(k), and LogTable(ExpTable(k))')
    for k in range(1, 256):
        print(f'{k:3d}  {exp[k]:02X}  {log[exp[k]]:3d}')
    # Independent reference: unreduced polynomial product and long division.
    for x in range(256):
        for y in range(256):
            expected = poly_divmod(poly_mul(x, y), 0x11B)[1]
            assert gf_mul(x, y) == expected
            assert table_mul(x, y, exp, log) == expected
    print('6(d): all 65,536 byte pairs passed independent multiplication checks.')


if __name__ == '__main__':
    problem3()
    problem4()
    problem5()
    problem6()
