#include <stdio.h>

// 8 x 8 matrix becomes an 8 x 16 augmented matrix.
#define MAX_SIZE 16

typedef struct {
    int M[MAX_SIZE][MAX_SIZE];
    int row;
    int col;
} Matrix;

void Matrix_print(const Matrix& A) {
    for (int i = 0; i < A.row; i++) {
        printf("[");
        for (int j = 0; j < A.col; j++) printf(" %d", A.M[i][j]);
        printf("]\n");
    }
    printf("\n");
}

void Mat_Exchange_Row(Matrix& A, int row1, int row2) {
    for (int j = 0; j < A.col; j++) {
        int temp = A.M[row1][j];
        A.M[row1][j] = A.M[row2][j];
        A.M[row2][j] = temp;
    }
}

// Addition and subtraction in GF(2) are both XOR.
void Mat_Row_Add(Matrix& A, int row_src, int row_target) {
    for (int j = 0; j < A.col; j++)
        A.M[row_target][j] ^= A.M[row_src][j];
}

Matrix Matrix_Mul(const Matrix& A, const Matrix& B) {
    Matrix C = {};
    if (A.col != B.row) return C;
    C.row = A.row;
    C.col = B.col;
    for (int i = 0; i < C.row; i++)
        for (int j = 0; j < C.col; j++)
            for (int k = 0; k < A.col; k++)
                C.M[i][j] ^= A.M[i][k] & B.M[k][j];
    return C;
}

Matrix Matrix_Inverse(Matrix A) {
    Matrix InvA = {};
    if (A.row != A.col || A.row < 1 || A.col * 2 > MAX_SIZE) {
        printf("Invalid matrix size.\n");
        return InvA;
    }
    Matrix AA = {};
    AA.row = A.row;
    AA.col = A.col * 2;
    for (int i = 0; i < A.row; i++) {
        for (int j = 0; j < A.col; j++) {
            AA.M[i][j] = A.M[i][j];
            AA.M[i][A.col + j] = (i == j) ? 1 : 0;
        }
    }

    // Match the homework sample: print after each pivot column.
    for (int j = 0; j < A.col; j++) {
        int pivot_row = -1;
        for (int i = j; i < AA.row; i++) {
            if (AA.M[i][j] == 1) {
                pivot_row = i;
                break;
            }
        }
        if (pivot_row == -1) {
            printf("No inverse.\n");
            return InvA;
        }
        if (pivot_row != j) Mat_Exchange_Row(AA, j, pivot_row);

        // Every nonzero pivot in GF(2) is already 1.
        for (int i = 0; i < AA.row; i++) {
            if (i != j && AA.M[i][j] == 1) Mat_Row_Add(AA, j, i);
        }
        Matrix_print(AA);
    }

    InvA.row = A.row;
    InvA.col = A.col;
    for (int i = 0; i < A.row; i++)
        for (int j = 0; j < A.col; j++)
            InvA.M[i][j] = AA.M[i][A.col + j];
    return InvA;
}

int main() {
    const int data[8][8] = {
        {1,0,0,0,1,1,1,1},
        {1,1,0,0,0,1,1,1},
        {1,1,1,0,0,0,1,1},
        {1,1,1,1,0,0,0,1},
        {1,1,1,1,1,0,0,0},
        {0,1,1,1,1,1,0,0},
        {0,0,1,1,1,1,1,0},
        {0,0,0,1,1,1,1,1}
    };
    Matrix A = {};
    A.row = A.col = 8;
    for (int i = 0; i < 8; i++)
        for (int j = 0; j < 8; j++) A.M[i][j] = data[i][j];
    printf("A =\n");
    Matrix_print(A);
    Matrix InvA = Matrix_Inverse(A);
    if (InvA.row == 0) return 1;
    printf("invA =\n");
    Matrix_print(InvA);

    Matrix C = Matrix_Mul(A, InvA);
    for (int i = 0; i < 8; i++)
        for (int j = 0; j < 8; j++)
            if (C.M[i][j] != (i == j)) return 2;
    return 0;
}
