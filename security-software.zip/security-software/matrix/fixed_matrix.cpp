#include <stdio.h>

#define MAX_SIZE 16
#define MAX_COLS (MAX_SIZE * 2)

// GF(2): 덧셈은 XOR, 곱셈은 AND와 같습니다.
typedef struct {
    int M[MAX_SIZE][MAX_COLS];
    int row;
    int col;
} Matrix;

Matrix Matrix_init(void) {
    Matrix A = {};
    A.row = 1;
    A.col = 1;
    return A;
}

void Matrix_print(const Matrix& A) {
    for (int i = 0; i < A.row; ++i) {
        printf("[");
        for (int j = 0; j < A.col; ++j)
            printf(" %d", A.M[i][j] & 1);
        printf(" ]\n");
    }
    printf("\n");
}

Matrix Matrix_Add(const Matrix& A, const Matrix& B) {
    Matrix C = Matrix_init();
    if (A.row != B.row || A.col != B.col) {
        printf("행렬 크기가 서로 다릅니다.\n");
        return C;
    }

    C.row = A.row;
    C.col = A.col;
    for (int i = 0; i < C.row; ++i)
        for (int j = 0; j < C.col; ++j)
            C.M[i][j] = (A.M[i][j] ^ B.M[i][j]) & 1;
    return C;
}

Matrix Matrix_Mul(const Matrix& A, const Matrix& B) {
    Matrix C = Matrix_init();
    if (A.col != B.row) {
        printf("행렬 곱셈의 크기가 맞지 않습니다.\n");
        return C;
    }

    C.row = A.row;
    C.col = B.col;
    for (int i = 0; i < C.row; ++i) {
        for (int j = 0; j < C.col; ++j) {
            C.M[i][j] = 0;
            for (int k = 0; k < A.col; ++k)
                C.M[i][j] ^= (A.M[i][k] & B.M[k][j]);
        }
    }
    return C;
}

void Mat_Exchange_Row(Matrix& A, int row1, int row2) {
    for (int j = 0; j < A.col; ++j) {
        int temp = A.M[row1][j];
        A.M[row1][j] = A.M[row2][j];
        A.M[row2][j] = temp;
    }
}

void Mat_Row_Xor(Matrix& A, int source, int target) {
    for (int j = 0; j < A.col; ++j)
        A.M[target][j] ^= A.M[source][j];
}

Matrix Matrix_Inverse(const Matrix& A) {
    Matrix InvA = Matrix_init();
    if (A.row != A.col || A.row < 1 || A.row > MAX_SIZE) {
        printf("정사각 행렬이 아니거나 크기 제한을 넘었습니다.\n");
        return InvA;
    }

    Matrix AA = {};
    AA.row = A.row;
    AA.col = A.col * 2;
    for (int i = 0; i < A.row; ++i) {
        for (int j = 0; j < A.col; ++j) {
            AA.M[i][j] = A.M[i][j] & 1;
            AA.M[i][A.col + j] = (i == j);
        }
    }

    for (int col = 0; col < A.col; ++col) {
        int pivot = -1;
        for (int row = col; row < A.row; ++row) {
            if (AA.M[row][col] == 1) {
                pivot = row;
                break;
            }
        }

        if (pivot == -1) {
            printf("역행렬이 존재하지 않습니다.\n");
            return InvA;
        }
        if (pivot != col)
            Mat_Exchange_Row(AA, pivot, col);

        // GF(2)의 피벗은 이미 1이므로 나눗셈이 필요 없습니다.
        for (int row = 0; row < AA.row; ++row) {
            if (row != col && AA.M[row][col] == 1)
                Mat_Row_Xor(AA, col, row);
        }
    }

    InvA.row = A.row;
    InvA.col = A.col;
    for (int i = 0; i < A.row; ++i)
        for (int j = 0; j < A.col; ++j)
            InvA.M[i][j] = AA.M[i][A.col + j];
    return InvA;
}

void test_print(void) {
    Matrix A = {};
    A.row = A.col = 8;
    int data[8][8] = {
        {1,0,0,0,1,1,1,1}, {1,1,0,0,0,1,1,1},
        {1,1,1,0,0,0,1,1}, {1,1,1,1,0,0,0,1},
        {1,1,1,1,1,0,0,0}, {0,1,1,1,1,1,0,0},
        {0,0,1,1,1,1,1,0}, {0,0,0,1,1,1,1,1}
    };

    for (int i = 0; i < 8; ++i)
        for (int j = 0; j < 8; ++j)
            A.M[i][j] = data[i][j];

    Matrix InvA = Matrix_Inverse(A);
    printf("A =\n");
    Matrix_print(A);
    printf("invA =\n");
    Matrix_print(InvA);
    printf("A * invA =\n");
    Matrix_print(Matrix_Mul(A, InvA));
}

int main(void) {
    test_print();
    return 0;
}
