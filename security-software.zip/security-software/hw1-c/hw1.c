#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

/* HW1: computational work is restricted to problems 3--6. */
static const unsigned A[8][8] = {
    {1,0,0,0,1,1,1,1}, {1,1,0,0,0,1,1,1},
    {1,1,1,0,0,0,1,1}, {1,1,1,1,0,0,0,1},
    {1,1,1,1,1,0,0,0}, {0,1,1,1,1,1,0,0},
    {0,0,1,1,1,1,1,0}, {0,0,0,1,1,1,1,1}
};

static void check(int ok, const char *message) {
    if (!ok) { fprintf(stderr, "FAIL: %s\n", message); exit(EXIT_FAILURE); }
}

/* Polynomial basis; AES modulus is 0x11b. */
static uint8_t gf_mul(uint8_t a, uint8_t b) {
    unsigned aa = a, bb = b, result = 0;
    while (bb) {
        if (bb & 1u) result ^= aa;
        bb >>= 1;
        aa <<= 1;
        if (aa & 0x100u) aa ^= 0x11bu;
    }
    return (uint8_t)result;
}

static uint8_t gf_pow(uint8_t a, unsigned n) {
    uint8_t result = 1;
    while (n) {
        if (n & 1u) result = gf_mul(result, a);
        a = gf_mul(a, a);
        n >>= 1;
    }
    return result;
}

/* 0 maps to 0 only by the AES S-box convention. */
static uint8_t aes_inverse(uint8_t a) {
    return a ? gf_pow(a, 254) : 0;
}

static unsigned gf_order(uint8_t a) {
    uint8_t p = 1;
    if (!a) return 0; /* multiplicative order is undefined */
    for (unsigned k = 1; k <= 255; ++k) {
        p = gf_mul(p, a);
        if (p == 1) return k;
    }
    check(0, "order not found");
    return 0;
}

static int degree(unsigned p) {
    int d = -1;
    while (p) { p >>= 1; ++d; }
    return d;
}

static unsigned poly_mul(unsigned a, unsigned b) {
    unsigned p = 0;
    while (b) {
        if (b & 1u) p ^= a;
        a <<= 1;
        b >>= 1;
    }
    return p;
}

static unsigned poly_div(unsigned a, unsigned b, unsigned *rem) {
    unsigned q = 0;
    check(b != 0, "polynomial division by zero");
    while (a && degree(a) >= degree(b)) {
        unsigned shift = (unsigned)(degree(a) - degree(b));
        q ^= 1u << shift;
        a ^= b << shift;
    }
    *rem = a;
    return q;
}

static void problem3(void) {
    unsigned r0 = 0x11b, r1 = 0xbc;
    unsigned s0 = 1, s1 = 0, t0 = 0, t1 = 1;
    puts("=== Problem 3 ===");
    puts("(a) 0xbc = x^7 + x^5 + x^4 + x^3 + x^2");
    puts("(b) Polynomial EEA: r = s*m + t*a (all values hexadecimal)");
    printf("r=%03x s=%03x t=%03x\n", r0,s0,t0);
    printf("r=%03x s=%03x t=%03x\n", r1,s1,t1);
    while (r1 != 0) {
        unsigned rem, q = poly_div(r0,r1,&rem);
        unsigned s = s0 ^ poly_mul(q,s1);
        unsigned t = t0 ^ poly_mul(q,t1);
        check(rem == (poly_mul(s,0x11b) ^ poly_mul(t,0xbc)), "EEA identity");
        printf("q=%03x r=%03x s=%03x t=%03x\n",q,rem,s,t);
        r0=r1; r1=rem; s0=s1; s1=s; t0=t1; t1=t;
    }
    check(r0 == 1, "gcd must be one");
    unsigned inv;
    (void)poly_div(t0,0x11b,&inv);
    printf("inverse(bc)=%02x; bc*%02x=%02x\n",inv,inv,gf_mul(0xbc,(uint8_t)inv));
    for (unsigned a=0xbc; a<=0xbd; ++a) {
        unsigned n=gf_order((uint8_t)a);
        printf("order(%02x)=%u; inverse=%02x; product=%02x\n",a,n,
               gf_pow((uint8_t)a,n-1),gf_mul((uint8_t)a,gf_pow((uint8_t)a,n-1)));
        printf("%02x^15=%02x; ^17=%02x; ^51=%02x; ^85=%02x; ^255=%02x\n",a,
               gf_pow((uint8_t)a,15),gf_pow((uint8_t)a,17),gf_pow((uint8_t)a,51),
               gf_pow((uint8_t)a,85),gf_pow((uint8_t)a,255));
        printf("Repeated squares:");
        for (unsigned k=1;k<=128;k*=2) printf(" %u:%02x",k,gf_pow((uint8_t)a,k));
        putchar('\n');
    }
}

static void print_aug(unsigned m[8][16]) {
    for (unsigned i=0;i<8;++i) {
        printf("[");
        for (unsigned j=0;j<16;++j) {
            if (j==8) printf(" |");
            printf(" %u",m[i][j]);
        }
        puts(" ]");
    }
}

static void problem4(void) {
    unsigned m[8][16] = {{0}};
    puts("=== Problem 4 ===");
    puts("Initial [A | I]:");
    for (unsigned i=0;i<8;++i) {
        for (unsigned j=0;j<8;++j) m[i][j]=A[i][j];
        m[i][8+i]=1;
    }
    print_aug(m);
    for (unsigned c=0;c<8;++c) {
        unsigned p=c;
        while (p<8 && m[p][c]==0) ++p;
        check(p<8,"singular matrix");
        printf("Pivot %u:\n",c+1);
        if (p!=c) {
            printf("R%u <-> R%u\n",c+1,p+1);
            for (unsigned j=0;j<16;++j) {
                unsigned tmp=m[c][j]; m[c][j]=m[p][j]; m[p][j]=tmp;
            }
        }
        for (unsigned r=0;r<8;++r) {
            if (r!=c && m[r][c]) {
                printf("R%u <- R%u XOR R%u\n",r+1,r+1,c+1);
                for (unsigned j=0;j<16;++j) m[r][j]^=m[c][j];
            }
        }
        print_aug(m);
    }
    puts("invA =");
    for (unsigned i=0;i<8;++i) {
        printf("[");
        for (unsigned j=0;j<8;++j) printf(" %u",m[i][8+j]);
        puts(" ]");
    }
    for (unsigned i=0;i<8;++i) for (unsigned j=0;j<8;++j) {
        unsigned left=0,right=0;
        for (unsigned k=0;k<8;++k) {
            left ^= A[i][k] & m[k][8+j];
            right ^= m[i][8+k] & A[k][j];
        }
        check(left==(unsigned)(i==j) && right==(unsigned)(i==j),"matrix inverse");
    }
    puts("A*invA = invA*A = I: PASS");
}

/* LSB-first column vector. Only A's rows rotate; b=0x63 is fixed. */
static uint8_t sbox(uint8_t x, unsigned shift) {
    unsigned z=aes_inverse(x), y=0;
    for (unsigned i=0;i<8;++i) {
        unsigned bit=(0x63u>>i)&1u;
        for (unsigned j=0;j<8;++j) bit ^= A[(i+shift)%8][j] & ((z>>j)&1u);
        y |= bit<<i;
    }
    return (uint8_t)y;
}

static void points(const char *label, int inverse_only, unsigned shift) {
    printf("%s\n",label);
    for (unsigned anti=0;anti<=1;++anti) {
        unsigned count=0;
        printf("  %s:",anti?"anti-fixed":"fixed");
        for (unsigned x=0;x<256;++x) {
            unsigned y=inverse_only?aes_inverse((uint8_t)x):sbox((uint8_t)x,shift);
            if (y==(anti?(x^0xffu):x)) { printf(" %02x",x); ++count; }
        }
        if (!count) printf(" none");
        printf(" (count=%u)\n",count);
    }
}

static void problem5(void) {
    puts("=== Problem 5 ===");
    for (unsigned x=1;x<256;++x) check(gf_mul((uint8_t)x,aes_inverse((uint8_t)x))==1,"inverse");
    check(sbox(0,0)==0x63 && sbox(0x53,0)==0xed && sbox(0xff,0)==0x16,"AES S-box examples");
    points("(a) AES S-box",0,0);
    points("(b) Inversion only (0 -> 0)",1,0);
    for (unsigned s=1;s<8;++s) {
        char label[32];
        snprintf(label,sizeof(label),"(c) A%u, b=63",s);
        points(label,0,s);
    }
    puts("Inverses (nonzero 255 inputs), S-box examples: PASS");
}

/* Problem 6(c): legal exponents are 1..255, so LogTable[1]=255.
   LogTable[0]=-1; ExpTable[0] is an unused sentinel. */
static uint8_t ExpTable[256];
static int LogTable[256];

static void build_tables(uint8_t alpha) {
    unsigned seen[256]={0};
    uint8_t p=1;
    for (unsigned x=0;x<256;++x) LogTable[x]=-1;
    for (unsigned k=1;k<=255;++k) {
        p=gf_mul(p,alpha);
        check(p!=0 && !seen[p],"alpha must be a generator");
        seen[p]=1; ExpTable[k]=p; LogTable[p]=(int)k;
    }
    check(p==1 && LogTable[1]==255,"table endpoint");
}

static uint8_t table_mul(uint8_t x, uint8_t y) {
    if (!x || !y) return 0;
    unsigned k=(unsigned)(LogTable[x]+LogTable[y])%255;
    if (k==0) k=255;
    return ExpTable[k];
}

static void problem6(void) {
    puts("=== Problem 6 ===");
    build_tables(0x03);
    printf("order(03)=%u; 03^85=%02x; 03^51=%02x; 03^15=%02x; 03^255=%02x\n",
           gf_order(3),gf_pow(3,85),gf_pow(3,51),gf_pow(3,15),gf_pow(3,255));
    puts("(a) alpha^k, k=0..254; row label is decimal k, values are hex:");
    for (unsigned k=0;k<255;++k) {
        if (k%16==0) printf("%3u:",k);
        printf(" %02x",k==0?1:ExpTable[k]);
        if (k%16==15 || k==254) putchar('\n');
    }
    printf("(b) Log(a1)=%d, Log(63)=%d, sum mod 255=%d; a1*63=%02x\n",
           LogTable[0xa1],LogTable[0x63],(LogTable[0xa1]+LogTable[0x63])%255,table_mul(0xa1,0x63));
    puts("(c) ExpTable[k], k=1..255; row label is decimal k:");
    for (unsigned k=1;k<=255;++k) {
        if ((k-1)%16==0) printf("%3u:",k);
        printf(" %02x",ExpTable[k]);
        if ((k-1)%16==15 || k==255) putchar('\n');
    }
    puts("LogTable[x], x=00..ff; row labels are hex, entries are DECIMAL (-1=undefined):");
    for (unsigned x=0;x<256;++x) {
        if (x%16==0) printf("%02x:",x);
        printf(" %3d",LogTable[x]);
        if (x%16==15) putchar('\n');
    }
    for (unsigned x=1;x<256;++x) check(ExpTable[LogTable[x]]==x,"log/exp round trip");
    for (unsigned x=0;x<256;++x) for (unsigned y=0;y<256;++y)
        check(table_mul((uint8_t)x,(uint8_t)y)==gf_mul((uint8_t)x,(uint8_t)y),"table multiplication");
    puts("(d) All 65536 byte pairs: table_mul == gf_mul: PASS");
    printf("00*63=%02x; 01*01=%02x; 03*f6=%02x; a1*63=%02x\n",
           table_mul(0,0x63),table_mul(1,1),table_mul(3,0xf6),table_mul(0xa1,0x63));
}

int main(int argc, char **argv) {
    if (argc==1) { problem3(); problem4(); problem5(); problem6(); return 0; }
    if (argc!=2) { fprintf(stderr,"Usage: hw1 [3|4|5|6]\n"); return 1; }
    if (!strcmp(argv[1],"3")) problem3();
    else if (!strcmp(argv[1],"4")) problem4();
    else if (!strcmp(argv[1],"5")) problem5();
    else if (!strcmp(argv[1],"6")) problem6();
    else { fprintf(stderr,"Usage: hw1 [3|4|5|6]\n"); return 1; }
    return 0;
}
