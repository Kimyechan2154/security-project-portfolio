import socket
import threading

def send_message(sock, running_event):
    while running_event.is_set():
        try:
            msg = input("client: ")
            sock.sendall(msg.encode('utf-8'))

            if msg.lower() == 'quit':
                print("클라이언트를 종료합니다.")
                running_event.clear()

                try:
                    sock.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass

                break

        except Exception:
            break


def receive_message(sock, running_event):
    while running_event.is_set():
        try:
            data = sock.recv(1024)

            if not data:
                break

            message = data.decode('utf-8')
            print("server:", message)

            if message.lower() == 'quit':
                print("서버가 종료를 요청했습니다.")
                running_event.clear()

                try:
                    sock.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass

                break

        except Exception:
            break


SERVER_IP = '127.0.0.1'
PORT = 12345

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((SERVER_IP, PORT))

print(f"서버 {SERVER_IP}:{PORT}에 연결됨")
print("메시지를 입력하세요. 종료하려면 'quit' 입력")

running_event = threading.Event()
running_event.set()

send_thread = threading.Thread(
    target=send_message,
    args=(client_socket, running_event)
)

receive_thread = threading.Thread(
    target=receive_message,
    args=(client_socket, running_event)
)

send_thread.start()
receive_thread.start()

send_thread.join()
receive_thread.join()

client_socket.close()

print("클라이언트가 안전하게 종료되었습니다.")