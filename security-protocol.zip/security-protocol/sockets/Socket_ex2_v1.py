import socket
import threading


def send_message(sock, running_event):
    while running_event.is_set():
        try:
            msg = input("server: ")
            sock.sendall(msg.encode('utf-8'))

            if msg.lower() == 'quit':
                print("서버 종료")
                running_event.clear()

                try:
                    sock.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass

                break

        except Exception:
            break


def receive_message(sock, running_event):
    while running_event.is_set():
        try:
            data = sock.recv(1024)

            if not data:
                running_event.clear()
                break

            message = data.decode('utf-8')
            print("client:", message)

            if message.lower() == 'quit':
                print("클라이언트 연결 종료")
                running_event.clear()

                try:
                    sock.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass

                break

        except Exception:
            break


HOST = '127.0.0.1'
PORT = 12345

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((HOST, PORT))
server_socket.listen(1)

print(f"서버 시작: 포트 {PORT} 대기중...")
print("클라이언트 연결 대기중...")

client_socket, client_addr = server_socket.accept()

print(f"클라이언트 {client_addr} 연결됨")
print("메시지를 입력하세요('quit' 입력 시 종료)\n")

running_event = threading.Event()
running_event.set()

send_thread = threading.Thread(
    target=send_message,
    args=(client_socket, running_event)
)

receive_thread = threading.Thread(
    target=receive_message,
    args=(client_socket, running_event)
)

send_thread.start()
receive_thread.start()

send_thread.join()
receive_thread.join()

client_socket.close()
server_socket.close()

print("서버 종료")