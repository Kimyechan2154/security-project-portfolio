from pathlib import Path
import shutil,difflib,json
r=Path.cwd();base=r/'outputs/pepsi-precompute';d=r/'outputs/pepsi-unroll';assert not d.exists()
for f in ('src','build-support','tools','baseline'):shutil.copytree(base/f,d/f)
for f in ('baseline-manifest.json','config.json','requirements.txt'):shutil.copyfile(base/f,d/f)
s=(base/'src/myCrypt.c').read_text();before=s
fast=(r/'outputs/pepsi-fast94/src/myCrypt.c').read_text()
a=s.index('static void expand_masked_key(');b=s.index('/* Shared S-box',a)
fa=fast.index('static void expand_masked_key(');fb=fast.index('/* Shared S-box',fa)
s=s[:a]+fast[fa:fb]+s[b:]
helper=''
for final in (False,True):
 name='masked_sub_shift_final' if final else 'masked_sub_shift'
 args='' if final else ', const byte row_change[4]'
 change='0' if final else 'row_change[i&3]'
 helper+=f'static void {name}(const byte *input, byte *output, const byte *key, const byte order[16]{args})\n{{\n'
 # Explicit statements preserve shuffled order without a byte loop.
 for step in range(16):
  helper+=f'    {{ byte i=order[{step}]; byte value=masked_add_round_key(input[i],key[i]); output[shift_destination[i]]=lookup_remasked(value,{change}); }}\n'
 helper+='}\n'
s=s.replace('void Encrypt(unsigned char* PT',helper+'void Encrypt(unsigned char* PT')
a=s.index('    for(round=0;round<10;++round) {');b=s.index('    /* State and final key',a)
s=s[:a]+'''    round=0;
    /* PHASE_BEFORE */
    masked_sub_shift(in_state,out_state,round_keys[0],order,row_change);
    /* PHASE_SUB */
    mix_columns(out_state,columns);
    /* PHASE_MIX */
#if !CONTEST_FULL
    trigger_low();
#endif
    temporary=in_state;in_state=out_state;out_state=temporary;
    for(round=1;round<9;++round) {
        /* PHASE_BEFORE */
        masked_sub_shift(in_state,out_state,round_keys[round],order,row_change);
        /* PHASE_SUB */
        mix_columns(out_state,columns);
        /* PHASE_MIX */
        temporary=in_state;in_state=out_state;out_state=temporary;
    }
    round=9;
    /* PHASE_BEFORE */
    masked_sub_shift_final(in_state,out_state,round_keys[9],order);
    /* PHASE_SUB */
    in_state=out_state;
''' +s[b:]
(d/'src/myCrypt.c').write_text(s,encoding='utf-8')
(d/'changes.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='all-round-precompute',tofile='all-round-unrolled')),encoding='utf-8')
cfg=json.loads((d/'config.json').read_text());cfg['candidate']='all-round-masking-unrolled-fused-SB-SR';(d/'config.json').write_text(json.dumps(cfg,indent=2))
v=(base/'tools/check_phases.py').read_text().replace('pepsi-precompute','pepsi-unroll')
a=v.index("s=s.replace('    for(round=0;");b=v.index("(b/'observed.c').write_text(s)",a)
v=v[:a]+'''s=s.replace('/* PHASE_BEFORE */','{byte mask[16];for(i=0;i<16;++i)mask[i]=n[i&3];observe(round,0,in_state,mask);}')
s=s.replace('/* PHASE_SUB */','{byte rows[4]={row_mask0,row_mask1,row_mask2,row_mask3},mask[16];for(i=0;i<16;++i)mask[i]=round<9?rows[i&3]:key_output_mask;observe(round,2,out_state,mask);}')
s=s.replace('/* PHASE_MIX */','{byte mask[16];for(i=0;i<16;++i)mask[i]=n[i&3];observe(round,4,out_state,mask);}')
''' +v[b:]
v=v.replace('assert d.get_permutation_calls()==500 and d.get_order_failure()==0','')
v=v.replace("'permutation_calls':500,'order_reuse_all_rounds':'PASS',",'')
(d/'tools/check_phases.py').write_text(v,encoding='utf-8')
(d/'phase-check').mkdir();shutil.copyfile(d/'src/myCrypt.h',d/'phase-check/myCrypt.h');(d/'phase-check/hal.h').write_text('void trigger_high(void);void trigger_low(void);')
