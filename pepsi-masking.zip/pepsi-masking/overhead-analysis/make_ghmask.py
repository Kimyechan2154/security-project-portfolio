from pathlib import Path
import re,shutil,json,hashlib,difflib
r=Path.cwd();d=r/'outputs/pepsi-ghmask';base=r/'outputs/pepsi-unroll'
raw=(d/'origin/masking.c').read_text(encoding='utf-8');s=(base/'src/myCrypt.c').read_text()
for folder in ('src','build-support','tools','baseline'):shutil.copytree(base/folder,d/folder)
for f in ('baseline-manifest.json','config.json','requirements.txt'):shutil.copyfile(base/f,d/f)
def function(text,name):
 start=re.search(r'(?:static inline |static )?(?:void|byte) '+name+r'\(',text).start();a=text.index('{',start);depth=1;b=a+1
 while depth:
  depth+=(text[b]=='{')-(text[b]=='}');b+=1
 return text[start:b]
# Actual upstream constants and S-box builder, translated to internal names.
for upstream,local in [('sbox','aes_sbox'),('Rcon','round_constants')]:
 orig=re.search(r'const byte '+upstream+r'\[\d+\] = \{.*?\};',raw,re.S).group(0)
 s=re.sub(r'static const byte '+local+r'\[\d+\] = \{.*?\};',lambda m:'static '+orig.replace(upstream,local),s,count=1,flags=re.S)
sb=function(raw,'M_MSbox').replace('M_MSbox','build_key_sbox').replace('MSbox','key_sbox').replace('sbox[','aes_sbox[')
# Avoid replacement of the suffix in key_sbox.
sb=sb.replace('key_aes_sbox','key_sbox')
s=s.replace(function(s,'build_key_sbox'),'static '+sb)
a=s.index('static void expand_masked_key(');b=s.index('/* Shared S-box',a)
key='''/* Adapted from upstream M_KeyExpansion: explicit four-byte words,
 * nine ordinary rounds and a separate tenth-round mask conversion.
 * Write directly to round_keys; avoid upstream Wm[44][4] plus copy.
 */
static void M_KeyExpansion(byte key[16], byte round_keys[11][16], byte m, byte output_mask,
                    byte row_mask0, byte row_mask1, byte row_mask2, byte row_mask3,
                    byte n1, byte n2, byte n3, byte n4)
{
    byte q[4]={n1^m,n2^m,n3^m,n4^m};
    byte n[4]={n1,n2,n3,n4};
    byte guard[4]={row_mask0,row_mask1,row_mask2,row_mask3};
    byte round, i;
    for(i=0;i<16;++i) round_keys[0][i]=key[i]^q[i&3];
    for(round=0;round<9;++round) {
        const byte *previous=round_keys[round];
        byte *current=round_keys[round+1];
'''
for i in range(4):
 rot=(i+1)&3;rc=' ^ round_constants[round]' if i==0 else ''
 key+=f'        current[{i}]=masked_different(previous[{i}],key_sbox[previous[{12+rot}]^n[{rot}]],output_mask){rc};\n'
for i in range(4,16):key+=f'        current[{i}]=masked_same(previous[{i}],current[{i-4}],q[{i&3}],guard[{i&3}]);\n'
key+='    }\n    {\n        const byte *previous=round_keys[9];\n        byte *current=round_keys[10];\n'
for i in range(4):
 rot=(i+1)&3;rc=' ^ round_constants[9]' if i==0 else ''
 key+=f'        current[{i}]=masked_remask(masked_different(previous[{i}],key_sbox[previous[{12+rot}]^n[{rot}]],output_mask),q[{i}]^output_mask){rc};\n'
for i in range(4,16):key+=f'        current[{i}]=masked_same(previous[{i}],current[{i-4}],q[{i&3}],guard[{i&3}]);\n'
key+='    }\n}\n'
s=s[:a]+key+s[b:];s=s.replace('expand_masked_key(KEY','M_KeyExpansion(KEY')
s=s.replace('masked_sub_shift_final','M_SubBytes_ShiftRows_final').replace('masked_sub_shift','M_SubBytes_ShiftRows')
s=s.replace('/* Port of the supplied PEPSI_AES-8bit/main.c.','/* Derived from Kimyechan2154/school PEPSI/Masking/masking.c.\n * Upstream blob 54e1cc7ce8927b1a2620e2c7f98b90f555f62209.')
(d/'src/myCrypt.c').write_text(s,encoding='utf-8')
(d/'from-upstream.diff').write_text(''.join(difflib.unified_diff(raw.splitlines(True),s.splitlines(True),fromfile='GitHub/masking.c',tofile='src/myCrypt.c')),encoding='utf-8')
(d/'origin/provenance.json').write_text(json.dumps({'url':'https://github.com/Kimyechan2154/school/blob/main/PEPSI/Masking/masking.c','upstream_blob_sha':'54e1cc7ce8927b1a2620e2c7f98b90f555f62209','saved_sha256':hashlib.sha256((d/'origin/masking.c').read_bytes()).hexdigest(),'note':'Fetched via GitHub connector; saved decoded text snapshot. AVR helpers/adapter/shuffling retained from locally verified pepsi-unroll.'},indent=2))
v=(d/'tools/check_phases.py').read_text().replace('pepsi-unroll','pepsi-ghmask');(d/'tools/check_phases.py').write_text(v)
(d/'phase-check').mkdir();shutil.copyfile(d/'src/myCrypt.h',d/'phase-check/myCrypt.h');(d/'phase-check/hal.h').write_text('void trigger_high(void);void trigger_low(void);')
cfg=json.loads((d/'config.json').read_text());cfg['candidate']='github-masking-adapted-unrolled';(d/'config.json').write_text(json.dumps(cfg,indent=2))
