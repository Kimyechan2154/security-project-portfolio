from pathlib import Path
import shutil,json,hashlib
root=Path(__file__).resolve().parents[2];old=root/'outputs/pepsi-asm';d=root/'outputs/pepsi-asm2'
assert not d.exists(),'Do not overwrite an existing candidate'
d.mkdir()
for name in ('src','tools','origin','build-support'):shutil.copytree(old/name,d/name)
for name in ('config.json','requirements.txt'):shutil.copyfile(old/name,d/name)
b=d/'baseline';b.mkdir()
for p in (old/'src').iterdir():shutil.copyfile(p,b/p.name)
for p in old.glob('*.hex'):shutil.copyfile(p,b/p.name)
shutil.copyfile(old/'verification/assembly-report.json',b/'assembly-report.json')
(d/'baseline-manifest.json').write_text(json.dumps({p.relative_to(d).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in b.iterdir()},indent=2))
s=(d/'src/masked_aes.S').read_text()
s=s.replace(' * Private routines may clobber r0,r16..r31 and SREG as documented below.', ' * Private routines may clobber r0,r16..r31 and SREG as documented below.\n * expand_keys additionally borrows r8..r15 before the round pointers are set.')
s=s.replace('key_sbox: .skip 256','.balign 256\nkey_sbox: .skip 256')
s=s.replace('round_keys: .skip 176','.balign 16\nround_keys: .skip 176')
s=s.replace('state_a: .skip 16','.balign 16\nstate_a: .skip 16')
s=s.replace('asm_workspace_end:', 'scheduled_dest: .skip 16\nscheduled_change: .skip 16\nasm_workspace_end:')
# Xorshift sequence is bit-for-bit identical. Remove loop overhead only.
s=s.replace('''    clr r22
    mov r23,r18''','''    mov r23,r18''',1)
s=s.replace('''    ldi r26,5
1:  lsl r22
    rol r23
    rol r24
    rol r25
    dec r26
    brne 1b
    eor r18,r22''','''    .rept 5
        lsl r23
        rol r24
        rol r25
    .endr''',1)
s=s.replace('''    ldi r26,5
2:  lsl r22
    rol r23
    rol r24
    rol r25
    dec r26
    brne 2b''','''    .rept 5
        lsl r22
        rol r23
        rol r24
        rol r25
    .endr''',1)
# Page-aligned MSbox permits an address formed directly from the masked index.
s=s.replace('''    PTR r30,r31,key_sbox
    add r30,r24
    adc r31,r1''','''    mov r30,r24
    ldi r31,hi8(key_sbox)''')
# Keep random correction and guard in otherwise unused round registers during
# setup. Key XOR order is unchanged; no intermediate raw key is introduced.
s=s.replace('''    lds r21,masks+1
    eor r18,r20''','''    eor r18,r20''',1)
start=s.index('.macro KEY_NEXT');end=s.index('.endm',start)+len('.endm')
s=s[:start]+r'''.macro KEY_NEXT pos,change,guard
    ldd r18,Y+\pos
    ldd r19,Y+(12+\pos)
    eor r19,\change
    eor r18,r19
    eor r18,\guard
    std Y+(16+\pos),r18
.endm'''+s[end:]
for pos in range(4,16):
    row=pos%4;s=s.replace(f'    KEY_NEXT {pos},{row}',f'    KEY_NEXT {pos},r{8+row},r{12+row}')
init='    /* r8..r11=q^guard, r12..r15=guard; used only during key expansion. */\n'
for row in range(4):init+=f'    lds r{8+row},q_masks+{row}\n    lds r{12+row},masks+{2+row}\n    eor r{8+row},r{12+row}\n'
init+='    lds r21,masks+1\n'
s=s.replace('    ldi r16,9\n    ldi r17,1',init+'    ldi r16,9\n    ldi r17,1')
# Four table entries per loop, identical values and store order.
start=s.index('    PTR r26,r27,aes_sbox');end=s.index('    .set row,0',start)
s=s[:start]+'''    PTR r26,r27,aes_sbox
    ldi r31,hi8(key_sbox)
    clr r18
2:  .rept 4
        ld r19,X+
        eor r19,r17
        mov r30,r18
        eor r30,r16
        st Z,r19
        inc r18
    .endr
    brne 2b
'''+s[end:]
# Precompute the destination and mask correction in the existing permutation
# order. No additional random calls; setup remains inside the FULL trigger.
at=s.index('/* Fully expanded 16 operations')
s=s[:at]+'''/* Values depend only on the permutation and masks, not key/plaintext. */
.type prepare_schedule,@function
prepare_schedule:
    .set pos,0
    .rept 16
        lds r18,order+pos
        PTR r30,r31,shift_destination
        add r30,r18
        adc r31,r1
        ld r19,Z
        sts scheduled_dest+pos,r19
        andi r18,3
        PTR r30,r31,row_change
        add r30,r18
        adc r31,r1
        ld r19,Z
        sts scheduled_change+pos,r19
        .set pos,pos+1
    .endr
    ret
.size prepare_schedule,.-prepare_schedule

'''+s[at:]
start=s.index('.macro SUB_SHIFT');end=s.index('.endm',start)+len('.endm')
s=s[:start]+r'''/* State/key bases are 16-byte aligned: adding index 0..15 cannot
 * carry from the low address byte. MSbox is 256-byte aligned.
 * Inline lookup retains exactly CLR -> LD -> EOR for its destination. */
.macro SUB_SHIFT pos,final=0
    lds r18,order+\pos
    movw r30,r8
    add r30,r18
    ld r24,Z
    movw r30,r12
    add r30,r18
    ld r20,Z
    eor r24,r20
    .if \final
        clr r22
    .else
        lds r22,scheduled_change+\pos
    .endif
    mov r30,r24
    ldi r31,hi8(key_sbox)
    clr r24
    ld r24,Z
    eor r24,r22
    lds r25,scheduled_dest+\pos
    movw r30,r10
    add r30,r25
    st Z,r24
.endm'''+s[end:]
s=s.replace('    call make_permutation\n','    call make_permutation\n    call prepare_schedule\n')
(d/'src/masked_aes.S').write_text(s)
v=(d/'tools/verify.py').read_text()
needle="                obj=probe/f'production-core-{label}.o'"
extra='''                # The production SubBytes routines use inlined lookups.
                for function in ('sub_shift','sub_shift_final'):
                    section=re.search(r'<'+function+r'>:\\s*(.*?)(?=^[0-9a-f]+ <|\\Z)',dis,re.S|re.M).group(1)
                    hits=re.findall(r'eor\\s+(r\\d+),\\s*\\1\\s*\\n\\s*[0-9a-f]+:.*ld\\s+\\1, Z\\s*\\n\\s*[0-9a-f]+:.*eor\\s+\\1,',section)
                    if len(hits)!=16:raise ValueError(function+' inline lookup clear/load/remask check failed')
                symbols=run([bin/'avr-nm.exe','-n',cwd/'simpleserial-contest-CWLITEXMEGA.elf'],cwd,f'symbols-{label}.log',env)
                for name,alignment in (('key_sbox',256),('round_keys',16),('state_a',16),('state_b',16)):
                    addr=int(re.search(r'^([0-9a-f]+) [a-zA-Z] '+name+r'$',symbols,re.M).group(1),16)
                    if addr%alignment:raise ValueError(name+' address alignment failed')
'''
v=v.replace(needle,extra+needle)
(d/'tools/verify.py').write_text(v)
v=(d/'tools/verify_assembly.py').read_text().replace("'comparison_FULL_baseline_instructions':25666","'comparison_FULL_baseline_instructions':15457")
(d/'tools/verify_assembly.py').write_text(v)
cfg=json.loads((d/'config.json').read_text());cfg.update(baseline='pepsi-asm',candidate='asm2-aligned-scheduled-inline',latest_server_baseline={'cycles':21563,'overhead':1.54,'performance_score':18.8,'prng_submission_value':2,'security_score':None})
(d/'config.json').write_text(json.dumps(cfg,indent=2))
print(d)
