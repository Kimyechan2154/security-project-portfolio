from pathlib import Path
import json,hashlib,zipfile,shutil
r=Path.cwd();d=r/'outputs/pepsi-fast94';v=d/'verification'
for name in ('report.json','key-expansion.json','phase-results.json','asan.json'):
 obj=json.loads((v/name).read_text());assert obj.get('status',obj.get('result'))=='PASS'
for name in ('check_daily_keys.py','asan_daily.py'):shutil.copyfile(r/'outputs/overhead-analysis'/name,v/name)
(d/'README.md').write_text('''# PEPSI fast94 — 하루 1회 제출용 비교 후보

이번에 제출할 파일은 루트의 pepsi-fast94-ROUND1.hex와 pepsi-fast94-FULL.hex 두 개입니다. src/myCrypt.c가 수정 코드입니다. 기존 94.7점 제출본은 baseline에 소스·공용 파서·HEX를 보존했습니다. 원래 pepsi-round1-10 폴더/ZIP도 변경하지 않았습니다.

## 선정 이유
같은 입력(NIST AES 첫 벡터), PRNG 상태 1, 시뮬레이터 타이머 0에서 실제 제출 빌드 객체를 실행한 명령 수:
| 후보 | FULL 명령 수 | 기존 대비 감소 |
|---|---:|---:|
| 기존 94.7점 버전 | 37655 | — |
| 키 확장 주소 계산만 개선 | 34448 | 8.52% |
| 키 확장 + 일반 MixColumns 개선 (선정) | 32141 | 14.64% |
| 위 변경 + 중간 키 마스크 미리 해제 | 32577 | 13.49% |

서버 제출 횟수를 쓰지 않고 세 후보를 로컬에서 비교했습니다. 세 번째 추가 변경은 더 빠르지 않아 제외했습니다. 이 비교는 실제 하드웨어 클럭 시간이나 서버 성능 순위 보장이 아닙니다.

## 변경 범위
1. 키 확장: 라운드별 이전/현재 키와 워드 포인터를 재사용해 반복 주소 계산을 줄였습니다. masked_different/ masked_same/ masked_remask의 연산 순서와 마스크 보정, Rcon 및 마지막 라운드 키 보정을 유지했습니다.
2. 2~9라운드 전용 MixColumns: 이미 마스크 없는 상태를 처리하는 구간에만 공통 XOR를 재사용하는 수식을 적용했습니다. 첫 라운드의 마스킹 MixColumns는 그대로입니다.
3. 1·10라운드 상태 마스킹·셔플링, lookup_remasked 레지스터 초기화, MSbox 하나, 상태 버퍼 교대, 순열 1회 생성, 행 마스크 전환, 트리거 위치와 난수 호출 방식 유지.
4. 중간 라운드 키는 여전히 사용할 때 마스크를 해제합니다. 키 전체를 미리 비보호 형태로 저장하는 후보는 선정하지 않았습니다.

## 최종 후보 검증
- 독립 AES/출력 별칭/호스트 트리거: 6012건 통과.
- 실제 제출 AVR 객체: 두 모드 각 306건 AES 대조 통과. HEX 구조·체크섬과 lookup_remasked 초기화→로드→재마스킹 확인.
- 독립 GF 기반 키 확장: 1000개 키·마스크 조합의 각 176바이트 일치(0 마스크 포함).
- 중간 상태: 500개 암호화, 14500개 상태의 AES 값·마스크 일치. 순열 1회 생성 및 재사용 확인.
- ASan: 두 모드 각각 3968건 부분 중첩 출력·암호문·canary 검사 통과. UART 파서 재검사는 포함하지 않음.
- 배포 소스 해시가 실제 빌드·검증한 소스와 일치함을 확인.

## 서버 확인
기존과 같은 평가 조건 및 PRNG 입력 2바이트로 비교합니다. 이는 기존 제출 설정이며 공식 사용량 정의를 새롭게 확인했다는 뜻은 아닙니다.
새 결과에서 49710사이클보다 줄었는지, 보안 80점이 유지되는지 확인합니다. 명령 수 14.64% 감소를 실제 사이클·오버헤드·점수에 그대로 적용하지 마세요.
보드가 없어 실제 사이클 제한·최대 스택은 미검증입니다. 보안 80점 유지도 서버 평가 전까지 미확인입니다. 키 확장이나 컴파일러의 레지스터 배치 변화가 누설에 영향을 줄 수 있습니다. 이전 watch-cycles 결과를 하드웨어 사이클로 해석하는 오류는 이번 검증 도구에서 제거했습니다.

## 재빌드
src를 ChipWhisperer firmware/simpleserial-contest에 배치하고 build-support의 공용 simpleserial.c/.h를 적용한 복사본에서 make clean 후 make CONTEST_FULL=0 또는 1을 실행합니다.
tools/verify.py --host --avr --firmware-root <firmware 폴더> --avr-bin <AVR bin 폴더>로 재검증할 수 있습니다. Python/PyCryptodome·MSVC·ChipWhisperer AVR 도구 필요. 심층 검사 스크립트에는 실행한 작업 경로가 들어 있어 이동 시 경로 수정이 필요합니다.
''',encoding='utf-8')
files=[p for p in d.rglob('*') if p.is_file() and p.relative_to(d).parts[0] not in ('phase-check','memory-check','results') and '__pycache__' not in p.parts and p.name!='SHA256.json']
hashes={str(p.relative_to(d)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(d/'SHA256.json').write_text(json.dumps(hashes,indent=2),encoding='utf-8')
zpath=d.parent/'pepsi-fast94.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[d/'SHA256.json']:z.write(p,Path(d.name)/p.relative_to(d))
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 assert all(hashlib.sha256(z.read(d.name+'/'+name)).hexdigest()==h for name,h in hashes.items())
print(zpath)
