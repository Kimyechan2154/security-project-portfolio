from pathlib import Path
import json,re,subprocess
r=Path.cwd();template=(r/'outputs/overhead-analysis/check_precompute.py').read_text()
template=template[template.index('latest=sorted'):].replace('oldcount=42344','oldcount=37655')
results=[]
for name in ('local-keyptr','local-keyptr-mix','local-prekeys'):
 d=r/'outputs'/name
 exec(template)
 results.append({'variant':name,**result})
(r/'outputs/overhead-analysis/daily-comparison.json').write_text(json.dumps(results,indent=2))
