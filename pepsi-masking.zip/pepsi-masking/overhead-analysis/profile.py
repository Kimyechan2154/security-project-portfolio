from pathlib import Path
import re,subprocess,json,collections
r=Path(__file__).resolve().parent;bin=Path('C:/workspace/ChipWhisperer5_64/cw/workspace/avrgcc/bin')
log=(r/'trace.log').read_text(encoding='utf-8-sig');pcs=[int(x,16) for x in re.findall(r'^TRACE ([0-9a-f]+)',log,re.M)]
unique=sorted(set(pcs));lines=subprocess.check_output([str(bin/'avr-addr2line.exe'),'-f','-e',str(r/'probe.elf')]+[hex(pc) for pc in unique]).decode().splitlines()
mapping={pc:(lines[2*i],lines[2*i+1]) for i,pc in enumerate(unique)}
counts=collections.Counter(mapping[pc][0] for pc in pcs);sourcecounts=collections.Counter(mapping[pc][1] for pc in pcs)
dis=(r/'probe.dis').read_text();ins={}
for m in re.finditer(r'^[ \t]*([0-9a-f]+):[ \t]+((?:[0-9a-f]{2}[ \t]+)+)[ \t]*(\w+)[ \t]*(.*)$',dis,re.M):ins[int(m[1],16)]=(m[3],m[4])
mnemonics=collections.Counter(ins[pc][0] for pc in pcs)
result={'instructions':len(pcs),'function_counts':dict(counts.most_common()),'source_line_counts':dict(sourcecounts.most_common()),'mnemonics':dict(mnemonics.most_common())}
(r/'profile.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'instructions':len(pcs),'functions':dict(counts.most_common()),'top_lines':sourcecounts.most_common(15),'mnemonics':mnemonics.most_common(12)},indent=2))

