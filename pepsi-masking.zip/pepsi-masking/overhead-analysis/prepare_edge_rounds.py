from pathlib import Path
import shutil,json,difflib
r=Path(__file__).resolve().parents[1];old=r/'pepsi-precompute';d=r/'pepsi-round1-10'
assert not d.exists()
for folder in ('src','build-support','tools','baseline'):shutil.copytree(old/folder,d/folder)
for name in ('baseline-manifest.json','requirements.txt','config.json'):shutil.copyfile(old/name,d/name)
p=d/'src/myCrypt.c';before=p.read_text();s=before
s=s.replace('    byte columns[4];','    byte columns[4];\n    static const byte fixed_columns[4]={0,1,2,3};')
a=s.index('        for(step=0;step<16;++step) {',s.index('    for(round=0;round<10;++round) {'))
b=s.index('        temporary=in_state;',a)
s=s[:a]+'''        if(round==0 || round==9) {
            for(step=0;step<16;++step) {
                byte row, destination, change;
                i=order[step];
                row=i&3;
                destination=shift_destination[i];
                byte value=masked_add_round_key(in_state[i],round_keys[round][i]);
                change=(round==0)?row_change[row]:0;
                out_state[destination]=lookup_remasked(value,change);
            }
        } else {
            /* Rounds 2..9 deliberately use unmasked state and fixed order.
             * Stored round keys still carry n[row]^m from masked expansion. */
            for(i=0;i<16;++i) {
                byte key=round_keys[round][i]^n[i&3]^m;
                out_state[shift_destination[i]]=aes_sbox[in_state[i]^key];
            }
        }
        /* PHASE_AFTER_SUB_SHIFT */
        if(round<9) {
            mix_columns(out_state,round==0?columns:fixed_columns);
            /* PHASE_AFTER_MIX */
#if !CONTEST_FULL
            if(round==0) trigger_low();
#endif
            /* Enter plain rounds after round 1, re-mask before round 10.
             * These transitions themselves can leak; not a security proof. */
            if(round==0 || round==8)
                for(i=0;i<16;++i) out_state[i]=masked_remask(out_state[i],n[i&3]);
        }
''' +s[b:]
p.write_text(s,encoding='utf-8')
(d/'changes.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='all-rounds/myCrypt.c',tofile='round1-10/myCrypt.c')),encoding='utf-8')
cfg=json.loads((d/'config.json').read_text());cfg['candidate']='state-protection-rounds-1-and-10';(d/'config.json').write_text(json.dumps(cfg,indent=2))
# Adapt the independent phase oracle; observer code is never submitted.
v=(old/'tools/check_phases.py').read_text(encoding='utf-8').replace('pepsi-precompute','pepsi-round1-10')
start=v.index("s=s.replace('    for(round=0;");end=v.index("s='static unsigned",start)
v=v[:start]+'''s=s.replace('    for(round=0;round<10;++round) {','    for(round=0;round<10;++round) {\\n        {byte mask[16];for(i=0;i<16;++i)mask[i]=(round==0 || round==9)?n[i&3]:0;observe(round,0,in_state,mask);}')
s=s.replace('        /* PHASE_AFTER_SUB_SHIFT */','        {byte rows[4]={row_mask0,row_mask1,row_mask2,row_mask3},mask[16];for(i=0;i<16;++i)mask[i]=(round==0)?rows[i&3]:(round==9?key_output_mask:0);observe(round,2,out_state,mask);}')
s=s.replace('            /* PHASE_AFTER_MIX */','            {byte mask[16];for(i=0;i<16;++i)mask[i]=(round==0)?n[i&3]:0;observe(round,4,out_state,mask);}')
''' +v[end:]
v=v.replace("'before ARK / fused SB-SR under row masks (final mp) / after MC under n[row]'","'before ARK / after SB-SR / after MC; masks checked at protected-to-plain and plain-to-protected boundaries'")
(d/'tools/check_phases.py').write_text(v,encoding='utf-8')
(d/'phase-check').mkdir();shutil.copyfile(d/'src/myCrypt.h',d/'phase-check/myCrypt.h');(d/'phase-check/hal.h').write_text('void trigger_high(void);void trigger_low(void);')
print(d)
