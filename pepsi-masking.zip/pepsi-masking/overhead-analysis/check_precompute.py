from pathlib import Path
import shutil,subprocess,os,re,json
r=Path.cwd();d=r/'outputs/pepsi-precompute';b=d/'phase-check';b.mkdir(exist_ok=True)
shutil.copyfile(d/'src/myCrypt.h',b/'myCrypt.h');(b/'hal.h').write_text('void trigger_high(void);void trigger_low(void);')
s=(r/'outputs/pepsi-order-reuse/candidate-evidence/reuse_phases.py').read_text(encoding='utf-8')
s=s.replace("r/'work/reuse-check'","r/'outputs/pepsi-precompute/phase-check'").replace("r/'outputs/pepsi-order-reuse/src/myCrypt.c'","r/'outputs/pepsi-precompute/src/myCrypt.c'")
s=s.replace('mix_columns(out_state,order);','mix_columns(out_state,columns);')
(d/'tools/check_phases.py').write_text(s,encoding='utf-8')
env=os.environ.copy();env['PYTHONUTF8']='1';subprocess.run(['python',str(d/'tools/check_phases.py')],check=True,env=env)
latest=sorted((d/'results').iterdir())[-1];assert json.loads((latest/'report.json').read_text())['status']=='PASS'
dis=(latest/'probe-FULL.dis').read_text();high=re.search(r'^\s*([0-9a-f]+):.*sts\s+0x0605',dis,re.M).group(1);low=re.search(r'^\s*([0-9a-f]+):.*sts\s+0x0606',dis,re.M).group(1)
commands=f'''set pagination off
set confirm off
target sim
load
break Encrypt
run
set {{unsigned long}}&prng_state=1
break *0x{high}
continue
set $n=(unsigned long)0
while $pc != 0x{low} && $n < 200000
stepi
set $n=$n+1
end
printf "INSTRUCTIONS %lu\\n", $n
quit
'''
(latest/'trace.gdb').write_text(commands)
bin=Path('C:/workspace/ChipWhisperer5_64/cw/workspace/avrgcc/bin')
p=subprocess.run([str(bin/'avr-gdb.exe'),'--batch','-x','trace.gdb','avr-probe/mode1.elf'],cwd=latest,capture_output=True,text=True,errors='replace',timeout=120)
(latest/'instruction-trace.log').write_text(p.stdout+p.stderr);assert p.returncode==0
count=int(re.search(r'INSTRUCTIONS (\d+)',p.stdout).group(1));assert count<200000
oldcount=42344
result={'baseline_instructions':oldcount,'candidate_instructions':count,'reduction_percent':round((oldcount-count)*100/oldcount,2),'units':'executed instructions, NOT hardware clock cycles','sample':'NIST first vector, PRNG state 1, simulated timer 0','hardware_cycles':'NOT_MEASURED','server_security':'NOT_EVALUATED'}
(latest/'instruction-comparison.json').write_text(json.dumps(result,indent=2));print(result)
