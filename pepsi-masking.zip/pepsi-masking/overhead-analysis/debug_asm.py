from pathlib import Path
import subprocess,re,json
r=Path(__file__).resolve().parents[2];d=r/'outputs/pepsi-asm';t=sorted((d/'results').iterdir())[-1]
b=Path('C:/workspace/ChipWhisperer5_64/cw/workspace/avrgcc/bin')
cmd='''set pagination off
set confirm off
target sim
load
break sub_shift
run
dump binary memory keys.bin (char*)&round_keys (char*)&round_keys+176
dump binary memory masks.bin (char*)&masks (char*)&masks+18
dump binary memory states.bin (char*)&state_a (char*)&state_b+16
dump binary memory sbox.bin (char*)&key_sbox (char*)&key_sbox+256
dump binary memory order.bin (char*)&order (char*)&order+20
info registers r2 r3 r4 r5 r6 r7 r8 r9 r10 r11 r12 r13 r14 r1
break mix_columns
continue
dump binary memory sub.bin (char*)&state_b (char*)&state_b+16
quit
'''
(t/'debug.gdb').write_text(cmd)
p=subprocess.run([str(b/'avr-gdb.exe'),'--batch','-x','debug.gdb','avr-probe/mode0.elf'],cwd=t,capture_output=True,text=True,timeout=60)
print(p.stdout,p.stderr)
for name in ('keys','masks','states','order','sub'):print(name,(t/f'{name}.bin').read_bytes().hex())
