from pathlib import Path
import subprocess,re,json
r=Path.cwd();d=r/'outputs/pepsi-round1-10'
s=(r/'outputs/overhead-analysis/check_precompute.py').read_text()
s=s[s.index('latest=sorted'):].replace('oldcount=42344','oldcount=39057')
exec(s)
