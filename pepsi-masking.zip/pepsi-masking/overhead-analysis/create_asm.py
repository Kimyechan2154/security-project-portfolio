from pathlib import Path
import shutil,re,json,hashlib
root=Path(__file__).resolve().parents[2]
old=root/'outputs/pepsi-ghmask'; new=root/'outputs/pepsi-asm'
new.mkdir(exist_ok=True)
for name in ('src','tools','build-support','origin'):
    (new/name).mkdir(exist_ok=True)
for name in ('myCrypt.h','simpleserial-contest.c'):
    shutil.copyfile(old/'src'/name,new/'src'/name)
for p in (old/'build-support').iterdir():shutil.copyfile(p,new/'build-support'/p.name)
for name in ('verify.py','avr_test_template.c'):shutil.copyfile(old/'tools'/name,new/'tools'/name)
for name in ('config.json','requirements.txt'):shutil.copyfile(old/name,new/name)
baseline=new/'baseline';baseline.mkdir(exist_ok=True)
for p in (old/'src').iterdir():shutil.copyfile(p,baseline/p.name)
for p in old.glob('*.hex'):shutil.copyfile(p,baseline/p.name)
(new/'baseline-manifest.json').write_text(json.dumps({str(p.relative_to(new)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in baseline.iterdir()},indent=2))
shutil.copyfile(old/'src/myCrypt.c',new/'origin/reference.c')
(new/'src/makefile').write_text('''CONTEST_FULL ?= 0
CFLAGS += -DCONTEST_FULL=$(CONTEST_FULL)
ADEFS += -DCONTEST_FULL=$(CONTEST_FULL)
TARGET = simpleserial-contest
SRC += simpleserial-contest.c
ASRC += masked_aes.S
PLATFORM = CWLITEXMEGA
CRYPTO_TARGET = NONE
SS_VER = SS_VER_2_1
include ../simpleserial/Makefile.simpleserial
FIRMWAREPATH = ../.
include $(FIRMWAREPATH)/Makefile.inc
''')
sbox=re.search(r'aes_sbox\[256\] = \{(.*?)\};',(old/'src/myCrypt.c').read_text(),re.S).group(1)
values=re.findall(r'0x[0-9a-f]+',sbox)
s=r'''/* Hand-written GNU AVR assembly AES-128 core, ATxmega128D3.
 * Algorithm/mask flow ported from baseline/myCrypt.c (ghmask).
 * C is used only for the UART/HAL adapter, not any cryptographic routine.
 * One static workspace: non-reentrant, like the shared MSbox baseline.
 * Exported routines obey AVR-GCC ABI; r1 is zero on return.
 * Private routines may clobber r0,r16..r31 and SREG as documented below.
 * Encrypt reserves r2:r3=PT, r4:r5=KEY, r6:r7=out;
 * r8:r9=input, r10:r11=output, r12:r13=round key, r14=round.
 * Masks: m=input, mp=S-box output, rows[4], n=MixColumns(rows), q=n^m.
 * State n -> AddRoundKey m -> MSbox mp -> ShiftRows rows -> MixColumns n.
 * Final ShiftRows keeps mp; final round key also carries mp.
 * No assertion of physical leakage resistance or entropy quality.
 */
#include <avr/io.h>
#ifndef CONTEST_FULL
#define CONTEST_FULL 0
#endif
/* Assembly-owned .data/.bss need the AVR CRT initializers explicitly. */
.global __do_copy_data
.global __do_clear_bss
.section .data
.global prng_state
.type prng_state,@object
prng_state: .long 0x6d2b79f5
.size prng_state,4
aes_sbox:
__SBOX__
shift_destination: .byte 0,13,10,7,4,1,14,11,8,5,2,15,12,9,6,3
threshold: .byte 0,0,1,0,1,4,4,0,4,6,3,4,9,4,1,0
.section .bss
.global asm_workspace_start, asm_workspace_end
asm_workspace_start:
.global key_sbox, masks, n_masks, q_masks, row_change, round_keys, order, columns, state_a, state_b
key_sbox: .skip 256
masks: .skip 6
n_masks: .skip 4
q_masks: .skip 4
row_change: .skip 4
round_keys: .skip 176
order: .skip 16
columns: .skip 4
state_a: .skip 16
state_b: .skip 16
asm_workspace_end:
.section .text
.macro PTR lo,hi,sym
    ldi \lo,lo8(\sym)
    ldi \hi,hi8(\sym)
.endm
.macro TRIGGER_HIGH
    ldi r18,1
    sts _SFR_MEM_ADDR(PORTA_OUTSET),r18
.endm
.macro TRIGGER_LOW
    ldi r18,1
    sts _SFR_MEM_ADDR(PORTA_OUTCLR),r18
.endm
/* Constant instruction count xtime; destroys r0,r27. */
.macro XTIME value
    lsl \value
    sbc r0,r0
    ldi r27,0x1b
    and r0,r27
    eor \value,r0
.endm
.global ContestRandomInit
.type ContestRandomInit,@function
ContestRandomInit:
    sts _SFR_MEM_ADDR(TCC0_CTRLA),r1
    sts _SFR_MEM_ADDR(TCC0_CTRLB),r1
    ldi r24,0xff
    sts _SFR_MEM_ADDR(TCC0_PER),r24
    sts _SFR_MEM_ADDR(TCC0_PER)+1,r24
    sts _SFR_MEM_ADDR(TCC0_CNT),r1
    sts _SFR_MEM_ADDR(TCC0_CNT)+1,r1
    ldi r24,1
    sts _SFR_MEM_ADDR(TCC0_CTRLA),r24
    ret
.size ContestRandomInit,.-ContestRandomInit

/* Xorshift32(13,17,5), returns high byte in r24.
 * Destroys r18..r26 only; preserves X high, Y, Z, r16,r17. */
.type random_byte,@function
random_byte:
    lds r18,prng_state
    lds r19,prng_state+1
    lds r20,prng_state+2
    lds r21,prng_state+3
    clr r22
    mov r23,r18
    mov r24,r19
    mov r25,r20
    ldi r26,5
1:  lsl r22
    rol r23
    rol r24
    rol r25
    dec r26
    brne 1b
    eor r18,r22
    eor r19,r23
    eor r20,r24
    eor r21,r25
    mov r22,r20
    mov r23,r21
    lsr r23
    ror r22
    eor r18,r22
    eor r19,r23
    movw r22,r18
    movw r24,r20
    ldi r26,5
2:  lsl r22
    rol r23
    rol r24
    rol r25
    dec r26
    brne 2b
    eor r18,r22
    eor r19,r23
    eor r20,r24
    eor r21,r25
    sts prng_state,r18
    sts prng_state+1,r19
    sts prng_state+2,r20
    sts prng_state+3,r21
    mov r24,r21
    ret
.size random_byte,.-random_byte

/* Read the same 16-bit timer once per block; no verified entropy claim. */
.type refresh_timing_seed,@function
refresh_timing_seed:
    lds r24,_SFR_MEM_ADDR(TCC0_CNT)
    lds r25,_SFR_MEM_ADDR(TCC0_CNT)+1
    lds r18,prng_state
    lds r19,prng_state+1
    lds r20,prng_state+2
    lds r21,prng_state+3
    eor r18,r24
    eor r19,r25
    eor r20,r24
    eor r21,r25
    mov r22,r18
    or r22,r19
    or r22,r20
    or r22,r21
    brne 1f
    ldi r18,0xf5
    ldi r19,0x79
    ldi r20,0x2b
    ldi r21,0x6d
1:  sts prng_state,r18
    sts prng_state+1,r19
    sts prng_state+2,r20
    sts prng_state+3,r21
    ret
.size refresh_timing_seed,.-refresh_timing_seed

/* Z -> one column, in place; preserves Z,Y,r17 and all r2..r15.
 * Explicit original 2*a ^ 3*b ^ c ^ d expressions, no unmasking. */
.type mix_one,@function
mix_one:
    ld r18,Z
    ldd r19,Z+1
    ldd r20,Z+2
    ldd r21,Z+3
    mov r23,r18
    mov r24,r19
    mov r25,r20
    mov r26,r21
    XTIME r23
    XTIME r24
    XTIME r25
    XTIME r26
    mov r16,r24
    eor r16,r19
    eor r16,r23
    eor r16,r20
    eor r16,r21
    st Z,r16
    mov r16,r25
    eor r16,r20
    eor r16,r18
    eor r16,r24
    eor r16,r21
    std Z+1,r16
    mov r16,r26
    eor r16,r21
    eor r16,r18
    eor r16,r19
    eor r16,r25
    std Z+2,r16
    mov r16,r23
    eor r16,r18
    eor r16,r19
    eor r16,r20
    eor r16,r26
    std Z+3,r16
    ret
.size mix_one,.-mix_one

/* index r24, correction r22 -> value r24. Clobbers Z.
 * Keep CLR immediately before LD; do not reuse a live lookup output. */
.global lookup_remasked
.type lookup_remasked,@function
lookup_remasked:
    PTR r30,r31,key_sbox
    add r30,r24
    adc r31,r1
    clr r24
    ld r24,Z
    eor r24,r22
    ret
.size lookup_remasked,.-lookup_remasked

/* Key first word: previous=q, S-box=mp -> new=q (or mp in round 10).
 * Preserves key counter r16, Rcon r17, previous pointer Y. */
.macro KEY_FIRST row,source,source_row,final=0
    ldd r24,Y+\source
    lds r22,n_masks+\source_row
    eor r24,r22
    PTR r30,r31,key_sbox
    add r30,r24
    adc r31,r1
    clr r20
    ld r20,Z
    ldd r18,Y+\row
    lds r21,masks+1
    eor r18,r20
    eor r18,r21
    .if \final
        lds r22,q_masks+\row
        eor r22,r21
        eor r18,r22
    .endif
    .if \row == 0
        eor r18,r17
    .endif
    std Y+(16+\row),r18
.endm
/* Masked same-row XOR: change=q^guard, b^change, a^b, a^guard.
 * Never simplify to a raw-key XOR followed by remasking. */
.macro KEY_NEXT pos,row
    ldd r18,Y+\pos
    ldd r19,Y+(12+\pos)
    lds r20,q_masks+\row
    lds r21,masks+(2+\row)
    eor r20,r21
    eor r19,r20
    eor r18,r19
    eor r18,r21
    std Y+(16+\pos),r18
.endm
.macro KEY_ROUND final=0
    KEY_FIRST 0,13,1,\final
    KEY_FIRST 1,14,2,\final
    KEY_FIRST 2,15,3,\final
    KEY_FIRST 3,12,0,\final
    KEY_NEXT 4,0
    KEY_NEXT 5,1
    KEY_NEXT 6,2
    KEY_NEXT 7,3
    KEY_NEXT 8,0
    KEY_NEXT 9,1
    KEY_NEXT 10,2
    KEY_NEXT 11,3
    KEY_NEXT 12,0
    KEY_NEXT 13,1
    KEY_NEXT 14,2
    KEY_NEXT 15,3
.endm
.type expand_keys,@function
expand_keys:
    movw r26,r4
    PTR r28,r29,round_keys
    .set k,0
    .rept 16
        ld r18,X+
        lds r19,q_masks+(k%4)
        eor r18,r19
        std Y+k,r18
        .set k,k+1
    .endr
    ldi r16,9
    ldi r17,1
1:  KEY_ROUND 0
    adiw r28,16
    XTIME r17
    dec r16
    breq 2f
    rjmp 1b
2:  KEY_ROUND 1
    ret
.size expand_keys,.-expand_keys

.type make_permutation,@function
make_permutation:
    PTR r28,r29,order
    clr r16
1:  st Y+,r16
    inc r16
    cpi r16,16
    brne 1b
    ldi r16,15
2:  PTR r30,r31,threshold
    add r30,r16
    adc r31,r1
    ld r17,Z
3:  call random_byte
    mov r18,r16
    inc r18
    mul r24,r18
    mov r19,r1
    clr r1
    cp r0,r17
    brlo 3b
    PTR r26,r27,order
    PTR r30,r31,order
    add r26,r16
    adc r27,r1
    add r30,r19
    adc r31,r1
    ld r20,X
    ld r21,Z
    st X,r21
    st Z,r20
    dec r16
    brne 2b
    /* First appearances order[i]&3, no extra random bytes. */
    PTR r26,r27,order
    PTR r28,r29,columns
    clr r17
    ldi r20,4
4:  ld r18,X+
    andi r18,3
    mov r21,r18
    ldi r19,1
5:  tst r21
    breq 6f
    lsl r19
    dec r21
    rjmp 5b
6:  mov r22,r17
    and r22,r19
    brne 4b
    or r17,r19
    st Y+,r18
    dec r20
    brne 4b
    ret
.size make_permutation,.-make_permutation

/* Six random masks, one MSbox, then derived row-mask corrections. */
.type prepare_masks,@function
prepare_masks:
    PTR r28,r29,masks
    ldi r16,6
1:  call random_byte
    st Y+,r24
    dec r16
    brne 1b
    lds r16,masks
    lds r17,masks+1
    PTR r26,r27,aes_sbox
    clr r18
2:  ld r19,X+
    eor r19,r17
    mov r20,r18
    eor r20,r16
    PTR r30,r31,key_sbox
    add r30,r20
    adc r31,r1
    st Z,r19
    inc r18
    brne 2b
    .set row,0
    .rept 4
        lds r18,masks+2+row
        sts n_masks+row,r18
        .set row,row+1
    .endr
    PTR r30,r31,n_masks
    call mix_one
    lds r16,masks
    lds r17,masks+1
    .set row,0
    .rept 4
        lds r18,n_masks+row
        eor r18,r16
        sts q_masks+row,r18
        lds r18,masks+2+row
        eor r18,r17
        sts row_change+row,r18
        .set row,row+1
    .endr
    ret
.size prepare_masks,.-prepare_masks

/* Fully expanded 16 operations, in existing random order.
 * r8:r9 input, r10:r11 output, r12:r13 key. No ShiftRows copy loop. */
.macro SUB_SHIFT pos,final=0
    lds r18,order+\pos
    movw r30,r8
    add r30,r18
    adc r31,r1
    ld r24,Z
    movw r30,r12
    add r30,r18
    adc r31,r1
    ld r20,Z
    eor r24,r20
    .if \final
        clr r22
    .else
        mov r21,r18
        andi r21,3
        PTR r30,r31,row_change
        add r30,r21
        adc r31,r1
        ld r22,Z
    .endif
    call lookup_remasked
    PTR r30,r31,shift_destination
    add r30,r18
    adc r31,r1
    ld r25,Z
    movw r30,r10
    add r30,r25
    adc r31,r1
    st Z,r24
.endm
.type sub_shift,@function
sub_shift:
    .set pos,0
    .rept 16
        SUB_SHIFT pos,0
        .set pos,pos+1
    .endr
    ret
.size sub_shift,.-sub_shift
.type sub_shift_final,@function
sub_shift_final:
    .set pos,0
    .rept 16
        SUB_SHIFT pos,1
        .set pos,pos+1
    .endr
    ret
.size sub_shift_final,.-sub_shift_final
.type mix_columns,@function
mix_columns:
    .set col,0
    .rept 4
        lds r18,columns+col
        lsl r18
        lsl r18
        movw r30,r10
        add r30,r18
        adc r31,r1
        call mix_one
        .set col,col+1
    .endr
    ret
.size mix_columns,.-mix_columns

.global Encrypt
.type Encrypt,@function
Encrypt:
__PUSH__
    movw r2,r24
    movw r4,r22
    movw r6,r20
#if CONTEST_FULL
    TRIGGER_HIGH
#endif
    call refresh_timing_seed
    call prepare_masks
    call expand_keys
    call make_permutation
    movw r26,r2
    .set pos,0
    .rept 16
        ld r18,X+
        lds r19,n_masks+(pos%4)
        eor r18,r19
        sts state_a+pos,r18
        sts state_b+pos,r1
        .set pos,pos+1
    .endr
    PTR r24,r25,state_a
    movw r8,r24
    PTR r24,r25,state_b
    movw r10,r24
    PTR r24,r25,round_keys
    movw r12,r24
#if !CONTEST_FULL
    TRIGGER_HIGH
#endif
    call sub_shift
    call mix_columns
#if !CONTEST_FULL
    TRIGGER_LOW
#endif
    ldi r18,8
    mov r14,r18
1:  movw r24,r8
    movw r8,r10
    movw r10,r24
    ldi r18,16
    add r12,r18
    adc r13,r1
    call sub_shift
    call mix_columns
    dec r14
    brne 1b
    movw r24,r8
    movw r8,r10
    movw r10,r24
    ldi r18,16
    add r12,r18
    adc r13,r1
    call sub_shift_final
    PTR r28,r29,order
    ldi r16,16
    lds r17,masks+1
2:  ld r18,Y+
    movw r30,r10
    add r30,r18
    adc r31,r1
    ld r19,Z
    PTR r30,r31,round_keys+160
    add r30,r18
    adc r31,r1
    ld r20,Z
    eor r19,r20
    eor r19,r17
    eor r19,r17
    movw r30,r6
    add r30,r18
    adc r31,r1
    st Z,r19
    dec r16
    brne 2b
#if CONTEST_FULL
    TRIGGER_LOW
#endif
__POP__
    ret
.size Encrypt,.-Encrypt
'''
s=s.replace('__SBOX__','\n'.join('    .byte '+','.join(values[i:i+16]) for i in range(0,256,16)))
regs=list(range(2,18))+[28,29]
s=s.replace('__PUSH__','\n'.join(f'    push r{i}' for i in regs)).replace('__POP__','\n'.join(f'    pop r{i}' for i in reversed(regs)))
(new/'src/masked_aes.S').write_text(s)
v=(new/'tools/verify.py').read_text()
v=v.replace("obj=cwd/'objdir-CWLITEXMEGA/myCrypt.o'","obj=cwd/'objdir-CWLITEXMEGA/masked_aes.o'")
v=v.replace("report['host']={'status':'PASS','AES_alias_trigger_cases':cases}","report['host']={'status':'PASS','AES_alias_trigger_cases':cases}")
# No host-C fallback: the assembler is exercised by the actual AVR object.
v=v.replace("args=ap.parse_args();cfg=", "args=ap.parse_args();\n    if args.host:ap.error('Assembly has no host implementation; use --avr')\n    cfg=")
(new/'tools/verify.py').write_text(v)
print(new)
