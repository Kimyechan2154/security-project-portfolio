from pathlib import Path
import shutil,json,difflib
r=Path(__file__).resolve().parents[1];base=r/'pepsi-round1-10';original=(base/'src/myCrypt.c').read_text()
a=original.index('    byte row, word, round;',original.index('static void expand_masked_key'));b=original.index('\n}\n/* Shared S-box',a)
ptr='''    byte row, word, round;
    for (word=0; word<4; ++word)
        for (row=0; row<4; ++row)
            round_keys[0][4*word+row] = key[4*word+row] ^ q[row];
    for (round=1; round<=10; ++round) {
        const byte *previous=round_keys[round-1];
        byte *current=round_keys[round];
        for(row=0;row<4;++row) {
            byte rotated=(byte)((row+1)&3);
            byte index=previous[12+rotated]^n[rotated];
            byte g=key_sbox[index];
            byte v=masked_different(previous[row],g,output_mask);
            current[row]=v^(row==0?round_constants[round-1]:0);
        }
        for(word=1;word<4;++word) {
            const byte *previous_word=previous+4*word;
            byte *current_word=current+4*word;
            for(row=0;row<4;++row)
                current_word[row]=masked_same(previous_word[row],current_word[row-4],q[row],guard[row]);
        }
    }
    /* Final-round key still carries output_mask. */
    for(word=0;word<16;++word)
        round_keys[10][word]=masked_remask(round_keys[10][word],q[word&3]^output_mask);
'''
# row is promoted to int for row-4; pointers stay in the same 16-byte row.
sa=original[:a]+ptr+original[b:]
plain='''/* This algebraic shortcut is used ONLY for unmasked middle rounds. */
static void mix_columns_plain(byte state[16])
{
    byte col;
    for(col=0;col<4;++col) {
        byte *s=state+4*col;
        byte a=s[0], b=s[1], c=s[2], d=s[3];
        byte sum=a^b^c^d;
        s[0]=a^sum^xtime(a^b);
        s[1]=b^sum^xtime(b^c);
        s[2]=c^sum^xtime(c^d);
        s[3]=d^sum^xtime(d^a);
    }
}
'''
sb=sa.replace('void Encrypt(unsigned char* PT',plain+'void Encrypt(unsigned char* PT')
sb=sb.replace('    static const byte fixed_columns[4]={0,1,2,3};\n','')
sb=sb.replace('            mix_columns(out_state,round==0?columns:fixed_columns);','            if(round==0) mix_columns(out_state,columns);\n            else mix_columns_plain(out_state);')
sc=sb.replace('    random_permutation(order);','''    /* Only the already-unprotected middle round keys are unmasked here. */
    for(round=1;round<9;++round)
        for(i=0;i<16;++i) round_keys[round][i]^=n[i&3]^m;
    random_permutation(order);''')
sc=sc.replace('byte key=round_keys[round][i]^n[i&3]^m;','byte key=round_keys[round][i];').replace('Stored round keys still carry n[row]^m from masked expansion.','Middle round keys were unmasked during preparation.')
for label,s in [('keyptr',sa),('keyptr-mix',sb),('keyptr-mix-keys',sc)]:
 d=r/f'local-{label}';assert not d.exists()
 for f in ('src','build-support','tools','baseline'):shutil.copytree(base/f,d/f)
 for f in ('baseline-manifest.json','config.json','requirements.txt'):shutil.copyfile(base/f,d/f)
 (d/'src/myCrypt.c').write_text(s,encoding='utf-8')
 (d/'changes.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='94.7-baseline',tofile=label)),encoding='utf-8')
 print(d)
