from pathlib import Path
import shutil,json,difflib
r=Path(__file__).resolve().parents[1];old=r/'pepsi-order-reuse';new=r/'pepsi-precompute'
assert not new.exists()
for folder in ('src','build-support','tools','baseline'):shutil.copytree(old/folder,new/folder)
for name in ('baseline-manifest.json','requirements.txt','config.json'):shutil.copyfile(old/name,new/name)
p=new/'src/myCrypt.c';before=p.read_text();s=before
s=s.replace('static void mix_columns(byte state[16], const byte order[16]) {','static void mix_columns(byte state[16], const byte columns[4]) {')
s=s.replace('byte columns[4], step;\n    column_order(order,columns);','byte step;')
s=s.replace('round_keys[11][16], order[16];','round_keys[11][16], order[16];\n    byte columns[4], destinations[16];')
s=s.replace('    random_permutation(order);','''    random_permutation(order);
    /* Public index schedules: one preparation per encryption, no new RNG. */
    column_order(order,columns);
    for(step=0;step<16;++step) {
        i=order[step];
        destinations[step]=(byte)(4*((((i>>2)+4-(i&3))&3))+(i&3));
    }''')
s=s.replace('destination=(byte)(4*((((i>>2)+4-row)&3))+row);','destination=destinations[step];')
s=s.replace('mix_columns(out_state,order);','mix_columns(out_state,columns);')
assert s.count('column_order(order,columns);')==1 and s.count('random_permutation(order);')==1
p.write_text(s,encoding='utf-8')
(new/'changes.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='order-reuse/myCrypt.c',tofile='precompute/myCrypt.c')),encoding='utf-8')
p=new/'tools/verify.py';s=p.read_text();a=s.index('                budgets=[];limit=');b=s.index('                size=run(',a);s=s[:a]+"                budgets=[] # watch-cycles measures event ticks, not AVR clock cycles.\n"+s[b:]
s=s.replace("'cycle_samples':budgets","'hardware_cycle_limit':'NOT_VERIFIED'")
s=s.replace(' / cycle samples: PASS',': PASS (hardware cycles not verified)')
s=s.replace('simulator samples, not a worst-case proof','NOT_MEASURED: simulator event ticks are not AVR clock cycles')
p.write_text(s,encoding='utf-8')
cfg=json.loads((new/'config.json').read_text());cfg['candidate']='precompute-column-order-and-destinations';(new/'config.json').write_text(json.dumps(cfg,indent=2))
print(new)
