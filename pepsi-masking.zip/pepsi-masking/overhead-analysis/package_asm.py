from pathlib import Path
import shutil,json,hashlib,zipfile
r=Path(__file__).resolve().parents[2];d=r/'outputs/pepsi-asm'
t=sorted((d/'results').iterdir())[-1]
report=json.loads((t/'report.json').read_text()); extra=json.loads((t/'assembly-check/report.json').read_text())
assert report['status']==extra['status']=='PASS'
for name,h in report['source_sha256'].items():assert hashlib.sha256((d/'src'/name).read_bytes()).hexdigest()==h
v=d/'verification';v.mkdir(exist_ok=True)
for mode in ('ROUND1','FULL'):
    shutil.copyfile(t/f'{mode}.hex',d/f'pepsi-asm-{mode}.hex')
    for name in (f'{mode}.dis',f'size-{mode}.log',f'build-{mode}.log',f'probe-AES-{mode}.log',f'probe-{mode}.dis'):
        shutil.copyfile(t/name,v/name)
    shutil.copyfile(t/f'avr-probe/production-core-{mode}.o',v/f'production-core-{mode}.o')
    shutil.copyfile(t/f'assembly-check/equivalence-{mode}.log',v/f'equivalence-{mode}.log')
shutil.copyfile(t/'report.json',v/'report.json')
shutil.copyfile(t/'assembly-check/report.json',v/'assembly-report.json')
shutil.copyfile(r/'outputs/pepsi-ghmask/verification/instruction-comparison.json',v/'baseline-instructions.json')
for name in ('abi.S','equivalence.c','reference.c'):
    shutil.copyfile(t/'assembly-check'/name,v/name)
cfg=json.loads((d/'config.json').read_text());cfg.update(baseline='pepsi-ghmask',candidate='hand-written-avr-assembly',server_security='unverified',hardware_cycle_limit='not_verified')
(d/'config.json').write_text(json.dumps(cfg,indent=2))
(d/'README.md').write_text('''# PEPSI AVR 어셈블리 제출 후보

AES 핵심 전체를 직접 작성한 GNU AVR 어셈블리 `src/masked_aes.S`로 구현했습니다.
C로 남긴 부분은 SimpleSerial 통신과 ChipWhisperer HAL 어댑터입니다.
제출 빌드에는 기존 C AES 구현이 링크되지 않습니다.

## 제출 파일

| 제출 칸 | 파일 |
|---|---|
| 1라운드 HEX | pepsi-asm-ROUND1.hex |
| 전체 암호화 HEX | pepsi-asm-FULL.hex |

대상: CWLITEXMEGA / ATxmega128D3 / SimpleSerial 2.1.
기존 C 소스와 HEX는 baseline/에 보존했습니다. 기존 pepsi-ghmask 폴더도 변경하지 않았습니다.

## 유지한 동작

- 모든 라운드 마스킹, MSbox 하나, 두 상태 버퍼 교대.
- SubBytes·ShiftRows를 합친 16개 연산을 어셈블러 매크로로 펼침. 별도 복사 루프 없음.
- 암호화마다 순열 한 번 생성, 라운드에서 재사용. 첫 등장 order[i]&3 열 순서로 MixColumns 처리.
- 행 마스크와 사전 계산한 보정값 사용. 1~9라운드 및 마지막 키 확장을 별도로 구현.
- lookup_remasked에서 CLR → LD → EOR 순서 유지. 키 확장도 마스크 보정 순서 유지.
- 난수 생성, 타이머 초기화·시드 혼합, 셔플링, 키 확장, 암호화 모두 어셈블리 구현.
- FULL은 난수/마스크/키 준비부터 출력까지, ROUND1은 첫 SubBytes·ShiftRows와 MixColumns만 트리거에 포함.

상태와 키는 정적 작업 공간을 사용하므로 동시 호출/중첩 호출용 구현이 아닙니다.
기존 xorshift32와 타이머 16비트 혼합 동작을 유지했습니다. 타이머 표본 2바이트는 엔트로피 2바이트 보장을 뜻하지 않습니다.
PRNG 사용량 입력의 공식 산정 기준은 여전히 확인되지 않았습니다.

## 검증 결과

- 실제 제출 빌드의 어셈블리 객체로 PyCryptodome AES 대조: 102개 벡터 × 3가지 입출력 배치 × 2빌드 = 612건 통과.
- 같은 제출 객체로 기존 C 구현과 동등성/AVR ABI/버퍼 겹침 검사: 688건 × 2빌드 = 1,376건 통과.
- 암호문 외에도 PRNG 최종 상태, MSbox 256바이트, 마스크, 키 176바이트, 순열·열 순서, 두 최종 상태 버퍼를 비교.
- 호출 후 보존 레지스터 및 r1=0 확인. 출력이 입력/키와 부분적으로 겹치는 배치와 주변 메모리 확인.
- HEX 체크섬, 두 빌드, 조회 레지스터 초기화 검사 통과.
- 동일 NIST 입력/초기 PRNG=1/시뮬레이터 타이머=0에서 FULL 실행 명령 수 25,666 → 15,457 (약 39.8% 감소). ROUND1은 806개.

위 숫자는 실행 명령 수이며 AVR 클럭 사이클이 아닙니다. 실물 사이클 제한 통과, 서버 오버헤드와 보안 점수는 미확인입니다.
기존 C 버전의 평가 점수를 이 버전에 그대로 적용할 수 없습니다. 새 HEX로 서버 평가가 필요합니다.

## 재검증

Python에 requirements.txt 의존성을 설치한 후 패키지 폴더에서 실행합니다.
`verify.py`는 설치된 ChipWhisperer 펌웨어를 별도 results/ 아래로 복사해 빌드하며 설치 원본을 수정하지 않습니다.

```powershell
python tools/verify.py --avr --firmware-root "C:/workspace/ChipWhisperer5_64/cw/workspace/chipwhisperer/hardware/victims/firmware" --avr-bin "C:/workspace/ChipWhisperer5_64/cw/workspace/avrgcc/bin"
python tools/verify_assembly.py --avr-bin "C:/workspace/ChipWhisperer5_64/cw/workspace/avrgcc/bin"
```

verification/에 검증 보고서·제출 빌드 로그·역어셈블·원본 객체를 보관했습니다.
origin/reference.c는 대조용 이전 C 구현이며 제출에 사용하지 않습니다.
기반 마스킹 수식의 출처는 Kimyechan2154/school PEPSI/Masking/masking.c,
Git blob 54e1cc7ce8927b1a2620e2c7f98b90f555f62209입니다.
''',encoding='utf-8')
files=[p for p in d.rglob('*') if p.is_file() and 'results' not in p.relative_to(d).parts and p.name!='SHA256.json']
manifest={p.relative_to(d).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(d/'SHA256.json').write_text(json.dumps(manifest,indent=2))
archive=d.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files+[d/'SHA256.json']:z.write(p,Path(d.name)/p.relative_to(d))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,h in manifest.items():assert hashlib.sha256(z.read(d.name+'/'+name)).hexdigest()==h
print(json.dumps({'zip':str(archive),'bytes':archive.stat().st_size,'files':len(files)+1,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},indent=2))
