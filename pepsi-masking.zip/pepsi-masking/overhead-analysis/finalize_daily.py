from pathlib import Path
import shutil,subprocess,json,hashlib,zipfile,os
r=Path.cwd();base=r/'outputs/pepsi-round1-10';selected=r/'outputs/local-keyptr-mix';d=r/'outputs/pepsi-fast94'
assert not d.exists()
for folder in ('src','build-support','tools'):shutil.copytree(selected/folder,d/folder)
for f in ('requirements.txt','changes.diff'):shutil.copyfile(selected/f,d/f)
cfg=json.loads((selected/'config.json').read_text());cfg['baseline']='pepsi-round1-10 (server 94.7)';cfg['candidate']='key-pointer-and-plain-middle-MixColumns';(d/'config.json').write_text(json.dumps(cfg,indent=2))
shutil.copytree(base/'src',d/'baseline/src');shutil.copytree(base/'build-support',d/'baseline/build-support')
for label in ('ROUND1','FULL'):shutil.copyfile(base/f'pepsi-round1-10-{label}.hex',d/'baseline'/f'pepsi-round1-10-{label}.hex')
latest=sorted((selected/'results').iterdir())[-1];rep=json.loads((latest/'report.json').read_text());assert rep['status']=='PASS'
ev=d/'verification';ev.mkdir()
for p in latest.iterdir():
 if p.is_file() and p.suffix in ('.json','.log','.dis','.gdb') and p.name!='instruction-trace.log':shutil.copyfile(p,ev/p.name)
for label in ('ROUND1','FULL'):shutil.copyfile(latest/f'{label}.hex',d/f'pepsi-fast94-{label}.hex')
shutil.copyfile(selected/'key-check/result.json',ev/'key-expansion.json')
shutil.copyfile(r/'outputs/overhead-analysis/daily-comparison.json',ev/'candidate-comparison.json')
for f in (d/'src').iterdir():assert hashlib.sha256(f.read_bytes()).hexdigest()==rep['source_sha256'][f.name]
b=d/'phase-check';b.mkdir();shutil.copyfile(d/'src/myCrypt.h',b/'myCrypt.h');(b/'hal.h').write_text('void trigger_high(void);void trigger_low(void);')
s=(base/'tools/check_phases.py').read_text().replace('pepsi-round1-10','pepsi-fast94');(d/'tools/check_phases.py').write_text(s)
env=os.environ.copy();env['PYTHONUTF8']='1';subprocess.run(['python',str(d/'tools/check_phases.py')],check=True,env=env)
shutil.copyfile(b/'phase-results.json',ev/'phase-results.json')
manifest={str(p.relative_to(d)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in (d/'baseline').rglob('*') if p.is_file()}
for folder in ('src','build-support'):
 for p in (base/folder).iterdir():manifest[folder+'/'+p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
(d/'baseline-manifest.json').write_text(json.dumps(manifest,indent=2))
print(d)
