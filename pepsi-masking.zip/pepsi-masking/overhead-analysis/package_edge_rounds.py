from pathlib import Path
import json,shutil,hashlib,zipfile
d=Path(__file__).resolve().parents[1]/'pepsi-round1-10';run=sorted((d/'results').iterdir())[-1]
rep=json.loads((run/'report.json').read_text());comp=json.loads((run/'instruction-comparison.json').read_text())
assert rep['status']=='PASS'
phase=json.loads((d/'phase-check/phase-results.json').read_text());assert phase['result']=='PASS'
for label in ('ROUND1','FULL'):shutil.copyfile(run/f'{label}.hex',d/f'pepsi-round1-10-{label}.hex')
ev=d/'verification';ev.mkdir(exist_ok=True)
for p in run.iterdir():
 if p.is_file() and p.suffix in ('.json','.log','.dis','.gdb') and p.name!='instruction-trace.log':shutil.copyfile(p,ev/p.name)
shutil.copyfile(d/'phase-check/phase-results.json',ev/'phase-results.json')
(d/'README.md').write_text(f'''# PEPSI 1·10라운드 상태 보호 비교 후보

제출 파일: pepsi-round1-10-ROUND1.hex / pepsi-round1-10-FULL.hex.
코드: src/myCrypt.c. 비교 기준: pepsi-precompute. 기존 제출본은 원래 폴더와 ZIP에 보존했습니다.

## 적용 범위
- 1라운드: 마스킹 AddRoundKey, 마스킹 S-box와 합친 ShiftRows, 행별 마스크, 바이트 및 MixColumns 열 셔플 유지.
- 2~9라운드: 마스크 없는 상태, 일반 AES S-box, 바이트 0~15 및 열 0~3 고정 순서. 저장된 라운드 키의 n[row]^m 마스크를 사용 시 해제.
- 10라운드: n[row]로 재마스킹된 입력을 사용하여 마스킹 AddRoundKey, 마스킹 S-box·ShiftRows, 셔플을 적용. AES 규격대로 MixColumns는 없음. 최종 키 결합과 암호문 출력도 기존 마스킹 helper와 셔플 유지.
- 키 확장 자체는 기존 마스킹 구현을 유지했습니다. 즉 이번 후보는 **상태 라운드 연산**의 보호 범위를 줄인 것이며, 전체 코드에서 보호 연산을 모두 제거한 것은 아닙니다.
- MSbox 하나, 두 상태 버퍼 교대, 고정 ShiftRows 목적지 표, 암호화마다 순열 1회 생성 유지. 추가 난수 호출 없음.

## 경계와 트리거
1라운드 MixColumns 후 n[row]를 해제해 평문 상태 연산으로 전환합니다. 9라운드 MixColumns 후 n[row]를 다시 씌워 10라운드에 들어갑니다.
ROUND1 트리거의 기존 위치는 유지하여 첫 AddRoundKey부터 첫 MixColumns까지 포함합니다. 새로 추가된 1라운드 뒤 마스크 해제는 trigger_low 뒤에서 실행됩니다. FULL은 준비·키 확장·전체 라운드·두 경계 변환·최종 출력까지 포함합니다.
중간 라운드와 마스크 해제 경계에 비보호 값이 생깁니다. 측정 창 밖이라는 이유로 안전한 것으로 간주해서는 안 됩니다. 보안 80점 유지와 2차 평가 저항성은 미확인입니다.

## 검증 결과
- 독립 AES·출력 별칭·호스트 트리거 6012건 통과.
- 실제 제출 AVR 객체: ROUND1/FULL 각 306건 독립 AES 대조 통과.
- AVR lookup_remasked 초기화→로드→재마스킹 명령 순서 및 HEX 구조/체크섬 확인.
- 별도 관찰 빌드로 500개 암호화의 14500개 중간 상태를 독립 AES와 비교. 각 라운드의 마스크 및 두 경계 변환 일치. 순열 생성 500회·라운드 간 순열 유지 확인. 관찰 코드는 제출 src에 없음.
- 동일 NIST 입력·PRNG 상태 1 표본의 FULL 명령 수: {comp['baseline_instructions']}→{comp['candidate_instructions']}, {comp['reduction_percent']}% 감소. 실제 클럭 사이클이나 서버 오버헤드 감소율이 아닙니다. 키 확장·주소 계산·MixColumns 비용이 남아 있습니다.
- 실제 사이클 제한·최대 스택·서버 보안 점수는 미검증. 이전 baseline 기록의 watch-cycles를 하드웨어 사이클로 해석한 부분은 유효하지 않습니다.

## 빌드와 평가
Python/PyCryptodome, MSVC C++ 도구 및 ChipWhisperer AVR 도구가 필요합니다.
tools/verify.py --host --avr --firmware-root <firmware 경로> --avr-bin <AVR bin 경로> 로 현재 소스의 검증·빌드를 실행합니다. build-support의 공용 SimpleSerial 파서를 적용한 격리 복사본에서 빌드합니다. src를 simpleserial-contest에 배치한 뒤 make clean 및 make CONTEST_FULL=0/1로 재빌드할 수도 있습니다.
tools/check_phases.py는 실행한 로컬 작업 경로를 사용하므로 이동 시 경로 조정이 필요합니다.
PRNG 제출 입력은 기존 비교 제출과 동일한 2바이트를 사용하되 공식 사용량 정의가 새롭게 확인됐다는 의미는 아닙니다. 서버에서 사이클 감소와 보안 점수를 함께 비교하세요.
''',encoding='utf-8')
files=[]
for p in d.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(d)
 if rel.parts[0] in ('results','phase-check') or '__pycache__' in rel.parts or p.name=='SHA256.json':continue
 files.append(p)
hashes={str(p.relative_to(d)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(d/'SHA256.json').write_text(json.dumps(hashes,indent=2,ensure_ascii=False),encoding='utf-8')
zpath=d.parent/'pepsi-round1-10.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[d/'SHA256.json']:z.write(p,Path(d.name)/p.relative_to(d))
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 assert all(hashlib.sha256(z.read(d.name+'/'+name)).hexdigest()==h for name,h in hashes.items())
print(zpath)
