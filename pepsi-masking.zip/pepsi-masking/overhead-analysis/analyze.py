from pathlib import Path
import shutil,subprocess,os,re,json
r=Path(__file__).resolve().parent; original=r.parent/'pepsi-order-reuse'
bin=Path('C:/workspace/ChipWhisperer5_64/cw/workspace/avrgcc/bin'); fw=Path('C:/workspace/ChipWhisperer5_64/cw/workspace/chipwhisperer/hardware/victims/firmware')
env=os.environ.copy();env['OS']='Linux';env['PATH']=str(bin)+';C:/Program Files/Git/usr/bin;'+env['PATH']
def run(cmd,cwd=r,timeout=60):
 p=subprocess.run([str(x) for x in cmd],cwd=cwd,env=env,capture_output=True,text=True,errors='replace',timeout=timeout)
 if p.returncode:raise RuntimeError(p.stdout+p.stderr)
 return p.stdout+p.stderr
b=r/'build';b.mkdir(exist_ok=True)
for f in ('hal','crypto','simpleserial'):shutil.copytree(fw/f,b/f,dirs_exist_ok=True)
shutil.copyfile(fw/'Makefile.inc',b/'Makefile.inc');shutil.copytree(original/'src',b/'simpleserial-contest',dirs_exist_ok=True)
for p in (original/'build-support').iterdir():shutil.copyfile(p,b/'simpleserial'/p.name)
stage=b/'simpleserial-contest'
run([bin/'make.exe','clean'],stage)
(r/'build.log').write_text(run([bin/'make.exe','CONTEST_FULL=1'],stage))
assert (stage/'simpleserial-contest-CWLITEXMEGA.hex').read_bytes()==(original/'pepsi-order-reuse-FULL.hex').read_bytes()
print('Rebuilt HEX exactly matches submission',flush=True)
(r/'test.c').write_text('''#include <stdint.h>
void Encrypt(unsigned char*,unsigned char*,unsigned char*);
unsigned char p[16]={0,17,34,51,68,85,102,119,136,153,170,187,204,221,238,255};
unsigned char k[16]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
unsigned char out[16];
int main(void){Encrypt(p,k,out);for(;;);}
''')
run([bin/'avr-gcc.exe','-mmcu=atxmega128d3','-Os','test.c',stage/'objdir-CWLITEXMEGA/myCrypt.o','-o','probe.elf'])
dis=run([bin/'avr-objdump.exe','-d','probe.elf']);(r/'probe.dis').write_text(dis)
high=re.search(r'^\s*([0-9a-f]+):.*sts\s+0x0605',dis,re.M).group(1);low=re.search(r'^\s*([0-9a-f]+):.*sts\s+0x0606',dis,re.M).group(1)
script=f'''set pagination off
set confirm off
target sim
load
break Encrypt
run
set {{unsigned long}}&prng_state = 1
break *0x{high}
continue
set $n=(unsigned long)0
while $pc != 0x{low} && $n < 200000
printf "TRACE %x\\n", $pc
stepi
set $n=$n+1
end
printf "DONE %lu\\n", $n
x/16bx 0x80213e
quit
'''
(r/'trace.gdb').write_text(script)
(r/'trace.log').write_text(run([bin/'avr-gdb.exe','--batch','-x','trace.gdb','probe.elf'],timeout=240))
print('Trace complete',flush=True)
