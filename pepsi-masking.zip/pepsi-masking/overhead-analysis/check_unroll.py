from pathlib import Path
import subprocess,re,json
r=Path.cwd();d=r/'outputs/pepsi-unroll';(d/'verification').mkdir(exist_ok=True)
s=(r/'outputs/overhead-analysis/asan_daily.py').read_text().replace('pepsi-fast94','pepsi-unroll')
exec(s)
s=(r/'outputs/overhead-analysis/check_precompute.py').read_text();s=s[s.index('latest=sorted'):].replace('oldcount=42344','oldcount=39057')
exec(s)
