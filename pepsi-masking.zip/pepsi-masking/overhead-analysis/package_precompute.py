from pathlib import Path
import json,shutil,hashlib,zipfile
d=Path(__file__).resolve().parents[1]/'pepsi-precompute';run=sorted((d/'results').iterdir())[-1]
rep=json.loads((run/'report.json').read_text());comp=json.loads((run/'instruction-comparison.json').read_text())
assert rep['status']=='PASS' and comp['candidate_instructions']<comp['baseline_instructions']
phase=json.loads((d/'phase-check/phase-results.json').read_text());assert phase['result']=='PASS'
for label in ('ROUND1','FULL'):shutil.copyfile(run/f'{label}.hex',d/f'pepsi-precompute-{label}.hex')
ev=d/'verification';ev.mkdir(exist_ok=True)
for p in run.iterdir():
 if p.is_file() and p.suffix in ('.json','.log','.dis','.gdb') and p.name!='instruction-trace.log':shutil.copyfile(p,ev/p.name)
shutil.copyfile(d/'phase-check/phase-results.json',ev/'phase-results.json')
(d/'README.md').write_text(f'''# PEPSI 중복 계산 감소 후보

제출: pepsi-precompute-ROUND1.hex 및 pepsi-precompute-FULL.hex.
src/myCrypt.c가 수정된 AES 코드입니다. 기존 pepsi-order-reuse 폴더와 ZIP은 원래 위치에 보존했습니다.

## 변경
- 암호화당 순열 생성 1회·라운드 간 재사용 유지.
- MixColumns 열 순서 추출을 9회에서 준비 단계 1회로 줄임. 동일한 4개 열 순서 재사용.
- ShiftRows 목적지 산술 계산을 고정 16바이트 표 조회로 대체. SubBytes와 ShiftRows는 여전히 같은 루프이며 입력/출력 상태 버퍼 교대를 유지.
- 마스킹 키 확장, S-box 하나, 행별 마스크 흐름, AVR lookup_remasked 레지스터 초기화 유지. 추가 난수 호출 없음.
- FULL은 위 준비 계산까지 포함. ROUND1은 첫 라운드 계산을 포함하며 열 순서 준비는 트리거 전에 실행됩니다.

## 확인
독립 AES·출력 별칭·호스트 트리거 6012건, 실제 제출 AVR 객체 두 모드 각 306건 AES 대조, lookup 명령 순서, HEX 구조/체크섬 통과.
관찰용 별도 호스트 빌드: 500개 암호화의 14500개 중간 상태를 독립 AES와 대조하여 마스크 흐름 일치. 순열 생성 500회 및 라운드 간 순서 재사용 확인. 관찰 코드는 제출 src에 없음.
동일 NIST 입력·초기 PRNG 상태 1·시뮬레이터 타이머 0 표본의 FULL 실행 명령 수: {comp['baseline_instructions']} → {comp['candidate_instructions']} ({comp['reduction_percent']}% 감소).

## 측정 제한
위 수치는 실행 명령 수이고 실제 AVR 클럭 사이클이나 서버 오버헤드 감소율이 아닙니다. 서버의 이전 103383사이클·6.89배가 이번 후보에서 얼마나 줄었는지는 재평가해야 합니다. 보안 80점 유지도 미확인입니다. 실제 하드웨어 사이클 제한은 검증하지 못했습니다.
이전 watch-cycles를 실측 사이클처럼 해석한 검사 오류를 반영해 이번 tools/verify.py는 해당 제한 통과를 보고하지 않습니다. baseline 내부 이전 검증 기록은 과거 자료이며 그 안의 사이클 통과 주장은 유효하지 않습니다.
고정 목적지 표로 정적 데이터가 16바이트 증가합니다. columns는 4바이트 지역 배열이며 실제 스택 변화는 컴파일러 배치에 따라 달라집니다. 최대 스택은 미측정입니다.

## 재빌드
ChipWhisperer firmware 트리에 src를 simpleserial-contest로 배치하고 build-support의 공용 simpleserial.c/.h를 firmware/simpleserial에 적용한 복사본에서 make clean 후 make CONTEST_FULL=0 또는 1로 빌드합니다.
tools/verify.py --host --avr --firmware-root <firmware 경로> --avr-bin <AVR bin 경로> 로 재검증할 수 있습니다. Python/PyCryptodome, Visual Studio C++ 도구, AVR 도구 필요. check_phases.py는 실행 환경의 로컬 경로를 사용하므로 이동 시 경로 조정이 필요합니다.
PRNG 제출 입력값은 이번 최적화로 바꾸지 않았습니다. 평가 입력은 기존 제출과 동일하게 비교하세요.
''',encoding='utf-8')
files=[]
for p in d.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(d)
 if rel.parts[0] in ('results','phase-check') or '__pycache__' in rel.parts:continue
 if p.name=='SHA256.json':continue
 files.append(p)
hashes={str(p.relative_to(d)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(d/'SHA256.json').write_text(json.dumps(hashes,indent=2,ensure_ascii=False),encoding='utf-8')
zpath=d.parent/'pepsi-precompute.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[d/'SHA256.json']:z.write(p,Path(d.name)/p.relative_to(d))
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 assert all(hashlib.sha256(z.read(d.name+'/'+name)).hexdigest()==h for name,h in hashes.items())
print(zpath);print(comp)
