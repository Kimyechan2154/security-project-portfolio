from pathlib import Path
import subprocess,os,json,shutil
r=Path.cwd();source=(r/'work/verify.py').read_text(encoding='utf-8-sig')
source=source.replace('outputs/pepsi-user-masking-v4','outputs/예찬충연최고-v4-security').replace("r/'work/check'","r/'work/security-check'").replace("stage=root/'work/build'","stage=root/'work/security-build'").replace('work/build/pepsi-','work/security-build/pepsi-')
env=os.environ.copy();env['PYTHONUTF8']='1';results=[]
for trial in range(3):
 s=source.replace('random.Random(808)',f'random.Random({202610090+trial})')
 if trial<2:s=s.split('# Build the actual')[0]
 f=r/f'work/security-test-{trial}.py';f.write_text(s,encoding='utf-8')
 p=subprocess.run(['python',str(f)],cwd=r,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=120)
 print(p.stdout,flush=True)
 if p.returncode:raise RuntimeError(p.stderr)
 results.append({'trial':trial+1,'seed':202610090+trial,'results':json.loads((r/'work/security-check/results.json').read_text())})
(r/'work/security-check/three-runs.json').write_text(json.dumps(results,indent=2))
s=(r/'work/avr_asan.py').read_text().replace("exec(open('work/verify.py',encoding='utf-8-sig').read().split('for mode in (0,1):')[0])","exec(Path('work/security-test-2.py').read_text(encoding='utf-8').split('for mode in (0,1):')[0])")
s='from pathlib import Path\n'+s
f=r/'work/security-avr-asan.py';f.write_text(s,encoding='utf-8')
p=subprocess.run(['python',str(f)],cwd=r,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=120);print(p.stdout,flush=True)
if p.returncode:raise RuntimeError(p.stderr)
