from pathlib import Path
import shutil
r=Path.cwd();old=r/'outputs/pepsi-user-masking-v4';new=r/'outputs/예찬충연최고-v4-security';shutil.copytree(old/'simpleserial-contest',new/'simpleserial-contest',dirs_exist_ok=True)
for f in ('original-v3.zip','ChipWhisperer-LICENSE.txt','contest_build.ipynb'):shutil.copyfile(old/f,new/f)
p=new/'simpleserial-contest/myCrypt.c';s=p.read_text();pos=s.index('void Encrypt(')
s=s[:pos]+'''/* Randomize the byte execution order and table assignment independently.
 * Rejection sampling avoids modulo bias; it does not repair PRNG entropy. */
static void random_permutation(byte order[16])
{
    byte i, j, value, temporary;
    for (i=0; i<16; ++i) order[i]=i;
    for (i=15; i>0; --i) {
        uint16_t limit=256u-(256u % (i+1u));
        do { value=random_byte(); } while ((uint16_t)value>=limit);
        j=(byte)(value % (i+1u));
        temporary=order[i]; order[i]=order[j]; order[j]=temporary;
    }
}
void Encrypt(unsigned char* PT, unsigned char* KEY, unsigned char* out)
{
    byte state[16], round_keys[11][16];
    byte input_mask[16], output_mask[16], active_mask[16];
    byte transformed_mask[16], order[16], table_for_byte[16];
    byte m, key_output_mask, row_mask0, row_mask1, row_mask2, row_mask3, n[4], q[4];
    byte i, step, round, table;
    uint16_t x;
#if CONTEST_FULL
    trigger_high();
#endif
    refresh_timing_seed();
    generate_key_masks(&m,&key_output_mask,&row_mask0,&row_mask1,&row_mask2,&row_mask3);
    build_key_sbox(m,key_output_mask);
    n[0]=xtime(row_mask0) ^ (xtime(row_mask1)^row_mask1) ^ row_mask2 ^ row_mask3;
    n[1]=row_mask0 ^ xtime(row_mask1) ^ (xtime(row_mask2)^row_mask2) ^ row_mask3;
    n[2]=row_mask0 ^ row_mask1 ^ xtime(row_mask2) ^ (xtime(row_mask3)^row_mask3);
    n[3]=(xtime(row_mask0)^row_mask0) ^ row_mask1 ^ row_mask2 ^ xtime(row_mask3);
    for(i=0;i<4;++i) q[i]=n[i]^m;
    expand_masked_key(KEY,round_keys,m,key_output_mask,row_mask0,row_mask1,row_mask2,row_mask3,n[0],n[1],n[2],n[3]);
    for(i=0;i<16;++i) {
        input_mask[i]=random_byte(); output_mask[i]=random_byte();
        for(x=0;x<256;++x)
            state_sbox[i][x]=aes_sbox[(byte)x ^ input_mask[i]] ^ output_mask[i];
    }
    random_permutation(order);
    random_permutation(table_for_byte);
    for(i=0;i<16;++i) {
        active_mask[i]=input_mask[table_for_byte[i]];
        transformed_mask[i]=output_mask[table_for_byte[i]];
    }
    shift_rows(transformed_mask); mix_columns(transformed_mask);
    /* Prepare public PT masking outside ROUND1, then capture exactly round 1. */
    for(i=0;i<16;++i) state[i]=PT[i]^active_mask[i];
#if !CONTEST_FULL
    trigger_high();
#endif
    for(round=0;round<10;++round) {
        /* Fuse key addition and substitution in a shuffled byte order.
         * The key correction is applied after combining masked operands. */
        for(step=0;step<16;++step) {
            i=order[step]; table=table_for_byte[i];
            byte value=masked_different(state[i],round_keys[round][i],q[i&3]);
            state[i]=state_sbox[table][value];
        }
        shift_rows(state);
        if(round<9) {
            mix_columns(state);
#if !CONTEST_FULL
            if(round==0) trigger_low();
#endif
            /* Rotate logical byte mask domains each round without rebuilding
             * 4096 table entries. These are reused masks, not fresh entropy. */
            random_permutation(order);
            random_permutation(table_for_byte);
            for(step=0;step<16;++step) {
                i=order[step]; byte next=input_mask[table_for_byte[i]];
                state[i]=masked_remask(state[i],transformed_mask[i]^next);
                active_mask[i]=next;
            }
            for(i=0;i<16;++i) transformed_mask[i]=output_mask[table_for_byte[i]];
            shift_rows(transformed_mask);
            if(round<8) mix_columns(transformed_mask);
        }
    }
    /* Final round skips MixColumns; remove its shifted output masks. */
    for(step=0;step<16;++step) {
        i=order[step];
        byte value=masked_different(state[i],round_keys[10][i],key_output_mask);
        out[i]=masked_remask(value,transformed_mask[i]);
    }
#if CONTEST_FULL
    trigger_low();
#endif
}
'''
# active_mask is needed only for PT initialization; preserve explicit flow.
p.write_text(s)
print(new)
