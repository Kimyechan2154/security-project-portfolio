from pathlib import Path
exec(Path('work/security-test-2.py').read_text(encoding='utf-8').split('for mode in (0,1):')[0])
bin=Path('C:/workspace/ChipWhisperer5_64/cw/workspace/avrgcc/bin')
# Fresh oracle vectors, built for AVR simulator; production timer access retained.
items=[];rng=random.Random(12080)
for n in range(102):
 p,k=(bytes.fromhex('00112233445566778899aabbccddeeff'),bytes(range(16))) if n==0 else (rng.randbytes(16),rng.randbytes(16))
 items.append('{'+','.join(str(v) for v in p+k+AES.new(k,AES.MODE_ECB).encrypt(p))+'}')
s=(prior/'v3-check/avr_test.c').read_text();s=re.sub(r'cases\[\]\[48\] PROGMEM=\{.*?\};','cases[][48] PROGMEM={'+','.join(items)+'};',s,flags=re.S)
s=s.replace('pepsi-user-masking/simpleserial-contest/myCrypt.h','myCrypt.h');s=re.sub(r'ContestSetSeed\([^;]*;','',s)
(b/'avr_test.c').write_text(s)
avr=[]
for mode in (0,1):
 run([str(bin/'avr-gcc.exe'),'-mmcu=atxmega128d3','-std=gnu99','-Os',f'-DCONTEST_FULL={mode}','-I.', 'myCrypt.c','avr_test.c','-o',f'avr{mode}.elf'])
 out=run([str(bin/'avr-run.exe'),'--watch-clock-int','10000',f'avr{mode}.elf']);assert 'P' in out,out
 avr.append({'mode':mode,'aes_alias_trigger_cases':306,'simulator':'PASS'})
 print(avr[-1],flush=True)
# ASan executes production cipher and parser under a bounded UART harness.
(b/'asan.c').write_text('''#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include "myCrypt.h"
#include "simpleserial.h"
extern int events,io_fault;void feed(unsigned char*,int);
uint8_t get_key(uint8_t,uint8_t,uint8_t,uint8_t*);uint8_t get_pt(uint8_t,uint8_t,uint8_t,uint8_t*);
int main(void){unsigned char a[96],k[16]={0},before[96],wire[700];int i,j,d;uint32_t x=1;
for(d=-15;d<=15;d++){memset(a,165,96);memcpy(before,a,96);events=0;Encrypt(a+40,k,a+40+d);if(events!=12)return 2;for(i=0;i<96;i++)if((i<40+d||i>=56+d)&&a[i]!=before[i])return 3;}
simpleserial_init();simpleserial_addcmd('k',16,get_key);simpleserial_addcmd('p',16,get_pt);
for(i=0;i<10000;i++){int n=i%699;for(j=0;j<n;j++){x^=x<<13;x^=x>>17;x^=x<<5;wire[j]=(x%255)+1;}wire[n]=0;feed(wire,n+1);simpleserial_get();if(io_fault)return 4;}
for(i=0;i<256;i++)simpleserial_put('r',i,wire);puts("PASS ASan: 31 overlap canaries, 10000 malformed frames, output lengths 0..255");return 0;}
''')
env=os.environ.copy();env['PATH']=r'C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Tools\MSVC\14.44.35207\bin\Hostx64\x64;'+env['PATH']
asan=[]
for mode in (0,1):
 (b/'asan_compile.cmd').write_text(f'@echo off\ncall "{vc}" >nul\ncl /nologo /O2 /fsanitize=address /Zi /DSS_VER=SS_VER_2_1 /DCONTEST_FULL={mode} myCrypt.c simpleserial.c /c\ncl /nologo /O2 /fsanitize=address /Zi /Dmain=firmware_main /DSS_VER=SS_VER_2_1 /c simpleserial-contest.c\ncl /nologo /O2 /fsanitize=address /Zi /DSS_VER=SS_VER_2_1 stub.c asan.c myCrypt.obj simpleserial.obj simpleserial-contest.obj /Fe:asan{mode}.exe\n')
 run(['cmd.exe','/d','/c','asan_compile.cmd']);out=run([str(b/f'asan{mode}.exe')],env=env);assert 'PASS ASan' in out;asan.append({'mode':mode,'result':out.strip()});print(out,flush=True)
(b/'avr-asan-results.json').write_text(json.dumps({'avr':avr,'asan':asan},indent=2))
