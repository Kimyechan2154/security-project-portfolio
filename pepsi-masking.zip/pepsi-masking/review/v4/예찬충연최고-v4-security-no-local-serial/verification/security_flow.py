from pathlib import Path
import subprocess,ctypes as C,json,os,re
r=Path.cwd();b=r/'work/security-check';vc=r'C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat'
(b/'flow.c').write_text('''#include "myCrypt.c"
void trigger_high(void){} void trigger_low(void){}
__declspec(dllexport) void permutation(uint8_t *out,uint32_t seed){prng_state=seed?seed:0x6d2b79f5UL;random_permutation(out);}
__declspec(dllexport) int verify_tables(uint32_t seed){uint8_t pt[16]={0},key[16]={0},out[16];unsigned int i,x;prng_state=seed?seed:1;Encrypt(pt,key,out);
/* Reconstruct each table's input mask from inverse of S(0) relation.
 * Instead compare the full table to all possible input mask hypotheses. */
for(i=0;i<16;i++){unsigned int m;int found=0;for(m=0;m<256;m++){uint8_t n=state_sbox[i][m]^aes_sbox[0];for(x=0;x<256;x++)if(state_sbox[i][x]!=(aes_sbox[x^m]^n))break;if(x==256){found=1;break;}}if(!found)return 1;}return 0;}
''')
(b/'flow_compile.cmd').write_text(f'@echo off\ncall "{vc}" >nul\ncl /nologo /O2 /LD flow.c /link /OUT:flow.dll /IMPLIB:flow.lib\n')
p=subprocess.run(['cmd.exe','/d','/c','flow_compile.cmd'],cwd=b,capture_output=True);assert p.returncode==0,p.stdout+p.stderr
d=C.CDLL(str(b/'flow.dll'));A=C.c_ubyte*16;d.permutation.argtypes=[C.POINTER(C.c_ubyte),C.c_uint32];d.verify_tables.argtypes=[C.c_uint32]
hist=[[0]*16 for _ in range(16)];unique=set()
for seed in range(10000):
 a=A();d.permutation(a,seed);assert sorted(a)==list(range(16));unique.add(bytes(a))
 for pos,value in enumerate(a):hist[pos][value]+=1
for seed in (0,1,0xffffffff,0x80000000,0x6d2b79f5):assert d.verify_tables(seed)==0
assert len(unique)>9900
(b/'flow-results.json').write_text(json.dumps({'permutations_valid':10000,'unique_permutations':len(unique),'table_sets_checked':5,'tables_per_set':16,'entries_per_table':256,'note':'Functional permutation/table checks, not a randomness or leakage proof','result':'PASS'},indent=2));print('10000 permutations and 5 full sets of masked S-box tables: PASS')
