from pathlib import Path
import shutil
r=Path.cwd();src=r/'outputs/예찬충연최고-v4-fast/simpleserial-contest';dest=r/'outputs/예찬충연최고-v4-single/simpleserial-contest';dest.mkdir(parents=True,exist_ok=True)
for f in ('makefile','myCrypt.h','simpleserial-contest.c'):shutil.copyfile(src/f,dest/f)
s=(src/'myCrypt.c').read_text(encoding='utf-8-sig');a=s.index('/* Two independently');b=s.index('static void random_permutation',a)
s=s[:a]+'''/* The key and state share T[x ^ m] = S(x) ^ key_output_mask.
 * One table saves setup/RAM but increases mask reuse and horizontal leakage risk.
 * Shuffle order still changes each round; this is not a leakage proof. */
'''+s[b:]
a=s.index('/* For two domains');s=s[:a]+'''void Encrypt(unsigned char* PT, unsigned char* KEY, unsigned char* out)
{
    byte state[16], round_keys[11][16], order[16];
    byte m, key_output_mask, row_mask0, row_mask1, row_mask2, row_mask3, n[4], q[4];
    byte i, step, round, mask_change;
#if CONTEST_FULL
    trigger_high();
#endif
    refresh_timing_seed();
    generate_key_masks(&m,&key_output_mask,&row_mask0,&row_mask1,&row_mask2,&row_mask3);
    build_key_sbox(m,key_output_mask);
    n[0]=xtime(row_mask0) ^ (xtime(row_mask1)^row_mask1) ^ row_mask2 ^ row_mask3;
    n[1]=row_mask0 ^ xtime(row_mask1) ^ (xtime(row_mask2)^row_mask2) ^ row_mask3;
    n[2]=row_mask0 ^ row_mask1 ^ xtime(row_mask2) ^ (xtime(row_mask3)^row_mask3);
    n[3]=(xtime(row_mask0)^row_mask0) ^ row_mask1 ^ row_mask2 ^ xtime(row_mask3);
    for(i=0;i<4;++i) q[i]=n[i]^m;
    expand_masked_key(KEY,round_keys,m,key_output_mask,row_mask0,row_mask1,row_mask2,row_mask3,n[0],n[1],n[2],n[3]);
    mask_change=key_output_mask^m;
    random_permutation(order);
    for(i=0;i<16;++i) state[i]=PT[i]^m;
#if !CONTEST_FULL
    trigger_high();
#endif
    for(round=0;round<10;++round) {
        for(step=0;step<16;++step) {
            i=order[step];
            byte value=masked_different(state[i],round_keys[round][i],q[i&3]);
            state[i]=key_sbox[value];
        }
        /* A uniform output mask is preserved by ShiftRows and MixColumns
         * because each MixColumns row's coefficients XOR to 1. */
        shift_rows(state);
        if(round<9) {
            mix_columns(state);
#if !CONTEST_FULL
            if(round==0) trigger_low();
#endif
            random_permutation(order);
            for(step=0;step<16;++step) {
                i=order[step];
                state[i]=masked_remask(state[i],mask_change);
            }
        }
    }
    /* State and final key both carry key_output_mask. Their XOR is the
     * public ciphertext; keep the established helper/output sequence. */
    for(step=0;step<16;++step) {
        i=order[step];
        byte value=masked_different(state[i],round_keys[10][i],key_output_mask);
        out[i]=masked_remask(value,key_output_mask);
    }
#if CONTEST_FULL
    trigger_low();
#endif
}
'''
(dest/'myCrypt.c').write_text(s,encoding='utf-8')
# Isolate all single-table tests and build outputs from the previous candidate.
s=(r/'work/fast_verify.py').read_text().replace('예찬충연최고-v4-fast','예찬충연최고-v4-single').replace('fast-test-source','single-test-source').replace('fast-check','single-check').replace('fast-test-','single-test-').replace('fast-avr-asan','single-avr-asan').replace('fast-build','single-build').replace('202610100','202610200')
(r/'work/single_verify.py').write_text(s,encoding='utf-8')
s=(r/'work/production_budget.py').read_text().replace('fast-check','single-check').replace('fast-build','single-build')
(r/'work/single_budget.py').write_text(s,encoding='utf-8')
print(dest)
