from pathlib import Path
import subprocess,ctypes,json
r=Path.cwd();b=r/'work/single-check';vc=r'C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat'
(b/'algebra.c').write_text('''#include "myCrypt.c"
void trigger_high(void){}void trigger_low(void){}
__declspec(dllexport) int algebra_check(void){unsigned int m,o,x;unsigned char plain[16],masked[16];
for(m=0;m<256;m++)for(o=0;o<256;o++){build_key_sbox(m,o);for(x=0;x<256;x++)if(key_sbox[x^m]!=(aes_sbox[x]^o))return 1;}
for(m=0;m<256;m++){for(x=0;x<16;x++){plain[x]=(unsigned char)(x*17);masked[x]=plain[x]^m;}shift_rows(plain);shift_rows(masked);mix_columns(plain);mix_columns(masked);for(x=0;x<16;x++)if((plain[x]^masked[x])!=m)return 2;}
return 0;}
''')
(b/'algebra_compile.cmd').write_text(f'@echo off\ncall "{vc}" >nul\ncl /nologo /O2 /LD algebra.c /link /OUT:algebra.dll /IMPLIB:algebra.lib\n')
p=subprocess.run(['cmd.exe','/d','/c','algebra_compile.cmd'],cwd=b,capture_output=True);assert p.returncode==0,p.stdout+p.stderr
d=ctypes.CDLL(str(b/'algebra.dll'));assert d.algebra_check()==0
res={'masked_sbox_identity_cases':256**3,'uniform_mask_shiftrows_mixcolumns_masks':256,'result':'PASS','note':'Functional mask algebra check; not a physical leakage proof'}
(b/'algebra-results.json').write_text(json.dumps(res,indent=2));print(res)
