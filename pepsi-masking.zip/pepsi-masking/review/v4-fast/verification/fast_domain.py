from pathlib import Path
p=Path('outputs/예찬충연최고-v4-fast/simpleserial-contest/myCrypt.c');s=p.read_text(encoding='utf-8-sig')
a=s.index('/* Experimental byte-specific masking.');b=s.index('#define STATE_TABLES',a)
s=s[:a]+'''/* Two independently generated mask domains shared across bytes.
 * Execution order and domain assignment are randomized separately.
 * This reduces setup cost but increases sharing versus the 16-table design.
 */
'''+s[b:]
pos=s.index('void Encrypt(')
s=s[:pos]+'''/* For two domains, each assignment needs one random bit, not a permutation.
 * Domain counts are not forced to be equal. This is not fresh entropy. */
static void assign_table_domains(byte domain[16])
{
    byte group,bit,choices;
    for(group=0;group<2;++group) {
        choices=random_byte();
        for(bit=0;bit<8;++bit) {
            domain[8*group+bit]=choices&1;
            choices>>=1;
        }
    }
}
'''+s[pos:]
s=s.replace('    random_permutation(table_for_byte);\n    for(i=0;i<16;++i) table_for_byte[i]&=(STATE_TABLES-1);','    assign_table_domains(table_for_byte);')
p.write_text(s,encoding='utf-8')
print('Independent random-bit table assignment prepared')
