from pathlib import Path
import os,subprocess,json,shutil
r=Path.cwd();env=os.environ.copy();env['PYTHONUTF8']='1'
# Test copies use shared parser; final contest folder excludes these files.
src=r/'outputs/예찬충연최고-v4-fast/simpleserial-contest'
stage=r/'work/fast-test-source';shutil.copytree(src,stage,dirs_exist_ok=True)
for f in ('simpleserial.c','simpleserial.h'):shutil.copyfile(r/'work/security-check'/('shared-'+f),stage/f)
s=(r/'work/verify.py').read_text(encoding='utf-8-sig').replace("fw=r/'outputs/pepsi-user-masking-v4/simpleserial-contest'","fw=r/'work/fast-test-source'").replace("r/'work/check'","r/'work/fast-check'")
s=s.split('# Build the actual')[0]
allresults=[]
for trial in range(3):
 f=r/f'work/fast-test-{trial}.py';f.write_text(s.replace('random.Random(808)',f'random.Random({202610100+trial})'),encoding='utf-8')
 p=subprocess.run(['python',str(f)],cwd=r,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=60);print(p.stdout,flush=True)
 if p.returncode:raise RuntimeError(p.stderr)
 allresults.append({'trial':trial+1,'results':json.loads((r/'work/fast-check/results.json').read_text())})
(r/'work/fast-check/three-runs.json').write_text(json.dumps(allresults,indent=2))
s=(r/'work/avr_asan.py').read_text().replace("exec(open('work/verify.py',encoding='utf-8-sig').read().split('for mode in (0,1):')[0])","exec(Path('work/fast-test-2.py').read_text(encoding='utf-8').split('for mode in (0,1):')[0])")
f=r/'work/fast-avr-asan.py';f.write_text('from pathlib import Path\n'+s,encoding='utf-8')
p=subprocess.run(['python',str(f)],cwd=r,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=120);print(p.stdout,flush=True)
if p.returncode:raise RuntimeError(p.stderr)
build=r/'work/fast-build';shutil.copytree(r/'work/security-build/make-fw',build,dirs_exist_ok=True)
for f in ('makefile','myCrypt.c','myCrypt.h','simpleserial-contest.c'):shutil.copyfile(src/f,build/'simpleserial-contest'/f)
bin=Path('C:/workspace/ChipWhisperer5_64/cw/workspace/avrgcc/bin');env['OS']='Linux';env['PATH']=str(bin)+';C:/Program Files/Git/usr/bin;'+env['PATH'];res=[]
for mode,label in ((0,'ROUND1'),(1,'FULL')):
 logs=[]
 for cmd in ([str(bin/'make.exe'),'clean'],[str(bin/'make.exe'),f'CONTEST_FULL={mode}']):
  p=subprocess.run(cmd,cwd=build/'simpleserial-contest',env=env,capture_output=True,text=True,errors='replace',timeout=60);logs.append(p.stdout+p.stderr)
  if p.returncode:raise RuntimeError(logs[-1])
 (r/f'work/fast-check/build-{label}.log').write_text('\n'.join(logs),encoding='utf-8')
 shutil.copyfile(build/'simpleserial-contest/simpleserial-contest-CWLITEXMEGA.hex',src.parent/f'예찬충연최고-{label}.hex')
 dis=subprocess.check_output([str(bin/'avr-objdump.exe'),'-d',str(build/'simpleserial-contest/simpleserial-contest-CWLITEXMEGA.elf')],env=env).decode();(r/f'work/fast-check/{label}.dis').write_text(dis)
 size=subprocess.check_output([str(bin/'avr-size.exe'),str(build/'simpleserial-contest/simpleserial-contest-CWLITEXMEGA.elf')],env=env).decode();res.append({'mode':label,'size':size});print(size,flush=True)
(r/'work/fast-check/build-results.json').write_text(json.dumps(res,indent=2))
