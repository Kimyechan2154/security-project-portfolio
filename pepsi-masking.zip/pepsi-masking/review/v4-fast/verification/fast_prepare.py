from pathlib import Path
import shutil,re
r=Path.cwd();d=r/'outputs/예찬충연최고-v4-fast';d.mkdir(exist_ok=True)
fw=d/'simpleserial-contest';shutil.copytree(r/'work/security-build/make-fw/simpleserial-contest',fw,dirs_exist_ok=True)
for p in list(fw.iterdir()):
 if p.is_file() and p.name not in ('makefile','myCrypt.c','myCrypt.h','simpleserial-contest.c'):p.unlink()
# Keep only deliverable sources (build directories are not copied to final ZIP).
s=(r/'work/security-check/myCrypt.c').read_text()
s=s.replace('static byte state_sbox[16][256];','/* Four mask domains: less table setup, increased domain sharing. */\n#define STATE_TABLES 4\nstatic byte state_sbox[STATE_TABLES][256];')
start=s.index('static void random_permutation(');end=s.index('void Encrypt(',start)
s=s[:start]+'''static void random_permutation(byte order[16])
{
    /* threshold[n-1] = 256 % n. Multiply-high rejection avoids division
     * while giving the same unbiased range mapping for uniform bytes. */
    static const byte threshold[16]={0,0,1,0,1,4,4,0,4,6,3,4,9,4,1,0};
    byte i,j,value,temporary;
    uint16_t product;
    for(i=0;i<16;++i) order[i]=i;
    for(i=15;i>0;--i) {
        do { value=random_byte(); product=(uint16_t)value*(i+1u); }
        while((byte)product<threshold[i]);
        j=(byte)(product>>8);
        temporary=order[i];order[i]=order[j];order[j]=temporary;
    }
}
'''+s[end:]
s=s.replace('byte input_mask[16], output_mask[16], active_mask[16];','byte input_mask[STATE_TABLES], output_mask[STATE_TABLES], active_mask[16];')
s=s.replace('for(i=0;i<16;++i) {\n        input_mask[i]=random_byte();','for(i=0;i<STATE_TABLES;++i) {\n        input_mask[i]=random_byte();')
s=s.replace('    random_permutation(table_for_byte);','    random_permutation(table_for_byte);\n    for(i=0;i<16;++i) table_for_byte[i]&=(STATE_TABLES-1);')
s=s.replace('4096 table entries','1024 table entries')
(fw/'myCrypt.c').write_text(s,encoding='utf-8')
# For local validation only, select exactly the already checked shared parser.
for f in ('simpleserial.c','simpleserial.h'):shutil.copyfile(r/'work/security-build/make-fw/simpleserial'/f,r/'work/security-check'/('shared-'+f))
print(d)
