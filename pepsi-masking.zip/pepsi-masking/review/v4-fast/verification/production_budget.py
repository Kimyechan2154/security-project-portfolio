from pathlib import Path
import subprocess,json,re,os
r=Path.cwd();b=r/'work/fast-check';bin=Path('C:/workspace/ChipWhisperer5_64/cw/workspace/avrgcc/bin')
s=(b/'avr_test.c').read_text().replace('   if(events!=12)finish(3);','')
(b/'production_test.c').write_text(s)
def run(cmd):
 p=subprocess.run(cmd,cwd=b,capture_output=True,text=True,errors='replace',timeout=20)
 return p
obj=r/'work/fast-build/simpleserial-contest/objdir-CWLITEXMEGA/myCrypt.o'
p=run([str(bin/'avr-gcc.exe'),'-mmcu=atxmega128d3','-std=gnu99','-Os','-fpack-struct','-I.','production_test.c',str(obj),'-o','production.elf']);assert p.returncode==0,p.stdout+p.stderr
p=run([str(bin/'avr-run.exe'),'--watch-clock-int','10000','production.elf']);assert 'P' in p.stdout,p.stdout+p.stderr
dis=run([str(bin/'avr-objdump.exe'),'-d','production.elf']).stdout;(b/'production.dis').write_text(dis)
high=re.search(r'^\s*([0-9a-f]+):.*sts\s+0x0605',dis,re.M).group(1);low=re.search(r'^\s*([0-9a-f]+):.*sts\s+0x0606',dis,re.M).group(1)
results=[]
for seed,budget in [(1,n) for n in (100000,120000,140000,152760)]+[(seed,120000) for seed in (0,0xffffffff,0x80000000,1208,20261008)]:
 cmd=[str(bin/'avr-gdb.exe'),'--batch','-ex','target sim','-ex','load','-ex',f'break *0x{high}','-ex','run','-ex',f'set {{unsigned long}}&prng_state = {seed}','-ex',f'sim watch-cycles-int +{budget}','-ex',f'break *0x{low}','-ex','continue','-ex','info registers pc','production.elf']
 p=run(cmd);out=p.stdout+p.stderr
 passed='Breakpoint 2,' in out and 'No symbol' not in out and 'syntax error' not in out
 results.append({'seed':seed,'cycle_budget':budget,'reached_GPIO_low':passed,'exit_code':p.returncode});print(results[-1],flush=True)
 (b/f'production-budget-{seed}-{budget}.log').write_text(out,encoding='utf-8')
(b/'production-budget-results.json').write_text(json.dumps({'production_cipher_object_aes_alias_cases':306,'results':results,'note':'Cycle budget probes in AVR simulator, not measured board/server cycles. GPIO high/low breakpoints surround compiled FULL region.'},indent=2))
assert all(x['reached_GPIO_low'] for x in results if x['cycle_budget']==120000)
