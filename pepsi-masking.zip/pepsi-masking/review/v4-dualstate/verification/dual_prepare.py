from pathlib import Path
import shutil
r=Path.cwd(); old=r/'outputs/예찬충연최고-v5-row-review';new=r/'outputs/예찬충연최고-v4-dualstate';shutil.copytree(old/'simpleserial-contest',new/'simpleserial-contest',dirs_exist_ok=True)
p=new/'simpleserial-contest/myCrypt.c';s=p.read_text();a=s.index('static void shift_rows(');b=s.index('static void mix_columns(',a);s=s[:a]+s[b:]
a=s.index('static MASK_NOINLINE byte masked_add_round_key');s=s[:a]+'''/* Clear the lookup destination register before loading a new masked byte.
 * This breaks that register's direct old/new S-box value transition only;
 * it is not a register/bus leakage proof for the complete implementation. */
static MASK_NOINLINE byte lookup_remasked(byte index, byte change)
{
#ifdef __AVR__
    const byte *address = key_sbox + index;
    byte value;
    __asm__ volatile("clr %0\\n\\tld %0, Z\\n\\teor %0, %2"
                     : "=&r"(value) : "z"(address), "r"(change) : "memory");
    return value;
#else
    volatile byte value = key_sbox[index];
    return value ^ change;
#endif
}
''' +s[a:]
s=s.replace('byte state[16], round_keys[11][16], order[16];','byte state_a[16], state_b[16], round_keys[11][16], order[16];\n    byte *in_state=state_a, *out_state=state_b, *temporary;')
s=s.replace('for(i=0;i<16;++i) state[i]=PT[i]^n[i&3];','for(i=0;i<16;++i) { in_state[i]=PT[i]^n[i&3]; out_state[i]=0; }')
a=s.index('        for(step=0;step<16;++step) {',s.index('for(round=0;round<10;'));b=s.index('#if !CONTEST_FULL\n            if(round==0)',a)
s=s[:a]+'''        for(step=0;step<16;++step) {
            byte row, destination, change;
            i=order[step];
            row=i&3;
            destination=(byte)(4*((((i>>2)+4-row)&3))+row);
            /* n[row] XOR (n[row] XOR m) = m. ShiftRows preserves row.
             * Non-final output is immediately remasked mp -> row_mask[row]. */
            byte value=masked_add_round_key(in_state[i],round_keys[round][i]);
            change=(round<9)?row_change[row]:0;
            out_state[destination]=lookup_remasked(value,change);
        }
        if(round<9) {
            mix_columns(out_state);
''' +s[b:]
s=s.replace('            random_permutation(order);\n        }\n    }','            random_permutation(order);\n        }\n        temporary=in_state;in_state=out_state;out_state=temporary;\n    }')
s=s.replace('masked_different(state[i],round_keys[10][i],key_output_mask)','masked_different(in_state[i],round_keys[10][i],key_output_mask)')
p.write_text(s,encoding='utf-8')
v=(r/'work/row_verify.py').read_text().replace('예찬충연최고-v5-row-review','예찬충연최고-v4-dualstate').replace('row-','dual-').replace('202610300','202610500');(r/'work/dual_verify.py').write_text(v,encoding='utf-8')
