from pathlib import Path
import shutil,subprocess,os,re,json,ctypes as C,random
from Crypto.Cipher import AES
r=Path.cwd(); prior=Path('C:/workspace/Documents/Codex/2026-10-07/https-pepsi-ohbin1208-com-https-pepsi/work'); fw=r/'outputs/pepsi-user-masking-v4/simpleserial-contest'; b=r/'work/check'; b.mkdir(exist_ok=True)
for f in ('myCrypt.c','myCrypt.h','simpleserial.c','simpleserial.h','simpleserial-contest.c'): shutil.copyfile(fw/f,b/f)
(b/'hal.h').write_text('void trigger_high(void);void trigger_low(void);void platform_init(void);void init_uart(void);void trigger_setup(void);char getch(void);void putch(char);')
stub=(prior/'handoff-fix/deep_stub.c').read_text().split('extern const')[0]
(b/'stub.c').write_text(stub)
(b/'harness.c').write_text('#include "myCrypt.c"\n__declspec(dllexport) void test_key(uint8_t *key,uint8_t *out,uint8_t *v){build_key_sbox(v[0],v[1]);expand_masked_key(key,(uint8_t (*)[16])out,v[0],v[1],v[2],v[3],v[4],v[5],v[6],v[7],v[8],v[9]);}\n')
vc=r'C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat'
helpers=(prior/'handoff-fix/deep_test.py').read_text().split('all_results=[]')[0];exec(helpers)
results=[]
def run(cmd,cwd=b,env=None):
 p=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True,text=True,errors='replace',timeout=60)
 if p.returncode: raise RuntimeError(p.stdout+p.stderr)
 return p.stdout+p.stderr
for mode in (0,1):
 (b/'compile.cmd').write_text(f'@echo off\ncall "{vc}" >nul\ncl /nologo /O2 /W4 /wd4100 /LD /Dmain=firmware_main /DSS_VER=SS_VER_2_1 /DCONTEST_FULL={mode} harness.c simpleserial.c simpleserial-contest.c stub.c /link /EXPORT:Encrypt /EXPORT:simpleserial_init /EXPORT:simpleserial_addcmd /EXPORT:simpleserial_get /EXPORT:get_key /EXPORT:get_pt /EXPORT:feed /EXPORT:events,DATA /EXPORT:rxpos,DATA /EXPORT:io_fault,DATA /EXPORT:txlen,DATA /EXPORT:tx,DATA /OUT:mode{mode}.dll /IMPLIB:mode{mode}.lib\n')
 (b/f'compile-{mode}.log').write_text(run(['cmd.exe','/d','/c','compile.cmd']))
 d=C.CDLL(str(b/f'mode{mode}.dll'));d.Encrypt.argtypes=[P]*3;d.test_key.argtypes=[P]*3
 rng=random.Random(808);cases=[(bytes.fromhex('00112233445566778899aabbccddeeff'),bytes(range(16)))]+[(rng.randbytes(16),rng.randbytes(16)) for _ in range(2000)]
 for pt,key in cases:
  for alias in range(3):
   p,k,o=B.from_buffer_copy(pt),B.from_buffer_copy(key),B();o=p if alias==1 else k if alias==2 else o
   C.c_int.in_dll(d,'events').value=0;d.Encrypt(p,k,o)
   assert bytes(o)==AES.new(key,AES.MODE_ECB).encrypt(pt)
   assert C.c_int.in_dll(d,'events').value==12
 # Independent key expansion using AES S-box derived algebraically.
 def mul(a,c):
  v=0
  for _ in range(8):
   if c&1:v^=a
   a=xt(a);c>>=1
  return v
 def sb(a):
  inv=0 if a==0 else 1
  if a:
   for _ in range(254):inv=mul(inv,a)
  return inv^sum([]) if False else inv^((inv<<1|inv>>7)&255)^((inv<<2|inv>>6)&255)^((inv<<3|inv>>5)&255)^((inv<<4|inv>>4)&255)^99
 S=[sb(i) for i in range(256)]
 for _ in range(1000):
  key=rng.randbytes(16);v=list(rng.randbytes(6));ns=mix(v[2:]);v+=ns;out=RK();d.test_key(B.from_buffer_copy(key),out,(C.c_ubyte*10)(*v));w=list(key);rc=1
  for i in range(16,176,4):
   t=w[i-4:i]
   if i%16==0:t=[S[t[1]]^rc,S[t[2]],S[t[3]],S[t[0]]];rc=xt(rc)
   w.extend(w[i-16+j]^t[j] for j in range(4))
  assert all((out[j]^(v[1] if j>=160 else ns[j&3]^v[0]))==w[j] for j in range(176))
 d.simpleserial_init();d.simpleserial_addcmd.argtypes=[C.c_char,C.c_uint,C.c_void_p];d.feed.argtypes=[P,C.c_int]
 for c,f in ((b'k',d.get_key),(b'p',d.get_pt)):d.simpleserial_addcmd(c,16,C.cast(f,C.c_void_p))
 bad=[bytes(rng.randrange(1,256) for _ in range(rng.randrange(0,600)))+b'\0' for _ in range(3000)]
 bad +=[request(112,bytes(n)) for n in range(256) if n!=16]+[request(112,bytes(16),badcrc=True)]
 for frame in bad:
  key=bytes(range(16));pt=bytes(range(16,32));wire=frame+request(107,key)+request(112,pt);a=(C.c_ubyte*len(wire)).from_buffer_copy(wire);d.feed(a,len(wire))
  for _ in range(3):d.simpleserial_get()
  tx=(C.c_ubyte*4096).in_dll(d,'tx');n=C.c_int.in_dll(d,'txlen').value
  assert decode_wire(bytes(tx[:n]))[-3:]==[(101,b'\0'),(114,AES.new(key,AES.MODE_ECB).encrypt(pt)),(101,b'\0')]
  assert C.c_int.in_dll(d,'io_fault').value==0 and C.c_int.in_dll(d,'rxpos').value==len(wire)
 results.append(dict(mode=mode,aes_alias_trigger_cases=len(cases)*3,key_schedules=1000,parser_resync_cases=len(bad),result='PASS'));print(results[-1],flush=True)
(b/'results.json').write_text(json.dumps(results,indent=2))
# Build the actual submission firmware, not the host harness.
s=(prior/'build_v3_hex.py').read_text().replace("stage=root/'work/v3-build'","stage=root/'work/build'").replace("stage/'pepsi-user-masking/simpleserial-contest'","root/'outputs/pepsi-user-masking-v4/simpleserial-contest'")
exec(s)
for mode in ('ROUND1','FULL'):shutil.copyfile(r/f'work/build/pepsi-{mode}.hex',r/f'outputs/pepsi-user-masking-v4/pepsi-{mode}.hex')

