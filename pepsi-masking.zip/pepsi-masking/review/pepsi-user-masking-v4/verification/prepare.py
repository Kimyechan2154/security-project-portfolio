from pathlib import Path
import re,shutil
r=Path.cwd(); old=r/'work/pepsi-user-masking-v3'; new=r/'outputs/pepsi-user-masking-v4'
shutil.copytree(old/'simpleserial-contest',new/'simpleserial-contest',dirs_exist_ok=True)
for f in ('ChipWhisperer-LICENSE.txt','contest_build.ipynb'): shutil.copyfile(old/f,new/f)
s=(old/'simpleserial-contest/myCrypt.c').read_text()
s=re.sub(r'#define AES_(BLOCK|ROUND|KEY)_SIZE 16\s*','',s)
names={'rand_num':'generate_key_masks','sbox':'aes_sbox','MSbox':'key_sbox','M_MSbox':'build_key_sbox','Rcon':'round_constants','ShiftRows':'shift_rows','MixColumns':'mix_columns','M_KeyExpansion':'expand_masked_key','byte_sbox':'state_sbox','roundKeys':'round_keys','m_prime':'output_mask','m1':'row_mask0','m2':'row_mask1','m3':'row_mask2','m4':'row_mask3','mp':'key_output_mask'}
for a,b in names.items(): s=re.sub(r'\b'+a+r'\b',b,s)
for name in ('generate_key_masks','build_key_sbox','shift_rows','mix_columns','expand_masked_key'): s=s.replace('void '+name+'(', 'static void '+name+'(')
s=s.replace('const byte aes_sbox','static const byte aes_sbox').replace('const byte round_constants','static const byte round_constants').replace('byte key_sbox[256]','static byte key_sbox[256]')
s='\n'.join(line.rstrip() for line in s.splitlines())+'\n'
s=re.sub(r'\n\s*\n', '\n',s)
s=s.replace('    shift_rows(shifted_mask);','    /* Linear AES operations transform the S-box output masks too. */\n    shift_rows(shifted_mask);')
s=s.replace('            for(i=0;i<16;++i)\n                state[i]=masked_remask','            /* Restore each next S-box input mask after MixColumns. */\n            for(i=0;i<16;++i)\n                state[i]=masked_remask')
(new/'simpleserial-contest/myCrypt.c').write_text(s)
p=(new/'simpleserial-contest/simpleserial.c').read_text()
p=re.sub(r'int hex_decode\(.*?\n}\n','',p,count=1,flags=re.S)
p=re.sub(r'void ss_puts\(.*?\n}\n','',p,count=1,flags=re.S)
p=re.sub(r'uint8_t unstuff_data\(.*?\n}\n','',p,count=1,flags=re.S)
p=p[:p.index('\n\n#else')]+ '\n\n#else\n#error "This local parser supports SimpleSerial 2.1 only"\n#endif\n'
p=re.sub(r'\n\s*\n','\n',p)
(new/'simpleserial-contest/simpleserial.c').write_text(p)
shutil.copyfile(Path('C:/workspace/Documents/Codex/2026-10-07/https-pepsi-ohbin1208-com-https-pepsi/outputs/pepsi-user-masking-v3.zip'),new/'original-v3.zip')
print('v4 source prepared')
