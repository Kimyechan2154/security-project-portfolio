from pathlib import Path
import shutil,subprocess,json,re
r=Path.cwd();b=r/'work/row-debug';b.mkdir(exist_ok=True)
attachment=Path('C:/workspace/.codex/attachments/2b5fdd99-1a75-4adf-813c-6b9690dacdf5/붙여넣은 텍스트.txt')
shutil.copyfile(attachment,b/'debug.c')
vc=r'C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat'
(b/'compile.cmd').write_text(f'@echo off\ncall "{vc}" >nul\ncl /nologo /O2 debug.c /Fe:debug.exe\n')
p=subprocess.run(['cmd.exe','/d','/c','compile.cmd'],cwd=b,capture_output=True);assert p.returncode==0,p.stdout+p.stderr
p=subprocess.run([str(b/'debug.exe')],cwd=b,capture_output=True,text=True);assert p.returncode==0
(b/'debug-output.txt').write_text(p.stdout,encoding='utf-8')
res={'debug_source':'user supplied two-table variant','encryptions':10,'FIPS_ciphertext_matches':p.stdout.count('39 25 84 1d 02 dc 09 fb dc 11 85 97 19 6a 0b 32'),'reported_unmasked_algebraic_candidates':p.stdout.count('NO MASK (leak)'),'note':'Printed intermediate expressions are algebraic candidates, not proof that AVR emits these exact temporaries or physical leakage. Debug printf itself reveals secrets; never submit this diagnostic program.'}
(b/'debug-summary.json').write_text(json.dumps(res,indent=2));print(res,flush=True)
src=r/'outputs/예찬충연최고-v4-single/simpleserial-contest';dest=r/'outputs/예찬충연최고-v5-row-review/simpleserial-contest';dest.mkdir(parents=True,exist_ok=True)
for f in ('makefile','myCrypt.h','simpleserial-contest.c'):shutil.copyfile(src/f,dest/f)
s=(src/'myCrypt.c').read_text();a=s.index('/* The key and state share');bpos=s.index('static void random_permutation',a)
s=s[:a]+'''/* Shared S-box input/output masks are converted to four independent row
 * masks before each non-final MixColumns. Physical leakage remains untested. */
static MASK_NOINLINE byte masked_add_round_key(byte a,byte b)
{
#ifdef __AVR__
    __asm__ volatile("eor %0, %1" : "+&r"(a) : "r"(b));
    return a;
#else
    volatile byte value=a^b;
    return value;
#endif
}
'''+s[bpos:]
s=s.replace('row_mask3, n[4], q[4]','row_mask3, n[4], row_change[4]').replace('byte i, step, round, mask_change;','byte i, step, round;')
s=s.replace('    for(i=0;i<4;++i) q[i]=n[i]^m;','    row_change[0]=key_output_mask^row_mask0;\n    row_change[1]=key_output_mask^row_mask1;\n    row_change[2]=key_output_mask^row_mask2;\n    row_change[3]=key_output_mask^row_mask3;')
s=s.replace('    mask_change=key_output_mask^m;\n','')
s=s.replace('state[i]=PT[i]^m;','state[i]=PT[i]^n[i&3];')
s=s.replace('byte value=masked_different(state[i],round_keys[round][i],q[i&3]);','/* State mask n[row] XOR key mask (n[row] XOR m) = m. */\n            byte value=masked_add_round_key(state[i],round_keys[round][i]);')
s=s.replace('''        /* A uniform output mask is preserved by ShiftRows and MixColumns
         * because each MixColumns row's coefficients XOR to 1. */'''.replace('\n+','\n'),'''        /* ShiftRows keeps uniform S-box output mask m_prime. */''')
s=s.replace('''        if(round<9) {
            mix_columns(state);'''.replace('\n+','\n'),'''        if(round<9) {
            /* Convert m_prime to row_mask0..3 BEFORE MixColumns, so
             * equal-domain XORs are no longer identically unmasked. */
            for(step=0;step<16;++step) {
                i=order[step];
                state[i]=masked_remask(state[i],row_change[i&3]);
            }
            mix_columns(state);'''.replace('\n+','\n'))
s=s.replace('''            for(step=0;step<16;++step) {
                i=order[step];
                state[i]=masked_remask(state[i],mask_change);
            }
'''.replace('\n+','\n'),'')
(dest/'myCrypt.c').write_text(s,encoding='utf-8')
s=(r/'work/single_verify.py').read_text().replace('예찬충연최고-v4-single','예찬충연최고-v5-row-review').replace('single-test-source','row-test-source').replace('single-check','row-check').replace('single-test-','row-test-').replace('single-avr-asan','row-avr-asan').replace('single-build','row-build').replace('202610200','202610300');(r/'work/row_verify.py').write_text(s,encoding='utf-8')
s=(r/'work/single_budget.py').read_text().replace('single-check','row-check').replace('single-build','row-build');(r/'work/row_budget.py').write_text(s,encoding='utf-8')
print(dest,flush=True)
