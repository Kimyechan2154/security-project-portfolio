#include "myCrypt.h"
#if defined(__AVR__) || defined(CONTEST_MOCK_TIMER)
#include <avr/io.h>
#endif
#ifndef CONTEST_FULL
#define CONTEST_FULL 0
#endif
/* Port of the supplied PEPSI_AES-8bit/main.c.
 * Original masked S-box, masked key expansion and mask corrections retained.
 * Timer seeding is experimental and provides no verified entropy guarantee.
 */
static uint32_t prng_state = 0x6d2b79f5UL;
void ContestRandomInit(void)
{
#if defined(__AVR__) || defined(CONTEST_MOCK_TIMER)
    /* This firmware owns TCC0. No interrupts or output pins are enabled. */
    TCC0.CTRLA = TC_CLKSEL_OFF_gc;
    TCC0.CTRLB = 0;
    TCC0.PER = 0xffff;
    TCC0.CNT = 0;
    TCC0.CTRLA = TC_CLKSEL_DIV1_gc;
#endif
}
static uint8_t random_byte(void)
{
    uint32_t x = prng_state;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    prng_state = x;
    return (uint8_t)(x >> 24);
}
static void refresh_timing_seed(void)
{
#if defined(__AVR__) || defined(CONTEST_MOCK_TIMER)
    /* Two sampled input bytes per encryption; not two bytes of entropy. */
    uint16_t timing = TCC0.CNT;
    prng_state ^= ((uint32_t)timing << 16) | timing;
    if (!prng_state) prng_state = 0x6d2b79f5UL;
#endif
}
typedef uint8_t byte;
static void generate_key_masks(byte* m, byte* output_mask, byte* row_mask0, byte* row_mask1, byte* row_mask2, byte* row_mask3) {
	*m = random_byte();
	*output_mask = random_byte();
	*row_mask0 = random_byte();
	*row_mask1 = random_byte();
	*row_mask2 = random_byte();
	*row_mask3 = random_byte();
}
static const byte aes_sbox[256] = {
	0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
	0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
	0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
	0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
	0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
	0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
	0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
	0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
	0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
	0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
	0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
	0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
	0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
	0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
	0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
	0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
};
static byte key_sbox[256];
static void build_key_sbox(byte m, byte output_mask) {
	for (int byte_idx = 0; byte_idx < 256; byte_idx++) {
		key_sbox[byte_idx ^ m] = aes_sbox[byte_idx] ^ output_mask;
	}
}
static inline byte xtime(byte x) {
	return (byte)((x << 1) ^ (((x >> 7) & 1) * 0x1b));
}
static const byte round_constants[10] = {
	0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36
};
static void column_order(const byte order[16], byte groups[4])

{

    byte seen=0, count=0, step;

    for(step=0;step<16 && count<4;++step) {

        byte g=order[step]&3;

        if(!(seen & (1u<<g))) { groups[count++]=g; seen|=(1u<<g); }

    }

}

/* Reuses the SubBytes permutation; this is not an independent shuffle. */
static void mix_columns(byte state[16], const byte columns[4]) {
	byte s0, s1, s2, s3;
	byte step;
    for (step=0; step<4; ++step) {
        byte i=(byte)(4*columns[step]);
		s0 = state[i];
		s1 = state[i + 1];
		s2 = state[i + 2];
		s3 = state[i + 3];
		state[i] = xtime(s0) ^ (xtime(s1) ^ s1) ^ s2 ^ s3;
		state[i + 1] = s0 ^ xtime(s1) ^ (xtime(s2) ^ s2) ^ s3;
		state[i + 2] = s0 ^ s1 ^ xtime(s2) ^ (xtime(s3) ^ s3);
		state[i + 3] = (xtime(s0) ^ s0) ^ s1 ^ s2 ^ xtime(s3);
	}
}
/* Force the mask-preserving instruction order on AVR. Early-clobber
 * outputs cannot overlap any still-live input. These helpers address the
 * reported raw key intermediate; they are NOT a full leakage proof.
 */
#ifdef __AVR__
#define MASK_NOINLINE __attribute__((noinline,noclone))
#elif defined(_MSC_VER)
#define MASK_NOINLINE __declspec(noinline)
#else
#define MASK_NOINLINE __attribute__((noinline))
#endif
static MASK_NOINLINE byte masked_different(byte a, byte b, byte correction)
{
#ifdef __AVR__
    __asm__ volatile ("eor %0, %1\n\teor %0, %2"
                      : "+&r"(a) : "r"(b), "r"(correction));
    return a;
#else
    volatile byte t = a ^ b;
    return t ^ correction;
#endif
}
static MASK_NOINLINE byte masked_same(byte a, byte b, byte correction, byte guard)
{
    byte change = correction ^ guard;
#ifdef __AVR__
    __asm__ volatile ("eor %1, %2\n\teor %0, %1\n\teor %0, %3"
                      : "+&r"(a), "+&r"(b) : "r"(change), "r"(guard));
    return a;
#else
    volatile byte t = b ^ change;
    volatile byte u = a ^ t;
    return u ^ guard;
#endif
}
static MASK_NOINLINE byte masked_remask(byte a, byte change)
{
#ifdef __AVR__
    __asm__ volatile ("eor %0, %1" : "+&r"(a) : "r"(change));
    return a;
#else
    volatile byte t = a ^ change;
    return t;
#endif
}
static void expand_masked_key(byte key[16], byte round_keys[11][16], byte m, byte output_mask,
                    byte row_mask0, byte row_mask1, byte row_mask2, byte row_mask3,
                    byte n1, byte n2, byte n3, byte n4)
{
    byte q[4] = { n1 ^ m, n2 ^ m, n3 ^ m, n4 ^ m };
    byte n[4] = { n1,n2,n3,n4 };
    byte guard[4] = { row_mask0,row_mask1,row_mask2,row_mask3 };
    byte row, word, round;
    for (word=0; word<4; ++word)
        for (row=0; row<4; ++row)
            round_keys[0][4*word+row] = key[4*word+row] ^ q[row];
    for (round=1; round<=10; ++round) {
        for (row=0; row<4; ++row) {
            byte rotated = (byte)((row+1)&3);
            byte index = round_keys[round-1][12+rotated] ^ n[rotated];
            /* index has mask m; table result has mask output_mask.
             * Combine BEFORE cancelling output_mask, keeping mask q[row]. */
            byte g = key_sbox[index];
            byte v = masked_different(round_keys[round-1][row], g, output_mask);
            round_keys[round][row] = v ^ (row==0 ? round_constants[round-1] : 0);
        }
        for (word=1; word<4; ++word)
            for (row=0; row<4; ++row)
                round_keys[round][4*word+row] = masked_same(
                    round_keys[round-1][4*word+row],
                    round_keys[round][4*(word-1)+row], q[row], guard[row]);
    }
    /* AES final round expects key bytes under output_mask, not q[row]. */
    for (word=0; word<4; ++word)
        for (row=0; row<4; ++row)
            round_keys[10][4*word+row] = masked_remask(
                round_keys[10][4*word+row], q[row] ^ output_mask);
}
/* Shared S-box input/output masks are converted to four independent row
 * masks before each non-final MixColumns. Physical leakage remains untested. */
/* Clear the lookup destination register before loading a new masked byte.
 * This breaks that register's direct old/new S-box value transition only;
 * it is not a register/bus leakage proof for the complete implementation. */
static MASK_NOINLINE byte lookup_remasked(byte index, byte change)
{
#ifdef __AVR__
    const byte *address = key_sbox + index;
    byte value;
    __asm__ volatile("clr %0\n\tld %0, Z\n\teor %0, %2"
                     : "=&r"(value) : "z"(address), "r"(change) : "memory");
    return value;
#else
    volatile byte value = key_sbox[index];
    return value ^ change;
#endif
}
static MASK_NOINLINE byte masked_add_round_key(byte a,byte b)
{
#ifdef __AVR__
    __asm__ volatile("eor %0, %1" : "+&r"(a) : "r"(b));
    return a;
#else
    volatile byte value=a^b;
    return value;
#endif
}
static void random_permutation(byte order[16])
{
    /* threshold[n-1] = 256 % n. Multiply-high rejection avoids division
     * while giving the same unbiased range mapping for uniform bytes. */
    static const byte threshold[16]={0,0,1,0,1,4,4,0,4,6,3,4,9,4,1,0};
    byte i,j,value,temporary;
    uint16_t product;
    for(i=0;i<16;++i) order[i]=i;
    for(i=15;i>0;--i) {
        do { value=random_byte(); product=(uint16_t)value*(i+1u); }
        while((byte)product<threshold[i]);
        j=(byte)(product>>8);
        temporary=order[i];order[i]=order[j];order[j]=temporary;
    }
}
/* Fixed ShiftRows destination for each input position. */
static const byte shift_destination[16]={0,13,10,7,4,1,14,11,8,5,2,15,12,9,6,3};
void Encrypt(unsigned char* PT, unsigned char* KEY, unsigned char* out)
{
    byte state_a[16], state_b[16], round_keys[11][16], order[16];
    byte columns[4];
    byte *in_state=state_a, *out_state=state_b, *temporary;
    byte m, key_output_mask, row_mask0, row_mask1, row_mask2, row_mask3, n[4], row_change[4];
    byte i, step, round;
#if CONTEST_FULL
    trigger_high();
#endif
    refresh_timing_seed();
    generate_key_masks(&m,&key_output_mask,&row_mask0,&row_mask1,&row_mask2,&row_mask3);
    build_key_sbox(m,key_output_mask);
    n[0]=xtime(row_mask0) ^ (xtime(row_mask1)^row_mask1) ^ row_mask2 ^ row_mask3;
    n[1]=row_mask0 ^ xtime(row_mask1) ^ (xtime(row_mask2)^row_mask2) ^ row_mask3;
    n[2]=row_mask0 ^ row_mask1 ^ xtime(row_mask2) ^ (xtime(row_mask3)^row_mask3);
    n[3]=(xtime(row_mask0)^row_mask0) ^ row_mask1 ^ row_mask2 ^ xtime(row_mask3);
    row_change[0]=key_output_mask^row_mask0;
    row_change[1]=key_output_mask^row_mask1;
    row_change[2]=key_output_mask^row_mask2;
    row_change[3]=key_output_mask^row_mask3;
    expand_masked_key(KEY,round_keys,m,key_output_mask,row_mask0,row_mask1,row_mask2,row_mask3,n[0],n[1],n[2],n[3]);
    random_permutation(order);
    /* Public index schedules: one preparation per encryption, no new RNG. */
    column_order(order,columns);
    for(i=0;i<16;++i) { in_state[i]=PT[i]^n[i&3]; out_state[i]=0; }
#if !CONTEST_FULL
    trigger_high();
#endif
    for(round=0;round<10;++round) {
        for(step=0;step<16;++step) {
            byte row, destination, change;
            i=order[step];
            row=i&3;
            destination=shift_destination[i];
            /* n[row] XOR (n[row] XOR m) = m. ShiftRows preserves row.
             * Non-final output is immediately remasked mp -> row_mask[row]. */
            byte value=masked_add_round_key(in_state[i],round_keys[round][i]);
            change=(round<9)?row_change[row]:0;
            out_state[destination]=lookup_remasked(value,change);
        }
        if(round<9) {
            mix_columns(out_state,columns);
#if !CONTEST_FULL
            if(round==0) trigger_low();
#endif
            /* Reuse this encryption's order; next Encrypt builds a new one. */
        }
        temporary=in_state;in_state=out_state;out_state=temporary;
    }
    /* State and final key both carry key_output_mask. Their XOR is the
     * public ciphertext; keep the established helper/output sequence. */
    for(step=0;step<16;++step) {
        i=order[step];
        byte value=masked_different(in_state[i],round_keys[10][i],key_output_mask);
        out[i]=masked_remask(value,key_output_mask);
    }
#if CONTEST_FULL
    trigger_low();
#endif
}
