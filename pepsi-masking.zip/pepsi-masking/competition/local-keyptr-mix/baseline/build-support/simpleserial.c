// simpleserial.c
#include "simpleserial.h"
#include <stdint.h>
#include "hal.h"
#define MAX_SS_CMDS 16
static int num_commands = 0;
#define MAX_SS_LEN 256
//#define SS_VER_1_0 0
//#define SS_VER_1_1 1
//#define SS_VER_2_0 2
// 0xA6 formerly 
#define CW_CRC 0x4D 
uint8_t ss_crc(uint8_t *buf, uint8_t len)
{
	unsigned int k = 0;
	uint8_t crc = 0x00;
	while (len--) {
		crc ^= *buf++;
		for (k = 0; k < 8; k++) {
			crc = crc & 0x80 ? (crc << 1) ^ CW_CRC: crc << 1;
		}
	}
	return crc;
}
// [B_STUFF, CMD, SCMD, LEN, B_STUFF, DATA..., CRC, TERM]
//#define SS_VER SS_VER_2_0
#if SS_VER == SS_VER_2_0
#error "SS_VER_2_0 is deprecated! Use SS_VER_2_1 instead."
#elif SS_VER == SS_VER_2_1
typedef struct ss_cmd
{
	char c;
	unsigned int len;
	uint8_t (*fp)(uint8_t, uint8_t, uint8_t, uint8_t *);
} ss_cmd;
static ss_cmd commands[MAX_SS_CMDS];
#define FRAME_BYTE 0x00
uint8_t check_version(uint8_t cmd, uint8_t scmd, uint8_t len, uint8_t *data)
{
	uint8_t ver = SS_VER;
	simpleserial_put('r', 1, &ver);
	return SS_ERR_OK;
}
uint8_t ss_get_commands(uint8_t cmd, uint8_t scmd, uint8_t len, uint8_t *data)
{
    uint8_t cmd_chars[MAX_SS_CMDS];
    for (uint8_t i = 0; i < (num_commands & 0xFF); i++) {
        cmd_chars[i] = commands[i].c;
    }
    simpleserial_put('r', num_commands & 0xFF, (void *)cmd_chars);
    return 0x00;
}
uint8_t stuff_data(uint8_t *buf, uint8_t len)
{
	uint8_t i = 1;
	uint8_t last = 0;
	for (; i < len; i++) {
		if (buf[i] == FRAME_BYTE) {
			buf[last] = i - last;
			last = i;
		}
	}
	return 0x00;
}
// Set up the SimpleSerial module by preparing internal commands
// This just adds the "v" command for now...
void simpleserial_init()
{
	simpleserial_addcmd('v', 0, check_version);
    simpleserial_addcmd('w', 0, ss_get_commands);
}
int simpleserial_addcmd(char c, unsigned int len, uint8_t (*fp)(uint8_t, uint8_t, uint8_t, uint8_t*))
{
	if(num_commands >= MAX_SS_CMDS) {
		putch('a');
		return 1;
	}
	if(len > MAX_SS_LEN - 6) {
		putch('b');
		return 1;
	}
	commands[num_commands].c   = c;
	commands[num_commands].len = len;
	commands[num_commands].fp  = fp;
	num_commands++;
	return 0;
}
/* Local SS2.1 fix: read/drain a complete delimited frame before parsing.
 * Buffer/index limits are checked before writes. No timeout is provided by
 * the platform's blocking getch(); a truncated frame may still wait for UART.
 */
void simpleserial_get(void)
{
    uint8_t data_buf[MAX_SS_LEN];
    uint8_t err = 0, byte_in, code, c;
    uint16_t used=0, read_pos=0, write_pos=0, j;
    uint8_t overflow=0;
    do {
        byte_in = (uint8_t)getch();
        if (byte_in != FRAME_BYTE) {
            if (used < MAX_SS_LEN-1) data_buf[used++] = byte_in;
            else overflow=1;
        }
    } while (byte_in != FRAME_BYTE);
    if (overflow) { err=SS_ERR_LEN; goto ERROR; }
    if (used < 5) { err=SS_ERR_FRAME_BYTE; goto ERROR; }
    /* Decode standard COBS in-place; source is always ahead of destination. */
    while (read_pos < used) {
        code=data_buf[read_pos++];
        if (!code || (uint16_t)(code-1) > used-read_pos) {
            err=SS_ERR_FRAME_BYTE; goto ERROR;
        }
        for (j=1; j<code; ++j) data_buf[write_pos++]=data_buf[read_pos++];
        if (code != 255 && read_pos < used) data_buf[write_pos++]=0;
    }
    if (write_pos < 4 || data_buf[2] > MAX_SS_LEN-6 ||
        write_pos != (uint16_t)data_buf[2]+4) {
        err=SS_ERR_LEN; goto ERROR;
    }
    for (c=0; c<num_commands; ++c)
        if (commands[c].c == data_buf[0]) break;
    if (c == num_commands) { err=SS_ERR_CMD; goto ERROR; }
    if (ss_crc(data_buf, (uint8_t)(write_pos-1)) != data_buf[write_pos-1]) {
        err=SS_ERR_CRC; goto ERROR;
    }
    if (data_buf[2] != commands[c].len) { err=SS_ERR_LEN; goto ERROR; }
    err=commands[c].fp(data_buf[0], data_buf[1], data_buf[2], data_buf+3);
ERROR:
    simpleserial_put('e', 1, &err);
}
void simpleserial_put(char c, uint8_t size, uint8_t* output)
{
    if (size > MAX_SS_LEN - 6) return; /* SS2.1 bounded encoding */
	uint8_t data_buf[MAX_SS_LEN];
	data_buf[0] = 0x00;
	data_buf[1] = c;
	data_buf[2] = size;
	int i = 0;
	for (; i < size; i++) {
		data_buf[i + 3] = output[i];
	}
	data_buf[i + 3] = ss_crc(data_buf+1, size+2);
	data_buf[i + 4] = 0x00;
	stuff_data(data_buf, i + 5);
	for (int i = 0; i < size + 5; i++) {
		putch(data_buf[i]);
	}
}
#else
#error "This local parser supports SimpleSerial 2.1 only"
#endif
