#include "hal.h"
#include "simpleserial.h"
#include <stdint.h>

#include "myCrypt.h"

unsigned char KEY[16] = { 0, };

uint8_t get_key(uint8_t cmd, uint8_t scmd, uint8_t len, uint8_t* k)
{
	unsigned char i = 0;
	if (len != 16)
		return SS_ERR_LEN;
	for (i = 0; i < 16; i++)
		KEY[i] = k[i];
	return 0x00;
}

uint8_t get_pt(uint8_t cmd, uint8_t scmd, uint8_t len, uint8_t* pt)
{
	unsigned char i = 0;
	unsigned char PT[16] = { 0, };
	unsigned char CT[16] = { 0, };
	if (len != 16)
		return SS_ERR_LEN;

	for (i = 0; i < 16; i++)
		PT[i] = pt[i];

	Encrypt(PT, KEY, CT);

	simpleserial_put('r', 16, CT);
	return 0x00;
}

int main(void)
{
	platform_init();
	init_uart();
	trigger_setup();
	ContestRandomInit();

	simpleserial_init();
	simpleserial_addcmd('k', 16, get_key);
	simpleserial_addcmd('p', 16, get_pt);
	while (1)
		simpleserial_get();
}
