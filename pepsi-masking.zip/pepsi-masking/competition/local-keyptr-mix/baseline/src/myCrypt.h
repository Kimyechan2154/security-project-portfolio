#pragma once
#include <stdint.h>
#include "hal.h"
void Encrypt(unsigned char* PT, unsigned char* KEY, unsigned char* out);
void ContestRandomInit(void);
