from pathlib import Path
import subprocess,ctypes as C,random,json
r=Path.cwd();b=r/'outputs/pepsi-round1-10/phase-check';src=r/'outputs/pepsi-round1-10/src/myCrypt.c'
s=src.read_text();s='static void observe(unsigned char,unsigned char,unsigned char*,unsigned char*);\n'+s
s=s.replace('    for(round=0;round<10;++round) {','    for(round=0;round<10;++round) {\n        {byte mask[16];for(i=0;i<16;++i)mask[i]=(round==0 || round==9)?n[i&3]:0;observe(round,0,in_state,mask);}')
s=s.replace('        /* PHASE_AFTER_SUB_SHIFT */','        {byte rows[4]={row_mask0,row_mask1,row_mask2,row_mask3},mask[16];for(i=0;i<16;++i)mask[i]=(round==0)?rows[i&3]:(round==9?key_output_mask:0);observe(round,2,out_state,mask);}')
s=s.replace('            /* PHASE_AFTER_MIX */','            {byte mask[16];for(i=0;i<16;++i)mask[i]=(round==0)?n[i&3]:0;observe(round,4,out_state,mask);}')
s='static unsigned permutation_calls, order_checks; static unsigned char first_order[16];\n'+s
s=s.replace('static void random_permutation(byte order[16])\n{','static void random_permutation(byte order[16])\n{\n    ++permutation_calls;')
s=s.replace('    for(round=0;round<10;++round) {','    for(round=0;round<10;++round) {\n        if(round==0){for(i=0;i<16;++i)first_order[i]=order[i];}\n        else{for(i=0;i<16;++i)if(first_order[i]!=order[i])order_checks=1;}')
s+='\n__declspec(dllexport) unsigned get_permutation_calls(void){return permutation_calls;}\n__declspec(dllexport) unsigned get_order_failure(void){return order_checks;}\n'

(b/'observed.c').write_text(s)
(b/'phase.c').write_text('''#include <stdint.h>
#include <string.h>
static uint8_t captured[10][5][16],masks[10][5][16];
static void observe(uint8_t round,uint8_t phase,uint8_t *state,uint8_t *mask){memcpy(captured[round][phase],state,16);memcpy(masks[round][phase],mask,16);}
void trigger_high(void){}void trigger_low(void){}
#include "observed.c"
__declspec(dllexport) void phase_encrypt(uint8_t *pt,uint8_t *key,uint8_t *out,uint8_t *values,uint8_t *mask_values){Encrypt(pt,key,out);memcpy(values,captured,sizeof(captured));memcpy(mask_values,masks,sizeof(masks));}
''')
vc=r'C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat';(b/'phase_compile.cmd').write_text(f'@echo off\ncall "{vc}" >nul\ncl /nologo /O2 /LD phase.c /link /OUT:phase.dll /IMPLIB:phase.lib\n')
p=subprocess.run(['cmd.exe','/d','/c','phase_compile.cmd'],cwd=b,capture_output=True);assert p.returncode==0,p.stdout+p.stderr
def xt(x):return ((x<<1)^(27 if x&128 else 0))&255
def mul(a,b):
 v=0
 for _ in range(8):
  if b&1:v^=a
  a=xt(a);b>>=1
 return v
def sb(x):
 inv=0 if x==0 else 1
 if x:
  for _ in range(254):inv=mul(inv,x)
 return inv^((inv<<1|inv>>7)&255)^((inv<<2|inv>>6)&255)^((inv<<3|inv>>5)&255)^((inv<<4|inv>>4)&255)^99
S=[sb(i) for i in range(256)]
def sr(s):return [s[4*((c+row)%4)+row] for c in range(4) for row in range(4)]
def mc(s):
 out=[]
 for j in range(0,16,4):
  a,b,c,d=s[j:j+4];out += [xt(a)^xt(b)^b^c^d,a^xt(b)^xt(c)^c^d,a^b^xt(c)^xt(d)^d,xt(a)^a^b^c^xt(d)]
 return out
def keys(k):
 w=list(k);rc=1
 for i in range(16,176,4):
  t=w[i-4:i]
  if i%16==0:t=[S[t[1]]^rc,S[t[2]],S[t[3]],S[t[0]]];rc=xt(rc)
  w.extend(w[i-16+j]^t[j] for j in range(4))
 return [w[i:i+16] for i in range(0,176,16)]
d=C.CDLL(str(b/'phase.dll'));P=C.POINTER(C.c_ubyte);d.phase_encrypt.argtypes=[P]*5;A=C.c_ubyte*16;V=C.c_ubyte*800;rng=random.Random(202610400);count=0
for case in range(500):
 pt=rng.randbytes(16);key=rng.randbytes(16);out=A();v=V();m=V();d.phase_encrypt(A.from_buffer_copy(pt),A.from_buffer_copy(key),out,v,m);rk=keys(key);state=list(pt)
 for round in range(10):
  expected={0:state};sub=[S[state[i]^rk[round][i]] for i in range(16)];shift=sr(sub);expected.update({2:shift})
  if round<9:expected.update({4:mc(shift)})
  for phase,value in expected.items():
   offset=(round*5+phase)*16
   assert [v[offset+i]^m[offset+i] for i in range(16)]==value,(case,round,phase)
   count+=1
  state=mc(shift) if round<9 else shift
 assert list(out)==[state[i]^rk[10][i] for i in range(16)]
assert d.get_permutation_calls()==500 and d.get_order_failure()==0
# Mask-only symbolic comparison of the diagnostic xtime pair:
# uniform mask gives 2*m XOR 2*m=0; independent row variables give
# a coefficient vector with two distinct nonzero coefficients.
res={'permutation_calls':500,'order_reuse_all_rounds':'PASS','encryptions':500,'phase_states_checked':count,'phases':'before ARK / after SB-SR / after MC; masks checked at protected-to-plain and plain-to-protected boundaries','result':'PASS','deterministic_xtime_pair_cancellation_uniform_mask':True,'deterministic_xtime_pair_cancellation_independent_row_symbols':False,'note':'No physical leakage proof; coincident masks may still cancel in individual executions. Observer code is host-only and excluded from submission.'}
(b/'phase-results.json').write_text(json.dumps(res,indent=2));print(res)
