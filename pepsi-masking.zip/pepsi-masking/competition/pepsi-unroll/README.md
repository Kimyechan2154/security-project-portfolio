# 전체 라운드 마스킹 + SubBytes·ShiftRows 펼치기

제출: pepsi-unroll-ROUND1.hex / pepsi-unroll-FULL.hex.
수정 코드: src/myCrypt.c. 이전 94.7점 버전 및 fast94 후보는 원래 폴더·ZIP에 보존했습니다. 이번 버전은 아직 서버 평가 전입니다.

## 구현
- 모든 10개 라운드의 상태 마스킹 복원. 중간 라운드의 마스크 해제·재적용 및 일반 S-box 경로 삭제.
- masked_sub_shift 함수에 16개 바이트 처리를 명시적으로 작성. 각 줄은 order[0]~order[15]에 따라 입력을 읽고 마스크 보정 후 ShiftRows 목적지에 기록. SubBytes와 ShiftRows는 합친 함수로 유지하여 별도의 복사 루프를 만들지 않음.
- 마지막 라운드 전용 masked_sub_shift_final을 별도로 작성. 바이트마다 마지막 라운드를 검사하는 if 제거. 마지막 라운드는 MixColumns 없음.
- 첫 라운드를 별도로 호출하여 ROUND1 trigger_low의 round==0 검사도 제거. 2~9라운드의 외부 라운드 반복문은 유지. 모든 for/if를 없앴다는 의미는 아님.
- 행별 보정 row_change[4]={mp^m1,mp^m2,mp^m3,mp^m4}를 암호화 준비에서 1회 계산.
- MSbox 하나, 두 상태 버퍼 교대, lookup_remasked의 레지스터 초기화·재마스킹, 암호화마다 순열 1회 생성·재사용 및 MixColumns 열 셔플 유지.
- 키 확장은 fast94에서 검증한 포인터 기반 마스킹 구현 사용. 보호된 MixColumns는 기존 행 마스크 흐름을 유지하는 구현 사용.
- FULL은 준비부터 최종 출력까지, ROUND1은 첫 라운드 AddRoundKey부터 MixColumns까지 포함.

## 검증
- 독립 AES·별칭·호스트 트리거 6012건 통과.
- 실제 제출 AVR 객체 두 모드 각 306건 AES 대조 통과. HEX 구조·체크섬, lookup_remasked의 초기화→로드→재마스킹 확인.
- 500개 암호화의 14500개 중간 상태를 독립 AES와 대조해 모든 라운드의 마스크 흐름 확인.
- ASan: 두 모드 각각 3968건 부분 중첩·암호문·canary 검사 통과.
- 최종 src 해시가 실제 빌드 소스와 일치함을 확인.

## 성능 비교의 한계
동일 NIST 입력·초기 PRNG 상태 1·시뮬레이터 타이머 0의 FULL 실행 명령 수는 31220개입니다.
전체 라운드 마스킹 precompute 버전의 39057개 대비 20.07% 감소했습니다. 1·10라운드만 보호한 fast94 후보는 같은 표본에서 32141개였으며, 이번 후보는 그보다 약 2.87% 적습니다.
이는 명령 실행 수 비교이며 실제 클럭 사이클이나 서버 점수 예측이 아닙니다. 실제 사이클 제한·최대 스택·보안 점수는 미확인입니다. 루프 펼치기와 함수화로 컴파일 결과·코드 크기·누설 양상이 달라질 수 있습니다. 사전 마스크 보정값 배열만으로 누설이 제거됐다고 주장하지 않습니다.
baseline에 포함된 과거 기록 중 watch-cycles를 하드웨어 사이클로 해석한 결론은 유효하지 않습니다. 이번 검증 도구는 해당 제한 통과를 보고하지 않습니다.

## 사용
평가 페이지에서 루트의 ROUND1/FULL HEX를 각각 업로드하고 기존 비교 제출과 같은 PRNG 입력 2바이트를 사용합니다. 난수 호출 정책은 변경하지 않았고, 공식 사용량 규정이 새롭게 확인됐다는 뜻은 아닙니다.
재검증: tools/verify.py --host --avr --firmware-root <firmware 폴더> --avr-bin <AVR bin 폴더>. Python/PyCryptodome, MSVC 및 ChipWhisperer AVR 도구 필요. build-support의 공용 SimpleSerial 파서를 적용한 격리 복사본에서 빌드합니다. 깊은 중간 상태 검사 스크립트에는 로컬 경로가 포함되어 있어 이동 시 수정이 필요합니다.
