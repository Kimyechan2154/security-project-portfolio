from pathlib import Path
import subprocess,ctypes as C,random,json,shutil
r=Path.cwd();base=r/'outputs/pepsi-round1-10'
oracle=(base/'tools/check_phases.py').read_text();exec(oracle[oracle.index('def xt(x)'):oracle.index('d=C.CDLL')])
vc=r'C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat'
results=[]
for name in ('local-keyptr','local-keyptr-mix','local-prekeys'):
 d=r/'outputs'/name;b=d/'key-check';b.mkdir(exist_ok=True)
 for f in ('myCrypt.c','myCrypt.h'):shutil.copyfile(d/'src'/f,b/f)
 (b/'hal.h').write_text('void trigger_high(void);void trigger_low(void);')
 (b/'check.c').write_text('''#include "myCrypt.c"
void trigger_high(void){} void trigger_low(void){}
__declspec(dllexport) void test_key(byte *key,byte *out,byte *v){build_key_sbox(v[0],v[1]);expand_masked_key(key,(byte (*)[16])out,v[0],v[1],v[2],v[3],v[4],v[5],v[6],v[7],v[8],v[9]);}
''')
 (b/'build.cmd').write_text(f'@echo off\ncall "{vc}" >nul\ncl /nologo /O2 /W4 /WX /LD check.c /link /OUT:check.dll /IMPLIB:check.lib\n')
 p=subprocess.run(['cmd.exe','/d','/c','build.cmd'],cwd=b,capture_output=True);assert p.returncode==0,p.stdout+p.stderr
 lib=C.CDLL(str(b/'check.dll'));lib.test_key.argtypes=[C.POINTER(C.c_ubyte)]*3
 rng=random.Random(20261105)
 for sample in range(1000):
  key=rng.randbytes(16);v=list(bytes(6) if sample==0 else rng.randbytes(6));n=mc(v[2:]*4)[:4];v+=n
  out=(C.c_ubyte*176)();lib.test_key((C.c_ubyte*16).from_buffer_copy(key),out,(C.c_ubyte*10)(*v))
  expected=sum(keys(key),[])
  assert all((out[i]^(v[1] if i>=160 else n[i&3]^v[0]))==expected[i] for i in range(176)),sample
 result={'variant':name,'independent_masked_key_schedules':1000,'bytes_per_schedule':176,'result':'PASS'}
 (b/'result.json').write_text(json.dumps(result,indent=2));print(result,flush=True);results.append(result)
(r/'outputs/overhead-analysis/daily-key-checks.json').write_text(json.dumps(results,indent=2))
