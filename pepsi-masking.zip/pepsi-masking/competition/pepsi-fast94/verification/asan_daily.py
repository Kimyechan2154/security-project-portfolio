from pathlib import Path
from Crypto.Cipher import AES
import subprocess,random,shutil,json
r=Path.cwd();d=r/'outputs/pepsi-fast94';b=d/'memory-check';b.mkdir(exist_ok=True)
for f in ('myCrypt.c','myCrypt.h'):shutil.copyfile(d/'src'/f,b/f)
(b/'hal.h').write_text('void trigger_high(void);void trigger_low(void);')
rng=random.Random(20261105);rows=[]
for _ in range(128):
 p,k=rng.randbytes(16),rng.randbytes(16);rows.append('{'+','.join(map(str,p+k+AES.new(k,AES.MODE_ECB).encrypt(p)))+'}')
code='''#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include "myCrypt.c"
static int events;
void trigger_high(void){events=events*10+1;}void trigger_low(void){events=events*10+2;}
static unsigned char cases[][48]={ROWS};
int main(void){unsigned char buf[96],before[96],key[16];int n,off,i;
for(n=0;n<128;n++)for(off=-15;off<=15;off++){
 memset(buf,165,sizeof(buf));memcpy(buf+40,cases[n],16);memcpy(before,buf,sizeof(buf));memcpy(key,cases[n]+16,16);events=0;
 Encrypt(buf+40,key,buf+40+off);
 if(events!=12 || memcmp(buf+40+off,cases[n]+32,16))return 2;
 for(i=0;i<96;i++)if((i<40+off || i>=56+off) && buf[i]!=before[i])return 3;
}puts("PASS: 3968 AES overlap/canary cases");return 0;}
'''.replace('ROWS',','.join(rows))
(b/'check.c').write_text(code)
vc=r'C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat'
for mode in (0,1):
 (b/'run.cmd').write_text(f'@echo off\ncall "{vc}" >nul\ncl /nologo /O2 /Zi /fsanitize=address /DCONTEST_FULL={mode} check.c /Fe:check{mode}.exe\nif errorlevel 1 exit /b 1\ncheck{mode}.exe\n')
 p=subprocess.run(['cmd.exe','/d','/c','run.cmd'],cwd=b,capture_output=True,text=True,errors='replace',timeout=60)
 (d/f'verification/asan-{mode}.log').write_text(p.stdout+p.stderr)
 assert p.returncode==0 and 'PASS:' in p.stdout,p.stdout+p.stderr
 print(mode,'ASan PASS',flush=True)
(d/'verification/asan.json').write_text(json.dumps({'cases_per_mode':3968,'modes':2,'result':'PASS','scope':'cipher and partial overlap, not UART parser'},indent=2))
