
#include <stdint.h>
#include <string.h>
#include <avr/io.h>
static uint8_t ref_masks[6],ref_n[4],ref_q[4],ref_change[4],ref_keys[176];
static uint8_t ref_order[16],ref_cols[4],ref_a[16],ref_b[16];
void trigger_high(void){} void trigger_low(void){}
#include "reference.c"
extern uint8_t masks[6],n_masks[4],q_masks[4],row_change[4],round_keys[176];
extern uint8_t order[16],columns[4],state_a[16],state_b[16],key_sbox[256];
extern uint32_t prng_state;
extern uint8_t abi_Encrypt(uint8_t*,uint8_t*,uint8_t*);
static uint8_t expect[112],actual[112];
static uint32_t seq=0x8d20a981UL;
static uint8_t next(void){seq^=seq<<13;seq^=seq>>17;seq^=seq<<5;return seq>>24;}
static void finish(uint8_t error){
 if(error){__asm__ volatile("out 0x32,%0"::"r"((uint8_t)('A'+error)));__asm__ volatile("out 0x29,%0"::"r"(error));}
 else {__asm__ volatile("out 0x32,%0"::"r"((uint8_t)'P'));__asm__ volatile("out 0x2f,%0"::"r"(error));}
 for(;;);
}
static void check(uint32_t seed,uint16_t timer,uint8_t output){
 uint8_t i;
 for(i=0;i<112;i++)expect[i]=next();
 memcpy(actual,expect,112);
 ref_prng_state=seed;TCC0.CNT=timer;
 ref_Encrypt(expect+16,expect+64,expect+output);
 prng_state=seed;TCC0.CNT=timer;
 if(abi_Encrypt(actual+16,actual+64,actual+output))finish(1);
 if(memcmp(actual,expect,112))finish(2);
 if(prng_state!=ref_prng_state)finish(3);
 if(memcmp(masks,ref_masks,6)||memcmp(n_masks,ref_n,4)||memcmp(q_masks,ref_q,4)||memcmp(row_change,ref_change,4))finish(4);
 if(memcmp(round_keys,ref_keys,176))finish(5);
 if(memcmp(order,ref_order,16)||memcmp(columns,ref_cols,4))finish(6);
 if(memcmp(state_a,ref_a,16)||memcmp(state_b,ref_b,16))finish(7);
 if(memcmp(key_sbox,ref_sbox,256))finish(8);
}
int main(void){
 uint16_t n;int8_t off;
 ContestRandomInit();
 for(n=0;n<64;n++){
  uint32_t seed=n==0?0:n==1?1:n==2?0xffffffffUL:n==3?0x80000000UL:seq;
  uint16_t timer=n==0?0:(uint16_t)(n*641u);
  check(seed,timer,96);check(seed,timer,16);check(seed,timer,64);
 }
 for(n=0;n<8;n++)for(off=-15;off<=15;off++){
  check(seq,(uint16_t)(n*2351u),(uint8_t)(16+off));
  check(seq,(uint16_t)(n*2351u),(uint8_t)(64+off));
 }
 finish(0);return 0;
}
