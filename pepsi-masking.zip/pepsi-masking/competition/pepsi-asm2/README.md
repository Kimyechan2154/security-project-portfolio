# PEPSI asm2 — 어셈블리 비용 감소 후보

기준: 직전 pepsi-asm. 사용자가 알려준 서버 결과는 21,563사이클, 오버헤드 1.54배,
성능 18.8/20, 입력 PRNG 2바이트입니다. 해당 결과의 보안 점수는 이번 메시지에서 제공되지 않았습니다.
새 후보의 서버 평가는 아직 하지 않았습니다.

## 제출할 두 파일

| 제출 칸 | 파일 |
|---|---|
| 1라운드 HEX | pepsi-asm2-ROUND1.hex |
| 전체 암호화 HEX | pepsi-asm2-FULL.hex |

ZIP 자체를 업로드하는 것이 아니라 위 두 HEX를 각각 선택합니다.
대상은 CWLITEXMEGA / ATxmega128D3 / SimpleSerial 2.1입니다.
이전 HEX와 어셈블리 원본은 baseline/에 별도로 보존했습니다.
원래 outputs/pepsi-asm 및 ZIP은 수정하지 않았습니다.

## 줄인 비용

1. MSbox를 256바이트 경계에, 키와 상태를 16바이트 경계에 배치해 반복 주소 계산을 줄였습니다.
2. 셔플 순서에 맞춘 ShiftRows 목적지와 행 마스크 보정값을 블록마다 한 번 계산해 모든 라운드가 재사용합니다.
3. SubBytes·ShiftRows 내부의 조회 호출을 펼쳐 CALL/RET를 줄였습니다. 각 조회의 CLR → LD → EOR는 유지합니다.
4. 키 확장 동안 마스크 보정값을 레지스터에 보관해 반복 메모리 읽기를 줄였습니다. 키 XOR/마스크 보정 순서는 유지합니다.
5. xorshift의 고정 횟수 시프트와 MSbox 생성 루프를 펼쳤습니다. 난수 출력과 호출 횟수는 같은 시드에서 기존과 동일합니다.

모든 라운드 마스킹, 단일 MSbox, 두 상태 버퍼, 블록마다 생성한 순열 재사용,
첫 등장 order[i]&3에 따른 MixColumns 열 순서, 별도 마지막 라운드 처리를 유지합니다.
MixColumns 내부 수식은 바꾸지 않았습니다. 추가 난수 호출은 없습니다.
FULL은 준비 작업과 암호화 출력까지 포함하고 ROUND1은 첫 SubBytes·ShiftRows와 MixColumns를 포함합니다.
속도를 위해 준비 작업을 FULL 측정 범위 밖으로 옮기지 않았습니다.

주소 정렬과 사전 계산용 저장 공간으로 RAM 사용량은 증가합니다. 정확한 빌드 크기는 verification/size-*.log를 참고합니다.
기존과 마찬가지로 정적 작업 공간을 사용하므로 재진입/동시 호출은 지원하지 않습니다.

## 확인된 결과와 한계

- 실제 제출 빌드 객체를 표준 AES(PyCryptodome)와 대조: 612건 통과.
- 같은 객체로 이전 C 기준 구현과 암호문, 난수 상태, MSbox, 마스크, 라운드 키, 순열, 열 순서, 상태 버퍼 대조: 1,376건 통과.
- 위 1,376건에 보존 레지스터/r1 검사, 입력·키와 출력의 부분 겹침 및 주변 버퍼 비교를 포함합니다.
- 실제 링크된 주소 정렬, 두 SubBytes 함수 각각의 16개 CLR/LD/EOR 조회, HEX 체크섬 검사 통과.
- 동일 NIST 입력, 초기 PRNG=1, 시뮬레이터 타이머=0에서 FULL 명령 수 15,457 → 10,768 (30.34% 감소).
- 같은 조건에서 ROUND1 명령 수 806 → 534.

명령 수는 실제 AVR 클럭 사이클이 아닙니다. 21,563사이클에 감소율을 곱한 값을 실측 결과로 쓰면 안 됩니다.
하드웨어 사이클 제한 통과, 새 오버헤드, 보안 점수와 100점 도달 여부는 서버 평가 전까지 미확인입니다.
기능/마스크 값의 일치는 물리적 누설 성능이 같다는 증명이 아닙니다.
PRNG 설정은 기존 타이머 16비트 혼합+xorshift를 유지했으며, 공식 PRNG 산정 기준은 추가 확인되지 않았습니다.

## 재검증

Python에 requirements.txt 의존성을 설치한 후 이 폴더에서 실행합니다.
설치된 펌웨어를 results/로 복사해 빌드하며 설치 원본을 수정하지 않습니다.

```powershell
python tools/verify.py --avr --firmware-root "C:/workspace/ChipWhisperer5_64/cw/workspace/chipwhisperer/hardware/victims/firmware" --avr-bin "C:/workspace/ChipWhisperer5_64/cw/workspace/avrgcc/bin"
python tools/verify_assembly.py --avr-bin "C:/workspace/ChipWhisperer5_64/cw/workspace/avrgcc/bin"
```

핵심 소스는 src/masked_aes.S이고 통신/HAL 어댑터만 C입니다.
origin/reference.c는 기능 대조용이며 제출 바이너리에 링크하지 않습니다.
기반 마스킹 수식 출처: Kimyechan2154/school PEPSI/Masking/masking.c,
Git blob 54e1cc7ce8927b1a2620e2c7f98b90f555f62209.
