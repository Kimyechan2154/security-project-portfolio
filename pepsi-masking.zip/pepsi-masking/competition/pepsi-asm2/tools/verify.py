"""Check the current source without modifying the installed firmware or baseline."""
from pathlib import Path
import argparse,ctypes as C,datetime,hashlib,json,os,random,re,shutil,subprocess,sys

ROOT=Path(__file__).resolve().parents[1]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def hex_check(p):
    memory={};base=0;ended=False
    for line in p.read_text().splitlines():
        if not line.startswith(':') or ended:raise ValueError(f'Invalid HEX record: {p}')
        v=bytes.fromhex(line[1:])
        if len(v)!=v[0]+5 or sum(v)%256:raise ValueError(f'Invalid HEX checksum: {p}')
        address=int.from_bytes(v[1:3],'big');kind=v[3]
        if kind==0:
            for i,x in enumerate(v[4:-1]):
                a=base+address+i
                if a in memory:raise ValueError('Overlapping HEX address')
                memory[a]=x
        elif kind==1:
            if v[0]!=0 or address:raise ValueError('Invalid EOF')
            ended=True
        elif kind in (2,4):
            if v[0]!=2 or address:raise ValueError('Invalid extended address')
            base=int.from_bytes(v[4:-1],'big')<<(4 if kind==2 else 16)
        else:raise ValueError(f'Unsupported HEX type {kind}')
    if not ended or not memory:raise ValueError('Missing HEX data/EOF')
    return {'status':'PASS','bytes':len(memory),'sha256':digest(p)}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--host',action='store_true');ap.add_argument('--avr',action='store_true')
    ap.add_argument('--vcvars',default='C:/Program Files/Microsoft Visual Studio/2022/Community/VC/Auxiliary/Build/vcvars64.bat')
    ap.add_argument('--firmware-root',type=Path);ap.add_argument('--avr-bin',type=Path)
    ap.add_argument('--unix-bin',type=Path,default=Path('C:/Program Files/Git/usr/bin'))
    args=ap.parse_args();
    if args.host:ap.error('Assembly has no host implementation; use --avr')
    cfg=json.loads((ROOT/'config.json').read_text())
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    out=ROOT/'results'/stamp;out.mkdir(parents=True)
    report={'status':'RUNNING','source_sha256':{p.name:digest(p) for p in (ROOT/'src').iterdir() if p.is_file()},'host':'NOT_RUN','avr':'NOT_RUN','server_security':'UNVERIFIED','hardware_measurements':'NOT_RUN','cycle_kind':'NOT_MEASURED: simulator event ticks are not AVR clock cycles'}
    def run(cmd,cwd,log,env=None,expected_nonzero=False):
        p=subprocess.run([str(x) for x in cmd],cwd=cwd,env=env,capture_output=True,text=True,errors='replace',timeout=60)
        text=p.stdout+p.stderr;(out/log).write_text(text,encoding='utf-8')
        if p.returncode and not expected_nonzero:raise RuntimeError(f'Command failed; see {log}')
        return text
    try:
        manifest=json.loads((ROOT/'baseline-manifest.json').read_text(encoding='utf-8'))
        changed=[name for name,h in manifest.items() if not (ROOT/name).is_file() or digest(ROOT/name)!=h]
        protected=[name for name in changed if name.startswith('baseline/')]
        if protected:raise ValueError('Preserved baseline changed: '+', '.join(protected))
        report['changed_from_baseline']=changed
        report['baseline_hex']={p.name:hex_check(p) for p in (ROOT/'baseline').rglob('*.hex')}
        if args.host or args.avr:
            from Crypto.Cipher import AES
            rng=random.Random(20261008)
            vectors=[(bytes.fromhex('00112233445566778899aabbccddeeff'),bytes(range(16))), (bytes(16),bytes(16))]+[(rng.randbytes(16),rng.randbytes(16)) for _ in range(1000)]
        if args.host:
            host=out/'host';shutil.copytree(ROOT/'src',host)
            (host/'hal.h').write_text('void trigger_high(void);void trigger_low(void);')
            (host/'harness.c').write_text('''#include "myCrypt.c"
static int events;
void trigger_high(void){events=events*10+1;}
void trigger_low(void){events=events*10+2;}
__declspec(dllexport) int test_encrypt(unsigned char *p,unsigned char *k,unsigned char *o){events=0;Encrypt(p,k,o);return events;}
''')
            if not Path(args.vcvars).is_file():raise ValueError('Set --vcvars to the installed vcvars64.bat')
            cases=0
            for mode in (0,1):
                (host/'compile.cmd').write_text(f'@echo off\ncall "{args.vcvars}" >nul\nif errorlevel 1 exit /b 1\ncl /nologo /O2 /W4 /WX /LD /DCONTEST_FULL={mode} harness.c /link /OUT:mode{mode}.dll /IMPLIB:mode{mode}.lib\n')
                run(['cmd.exe','/d','/c','compile.cmd'],host,f'host-{mode}.log')
                lib=C.CDLL(str(host/f'mode{mode}.dll'));lib.test_encrypt.argtypes=[C.POINTER(C.c_ubyte)]*3
                B=C.c_ubyte*16
                for pt,key in vectors:
                    expected=AES.new(key,AES.MODE_ECB).encrypt(pt)
                    for alias in range(3):
                        p,k,o=B.from_buffer_copy(pt),B.from_buffer_copy(key),B()
                        o=p if alias==1 else k if alias==2 else o
                        if lib.test_encrypt(p,k,o)!=12 or bytes(o)!=expected:raise ValueError(f'Host AES/trigger failed: mode={mode}, alias={alias}')
                        cases+=1
            report['host']={'status':'PASS','AES_alias_trigger_cases':cases}
            print('Host AES / aliases / trigger: PASS',flush=True)
        if args.avr:
            if not args.firmware_root or not args.avr_bin:raise ValueError('--avr requires --firmware-root and --avr-bin')
            fw=args.firmware_root.resolve();bin=args.avr_bin.resolve()
            if not (fw/'Makefile.inc').is_file():raise ValueError('firmware-root must contain Makefile.inc')
            build=out/'firmware';build.mkdir()
            shutil.copyfile(fw/'Makefile.inc',build/'Makefile.inc')
            for folder in ('hal','crypto','simpleserial'):shutil.copytree(fw/folder,build/folder)
            shutil.copytree(ROOT/'src',build/'simpleserial-contest')
            for p in (ROOT/'build-support').iterdir():shutil.copyfile(p,build/'simpleserial'/p.name)
            env=os.environ.copy();env['OS']='Linux';env['PATH']=str(bin)+';'+str(args.unix_bin)+';'+env['PATH']
            probe=out/'avr-probe';probe.mkdir();shutil.copyfile(ROOT/'src/myCrypt.h',probe/'myCrypt.h')
            (probe/'hal.h').write_text('void trigger_high(void);void trigger_low(void);')
            template=(ROOT/'tools/avr_test_template.c').read_text()
            vv=vectors[:102];items=['{'+','.join(str(x) for x in pt+key+AES.new(key,AES.MODE_ECB).encrypt(pt))+'}' for pt,key in vv]
            template=re.sub(r'cases\[\]\[48\] PROGMEM=\{.*?\};','cases[][48] PROGMEM={'+','.join(items)+'};',template,flags=re.S)
            template=template.replace('   if(events!=12)finish(3);','')
            (probe/'test.c').write_text(template)
            avresults=[]
            for mode,label in ((0,'ROUND1'),(1,'FULL')):
                cwd=build/'simpleserial-contest'
                run([bin/'make.exe','clean'],cwd,f'clean-{label}.log',env)
                run([bin/'make.exe',f'CONTEST_FULL={mode}'],cwd,f'build-{label}.log',env)
                h=out/f'{label}.hex';shutil.copyfile(cwd/'simpleserial-contest-CWLITEXMEGA.hex',h)
                check=hex_check(h)
                dis=run([bin/'avr-objdump.exe','-d',cwd/'simpleserial-contest-CWLITEXMEGA.elf'],cwd,f'{label}.dis',env)
                body=re.search(r'<lookup_remasked>:\s*(.*?)(?=^[0-9a-f]+ <|\Z)',dis,re.S|re.M)
                if not body or not re.search(r'eor\s+(r\d+),\s*\1\s*\n\s*[0-9a-f]+:.*ld\s+\1, Z\s*\n\s*[0-9a-f]+:.*eor\s+\1,',body.group(1)):raise ValueError('lookup_remasked clear/load/remask check failed')
                # The production SubBytes routines use inlined lookups.
                for function in ('sub_shift','sub_shift_final'):
                    section=re.search(r'<'+function+r'>:\s*(.*?)(?=^[0-9a-f]+ <|\Z)',dis,re.S|re.M).group(1)
                    hits=re.findall(r'eor\s+(r\d+),\s*\1\s*\n\s*[0-9a-f]+:.*ld\s+\1, Z\s*\n\s*[0-9a-f]+:.*eor\s+\1,',section)
                    if len(hits)!=16:raise ValueError(function+' inline lookup clear/load/remask check failed')
                symbols=run([bin/'avr-nm.exe','-n',cwd/'simpleserial-contest-CWLITEXMEGA.elf'],cwd,f'symbols-{label}.log',env)
                for name,alignment in (('key_sbox',256),('round_keys',16),('state_a',16),('state_b',16)):
                    addr=int(re.search(r'^([0-9a-f]+) [a-zA-Z] '+name+r'$',symbols,re.M).group(1),16)
                    if addr%alignment:raise ValueError(name+' address alignment failed')
                obj=probe/f'production-core-{label}.o'
                shutil.copyfile(cwd/'objdir-CWLITEXMEGA/masked_aes.o',obj)
                elf=probe/f'mode{mode}.elf'
                run([bin/'avr-gcc.exe','-mmcu='+cfg['mcu'],'-std=gnu99','-Os','-fpack-struct','-I.','test.c',obj,'-o',elf],probe,f'probe-build-{label}.log',env)
                sim=run([bin/'avr-run.exe','--watch-clock-int','10000',elf],probe,f'probe-AES-{label}.log',env)
                if 'P' not in sim:raise ValueError('AVR production-object AES check failed')
                pd=run([bin/'avr-objdump.exe','-d',elf],probe,f'probe-{label}.dis',env)
                high=re.search(r'^\s*([0-9a-f]+):.*sts\s+0x0605',pd,re.M).group(1)
                low=re.search(r'^\s*([0-9a-f]+):.*sts\s+0x0606',pd,re.M).group(1)
                budgets=[] # watch-cycles measures event ticks, not AVR clock cycles.
                size=run([bin/'avr-size.exe',cwd/'simpleserial-contest-CWLITEXMEGA.elf'],cwd,f'size-{label}.log',env)
                avresults.append({'mode':label,'HEX':check,'production_object_AES_cases':len(vv)*3,'lookup_sequence':'PASS','hardware_cycle_limit':'NOT_VERIFIED','size':size.strip()})
                print(f'{label} build / AVR AES / lookup: PASS (hardware cycles not verified)',flush=True)
            report['avr']={'status':'PASS','results':avresults}
        report['status']='PASS'
    except Exception as e:
        report['status']='FAILED';report['error']=str(e)
        print(str(e),file=sys.stderr)
    finally:
        (out/'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
        print(out/'report.json',flush=True)
    return 0 if report['status']=='PASS' else 1

if __name__=='__main__':sys.exit(main())
