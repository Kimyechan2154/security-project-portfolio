"""Execute submission assembly objects: ABI, C equivalence, overlap and instruction counts.
No board or physical leakage/cycle measurement is performed.
Run after verify.py --avr. Requires PyCryptodome and the installed AVR toolchain.
"""
from pathlib import Path
import subprocess,os,json,re,argparse
ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--avr-bin',type=Path,default=Path('C:/workspace/ChipWhisperer5_64/cw/workspace/avrgcc/bin'))
args=ap.parse_args();bin=args.avr_bin
latest=sorted((ROOT/'results').iterdir())[-1]
report=json.loads((latest/'report.json').read_text());assert report['status']=='PASS'
work=latest/'assembly-check';work.mkdir(exist_ok=True)
def run(cmd,log,timeout=60):
    p=subprocess.run([str(x) for x in cmd],cwd=work,capture_output=True,text=True,errors='replace',timeout=timeout)
    (work/log).write_text(p.stdout+p.stderr)
    if p.returncode:raise RuntimeError(log+': '+(p.stdout+p.stderr)[-1500:])
    return p.stdout
ref=(ROOT/'origin/reference.c').read_text()
ref=ref.replace('void Encrypt(', 'void ref_Encrypt(').replace('void ContestRandomInit(', 'void ref_Init(')
ref=re.sub(r'\bprng_state\b','ref_prng_state',ref)
ref=re.sub(r'\bkey_sbox\b','ref_sbox',ref)
# Snapshot at the end of the reference Encrypt function, not the production core.
end=ref.rfind('\n}')
ref=ref[:end]+'''
    ref_masks[0]=m;ref_masks[1]=key_output_mask;
    ref_masks[2]=row_mask0;ref_masks[3]=row_mask1;
    ref_masks[4]=row_mask2;ref_masks[5]=row_mask3;
    memcpy(ref_n,n,4);memcpy(ref_change,row_change,4);
    for(i=0;i<4;i++)ref_q[i]=n[i]^m;
    memcpy(ref_keys,round_keys,176);memcpy(ref_order,order,16);
    memcpy(ref_cols,columns,4);memcpy(ref_a,state_a,16);memcpy(ref_b,state_b,16);
'''+ref[end:]
(work/'reference.c').write_text(ref)
(work/'myCrypt.h').write_text((ROOT/'src/myCrypt.h').read_text())
(work/'hal.h').write_text('void trigger_high(void);void trigger_low(void);')
regs=list(range(2,18))+[28,29]
abi='''.text
.global abi_Encrypt
.type abi_Encrypt,@function
abi_Encrypt:
'''
abi+='\n'.join(f'push r{i}' for i in regs)+'\n'
for i in regs:abi+=f'ldi r18,{(i*7+13)&255}\nmov r{i},r18\n'
abi+='call Encrypt\ntst r1\nbrne .Lbad\n'
for i in regs:abi+=f'ldi r18,{(i*7+13)&255}\ncp r{i},r18\nbrne .Lbad\n'
abi+='clr r24\nrjmp .Ldone\n.Lbad:\nldi r24,1\nclr r1\n.Ldone:\n'
abi+='\n'.join(f'pop r{i}' for i in reversed(regs))+'\nret\n.size abi_Encrypt,.-abi_Encrypt\n'
(work/'abi.S').write_text(abi)
h=r'''
#include <stdint.h>
#include <string.h>
#include <avr/io.h>
static uint8_t ref_masks[6],ref_n[4],ref_q[4],ref_change[4],ref_keys[176];
static uint8_t ref_order[16],ref_cols[4],ref_a[16],ref_b[16];
void trigger_high(void){} void trigger_low(void){}
#include "reference.c"
extern uint8_t masks[6],n_masks[4],q_masks[4],row_change[4],round_keys[176];
extern uint8_t order[16],columns[4],state_a[16],state_b[16],key_sbox[256];
extern uint32_t prng_state;
extern uint8_t abi_Encrypt(uint8_t*,uint8_t*,uint8_t*);
static uint8_t expect[112],actual[112];
static uint32_t seq=0x8d20a981UL;
static uint8_t next(void){seq^=seq<<13;seq^=seq>>17;seq^=seq<<5;return seq>>24;}
static void finish(uint8_t error){
 if(error){__asm__ volatile("out 0x32,%0"::"r"((uint8_t)('A'+error)));__asm__ volatile("out 0x29,%0"::"r"(error));}
 else {__asm__ volatile("out 0x32,%0"::"r"((uint8_t)'P'));__asm__ volatile("out 0x2f,%0"::"r"(error));}
 for(;;);
}
static void check(uint32_t seed,uint16_t timer,uint8_t output){
 uint8_t i;
 for(i=0;i<112;i++)expect[i]=next();
 memcpy(actual,expect,112);
 ref_prng_state=seed;TCC0.CNT=timer;
 ref_Encrypt(expect+16,expect+64,expect+output);
 prng_state=seed;TCC0.CNT=timer;
 if(abi_Encrypt(actual+16,actual+64,actual+output))finish(1);
 if(memcmp(actual,expect,112))finish(2);
 if(prng_state!=ref_prng_state)finish(3);
 if(memcmp(masks,ref_masks,6)||memcmp(n_masks,ref_n,4)||memcmp(q_masks,ref_q,4)||memcmp(row_change,ref_change,4))finish(4);
 if(memcmp(round_keys,ref_keys,176))finish(5);
 if(memcmp(order,ref_order,16)||memcmp(columns,ref_cols,4))finish(6);
 if(memcmp(state_a,ref_a,16)||memcmp(state_b,ref_b,16))finish(7);
 if(memcmp(key_sbox,ref_sbox,256))finish(8);
}
int main(void){
 uint16_t n;int8_t off;
 ContestRandomInit();
 for(n=0;n<64;n++){
  uint32_t seed=n==0?0:n==1?1:n==2?0xffffffffUL:n==3?0x80000000UL:seq;
  uint16_t timer=n==0?0:(uint16_t)(n*641u);
  check(seed,timer,96);check(seed,timer,16);check(seed,timer,64);
 }
 for(n=0;n<8;n++)for(off=-15;off<=15;off++){
  check(seq,(uint16_t)(n*2351u),(uint8_t)(16+off));
  check(seq,(uint16_t)(n*2351u),(uint8_t)(64+off));
 }
 finish(0);return 0;
}
'''
(work/'equivalence.c').write_text(h)
results=[]
# Link the same object copied from each actual submission build.
for mode,label in ((0,'ROUND1'),(1,'FULL')):
    obj=latest/f'avr-probe/production-core-{label}.o'
    assert obj.is_file(),'Run verify.py --avr first'
    elf=work/f'check-{label}.elf'
    run([bin/'avr-gcc.exe','-mmcu=atxmega128d3','-std=gnu99','-Os','-I.',f'-DCONTEST_FULL={mode}','equivalence.c','abi.S',obj,'-o',elf],f'link-{label}.log')
    out=run([bin/'avr-run.exe','--watch-clock-int','10000',elf],f'equivalence-{label}.log')
    assert out.strip()=='P',out
    # Baseline primary tests already used the original production object.
    results.append({'mode':label,'equivalence_ABI_overlap_cases':688,'status':'PASS'})
    print(label+': 688 C-equivalence / ABI / overlap cases PASS',flush=True)

# Count instructions between the GPIO trigger writes in the production-object
# probes. This is explicitly NOT a hardware cycle measurement.
counts={}
for mode,label in ((0,'ROUND1'),(1,'FULL')):
    dis=(latest/f'probe-{label}.dis').read_text()
    high=re.search(r'^\s*([0-9a-f]+):.*sts\s+0x0605',dis,re.M).group(1)
    low=re.search(r'^\s*([0-9a-f]+):.*sts\s+0x0606',dis,re.M).group(1)
    commands=f'''set pagination off
set confirm off
target sim
load
break Encrypt
run
set {{unsigned long}}&prng_state=1
break *0x{high}
continue
set $n=(unsigned long)0
while $pc != 0x{low} && $n < 200000
stepi
set $n=$n+1
end
printf "INSTRUCTIONS %lu\\n", $n
quit
'''
    (work/'count.gdb').write_text(commands)
    trace=run([bin/'avr-gdb.exe','--batch','-x','count.gdb',latest/f'avr-probe/mode{mode}.elf'],f'instructions-{label}.log')
    count=int(re.search(r'INSTRUCTIONS (\d+)',trace).group(1));assert count<200000
    counts[label]=count
result={'status':'PASS','checks':results,'instructions':counts,'comparison_FULL_baseline_instructions':15457,'units':'executed instructions, NOT clock cycles','sample':'NIST first vector, initial PRNG state=1, timer=0','hardware_cycles':'NOT_MEASURED','server_security':'NOT_EVALUATED'}
(work/'report.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
