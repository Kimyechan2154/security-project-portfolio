#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdint.h> //8비트 정수 사용을 위함
#include <time.h>   // time()
#include <stdlib.h>

typedef uint8_t byte; //8비트 부호없는 정수형을 byte로 정의

#define AES_BLOCK_SIZE 16 // AES 블록 크기 (16바이트)
#define AES_ROUND_SIZE 16 //각 라운드 키 크기 (16바이트)
#define AES_KEY_SIZE 16 // AES 키 크기 (16바이트, 128비트)


//랜덤 값인 m, m' 설정
void rand_num(byte* m, byte* m_prime, byte* m1, byte* m2, byte* m3, byte* m4) {

	*m = rand() & 0xFF;
	*m_prime = rand() & 0xFF;

	*m1 = rand() & 0xFF;
	*m2 = rand() & 0xFF;
	*m3 = rand() & 0xFF;
	*m4 = rand() & 0xFF;
}

// AES 표준 S-Box (값 변경 방지를 위해 const 사용)
const byte sbox[256] = {
	0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
	0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
	0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
	0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
	0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
	0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
	0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
	0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
	0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
	0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
	0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
	0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
	0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
	0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
	0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
	0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
};

byte MSbox[256];

void M_MSbox(byte m, byte m_prime) {

	for (int byte_idx = 0; byte_idx < 256; byte_idx++) {
		MSbox[byte_idx ^ m] = sbox[byte_idx] ^ m_prime;
	}
}

//byte xtime(byte x) {
//	if (x & 0x80) { //오버플로우 발생시
//		return (x << 1) ^ 0x1b;
//	}
//	else {
//		return (x << 1);
//	}
//}

static inline byte xtime(byte x) {
	return (x << 1) ^ (((x >> 7) & 1) * 0x1b); // 피드백 새로 만든  xtime
}

const byte Rcon[10] = {
	0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36 //피드백 더미데이터 삭제
};

void SubBytes(byte state[16]) {

	for (int byte_idx = 0; byte_idx < AES_BLOCK_SIZE; byte_idx++)
	{
		state[byte_idx] = sbox[state[byte_idx]]; // S-Box를 사용하여 바이트 치환
	}
}

void M_SubBytes(byte state[16]) {//값을 변경하지 않고 MSbox를 불러옴

	for (int byte_idx = 0; byte_idx < AES_BLOCK_SIZE; byte_idx++)
	{
		state[byte_idx] = MSbox[state[byte_idx]]; // S-Box를 사용하여 바이트 치환
	}
}


void ShiftRows(byte state[16]) {

	byte temp;
	// 2번째 행 시프트
	temp = state[1];
	state[1] = state[5];
	state[5] = state[9];
	state[9] = state[13];
	state[13] = temp;
	// 3번째 행 시프트
	temp = state[2]; state[2] = state[10]; state[10] = temp;
	temp = state[6]; state[6] = state[14]; state[14] = temp;

	// 4번째 행 시프트
	temp = state[3];
	state[3] = state[15];
	state[15] = state[11];
	state[11] = state[7];
	state[7] = temp;
}


void M_ShiftRows(byte state[16], byte m_prime, byte m1, byte m2, byte m3, byte m4) {

	byte temp;

	// 1번째 행 M_시프트
	state[0] ^=  m1;
	state[4] ^= m1;
	state[8] ^= m1;
	state[12] ^= m1;


	// 2번째 행 M_시프트
	temp = state[1] ^ m2;
	state[1] = state[5] ^ m2;
	state[5] = state[9] ^ m2;
	state[9] = state[13] ^ m2;
	state[13] = temp;
	// 3번째 행 M_시프트
	temp = state[2] ^ m3; state[2] = state[10] ^ m3; state[10] = temp;
	temp = state[6] ^ m3; state[6] = state[14] ^ m3; state[14] = temp;

	// 4번째 행 M_시프트
	temp = state[3] ^ m4;
	state[3] = state[15] ^ m4;
	state[15] = state[11] ^ m4;
	state[11] = state[7] ^ m4;
	state[7] = temp;

	for (int byte_idx = 0; byte_idx < AES_BLOCK_SIZE; byte_idx++)
	{
		state[byte_idx] ^= m_prime; // M' 제거
	}
}

void MixColumns(byte state[16]) {
	byte s0, s1, s2, s3;

	for (int i = 0; i < 16; i += 4) {
		s0 = state[i];
		s1 = state[i + 1];
		s2 = state[i + 2];
		s3 = state[i + 3]; //백업

		state[i] = xtime(s0) ^ (xtime(s1) ^ s1) ^ s2 ^ s3; // 2 3 1 1
		state[i + 1] = s0 ^ xtime(s1) ^ (xtime(s2) ^ s2) ^ s3; // 1 2 3 1
		state[i + 2] = s0 ^ s1 ^ xtime(s2) ^ (xtime(s3) ^ s3); // 1 1 2 3
		state[i + 3] = (xtime(s0) ^ s0) ^ s1 ^ s2 ^ xtime(s3); // 3 1 1 2
	}
}

void KeyExpansion(byte key[16], byte roundKeys[11][16]) {

	byte* expandedkey = (byte*)roundKeys;
	byte temp[4];


	for (int i = 0; i < 16; i++) {
		expandedkey[i] = key[i];
	}
	for (int i = 16; i < 176; i += 4) {

		temp[0] = expandedkey[i - 4];
		temp[1] = expandedkey[i - 3];
		temp[2] = expandedkey[i - 2];
		temp[3] = expandedkey[i - 1];

		if (i % 16 == 0) {

			byte t = temp[0]; //배열후 회전
			temp[0] = temp[1];
			temp[1] = temp[2];
			temp[2] = temp[3];
			temp[3] = t;

			temp[0] = sbox[temp[0]]; //S-Box 치환
			temp[1] = sbox[temp[1]];
			temp[2] = sbox[temp[2]];
			temp[3] = sbox[temp[3]];

			temp[0] ^= Rcon[(i / 16) - 1]; //Rcon 상수 더하기 + 피드백
		}

		//최종 계산 및 저장
		expandedkey[i] = expandedkey[i - 16] ^ temp[0];
		expandedkey[i + 1] = expandedkey[i - 15] ^ temp[1];
		expandedkey[i + 2] = expandedkey[i - 14] ^ temp[2];
		expandedkey[i + 3] = expandedkey[i - 13] ^ temp[3];
	}
}

//
void M_KeyExpansion(
	byte key[16], byte roundKeys[11][16], byte m, byte m_prime,
	byte m1, byte m2, byte m3, byte m4, byte m1_prime, byte m2_prime, byte m3_prime, byte m4_prime)
{
	// 키 스케줄 구현
	byte Wm[44][4];
	byte mask_prime[4] = { m1_prime,m2_prime, m3_prime, m4_prime };
	// 초기 키 세팅
	for (int j = 0; j < 4;j++) {
		for (int byte_idx = 0; byte_idx < 4; byte_idx++) {
			Wm[j][byte_idx] = key[byte_idx + 4*j] ^ mask_prime[byte_idx] ^ m;
		}
	}

	//1~9 라운드 반복
	for (int round = 0; round < 9; round++)
	{
		Wm[4 * (round + 1)][0] = Wm[4 * round][0] ^ (MSbox[Wm[4 * round + 3][1] ^ m2_prime] ^ m_prime) ^ Rcon[round];
		Wm[4 * (round + 1)][1] = Wm[4 * round][1] ^ (MSbox[Wm[4 * round + 3][2] ^ m3_prime] ^ m_prime);
		Wm[4 * (round + 1)][2] = Wm[4 * round][2] ^ (MSbox[Wm[4 * round + 3][3] ^ m4_prime] ^ m_prime);
		Wm[4 * (round + 1)][3] = Wm[4 * round][3] ^ (MSbox[Wm[4 * round + 3][0] ^ m1_prime] ^ m_prime);

		// W5m, W9m, W13m ...
		Wm[4 * (round + 1) + 1][0] = Wm[4 * round + 1][0] ^ Wm[4 * (round + 1)][0] ^ m1_prime ^ m;
		Wm[4 * (round + 1) + 1][1] = Wm[4 * round + 1][1] ^ Wm[4 * (round + 1)][1] ^ m2_prime ^ m;
		Wm[4 * (round + 1) + 1][2] = Wm[4 * round + 1][2] ^ Wm[4 * (round + 1)][2] ^ m3_prime ^ m;
		Wm[4 * (round + 1) + 1][3] = Wm[4 * round + 1][3] ^ Wm[4 * (round + 1)][3] ^ m4_prime ^ m;

		// W6m, W10m, W14m ...
		Wm[4 * (round + 1) + 2][0] = Wm[4 * round + 2][0] ^ Wm[4 * (round + 1) + 1][0] ^ m1_prime ^ m;
		Wm[4 * (round + 1) + 2][1] = Wm[4 * round + 2][1] ^ Wm[4 * (round + 1) + 1][1] ^ m2_prime ^ m;
		Wm[4 * (round + 1) + 2][2] = Wm[4 * round + 2][2] ^ Wm[4 * (round + 1) + 1][2] ^ m3_prime ^ m;
		Wm[4 * (round + 1) + 2][3] = Wm[4 * round + 2][3] ^ Wm[4 * (round + 1) + 1][3] ^ m4_prime ^ m;

		// W7m, W11m, W15m ...
		Wm[4 * (round + 1) + 3][0] = Wm[4 * round + 3][0] ^ Wm[4 * (round + 1) + 2][0] ^ m1_prime ^ m;
		Wm[4 * (round + 1) + 3][1] = Wm[4 * round + 3][1] ^ Wm[4 * (round + 1) + 2][1] ^ m2_prime ^ m;
		Wm[4 * (round + 1) + 3][2] = Wm[4 * round + 3][2] ^ Wm[4 * (round + 1) + 2][2] ^ m3_prime ^ m;
		Wm[4 * (round + 1) + 3][3] = Wm[4 * round + 3][3] ^ Wm[4 * (round + 1) + 2][3] ^ m4_prime ^ m;
	}

	//10라운드 : W36~W39 → W40~W43
	Wm[40][0] = Wm[36][0] ^ m1_prime ^ m ^ m_prime ^ (MSbox[Wm[39][1] ^ m2_prime] ^ m_prime) ^ Rcon[9];
	Wm[40][1] = Wm[36][1] ^ m2_prime ^ m ^ m_prime ^ (MSbox[Wm[39][2] ^ m3_prime] ^ m_prime);
	Wm[40][2] = Wm[36][2] ^ m3_prime ^ m ^ m_prime ^ (MSbox[Wm[39][3] ^ m4_prime] ^ m_prime);
	Wm[40][3] = Wm[36][3] ^ m4_prime ^ m ^ m_prime ^ (MSbox[Wm[39][0] ^ m1_prime] ^ m_prime);

	// W41m
	Wm[41][0] = Wm[37][0] ^ Wm[40][0] ^ m1_prime ^ m;
	Wm[41][1] = Wm[37][1] ^ Wm[40][1] ^ m2_prime ^ m;
	Wm[41][2] = Wm[37][2] ^ Wm[40][2] ^ m3_prime ^ m;
	Wm[41][3] = Wm[37][3] ^ Wm[40][3] ^ m4_prime ^ m;

	// W42m
	Wm[42][0] = Wm[38][0] ^ Wm[41][0] ^ m1_prime ^ m;
	Wm[42][1] = Wm[38][1] ^ Wm[41][1] ^ m2_prime ^ m;
	Wm[42][2] = Wm[38][2] ^ Wm[41][2] ^ m3_prime ^ m;
	Wm[42][3] = Wm[38][3] ^ Wm[41][3] ^ m4_prime ^ m;

	// W43m
	Wm[43][0] = Wm[39][0] ^ Wm[42][0] ^ m1_prime ^ m;
	Wm[43][1] = Wm[39][1] ^ Wm[42][1] ^ m2_prime ^ m;
	Wm[43][2] = Wm[39][2] ^ Wm[42][2] ^ m3_prime ^ m;
	Wm[43][3] = Wm[39][3] ^ Wm[42][3] ^ m4_prime ^ m;

	// 라운드 키에 옮기기
	//3중 포문 사용
	for (int round = 0; round < 11; round++)
	{
		for (int word = 0; word < 4; word++) {
			for (int byte = 0; byte < 4; byte++) {
				roundKeys[round][word * 4 + byte] = Wm[round*4+word][byte];
			}
		}
	}
}


void AddRoundKey(byte state[16], byte roundKey[16]) {
	for (int byte_idx = 0; byte_idx < AES_BLOCK_SIZE; byte_idx++) {
		state[byte_idx] ^= roundKey[byte_idx]; // 라운드 키와 상태를 XOR 연산
	}
}

void AES_Encrypt(byte input[16], byte roundKeys[11][16], byte m, byte m_prime, byte m1, byte m2, byte m3, byte m4) {

	AddRoundKey(input, roundKeys[0]); // 초기 라운드 키 추가

	for (int round = 1; round <= 9; round++) {
		M_SubBytes(input);
		M_ShiftRows(input, m_prime,  m1, m2, m3, m4);
		MixColumns(input);
		AddRoundKey(input, roundKeys[round]);
	}

	M_SubBytes(input);
	ShiftRows(input);
	AddRoundKey(input, roundKeys[10]); // 마지막 라운드 키 추가
} // xtime 함수 구현 // 믹스컬럼 f함수 구현 끝 결과값 키스케쥴 확인 암호문 확인

int main() {

	srand((unsigned int)time(NULL)); //1회 실행

	byte key[16] = { //더미 추가
		0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
		0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c
	}; // fips197에 정해진 비밀키

	byte plaintext[16] = { //더미 추가
		0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d,
		0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34
	}; // fips197에 정해진 평문

	byte state[16];

	byte m, m_prime, m1, m2, m3, m4;
	byte m1_prime, m2_prime, m3_prime, m4_prime;

	rand_num(&m, &m_prime, &m1, &m2, &m3, &m4); //m 불러오기


	M_MSbox(m, m_prime);

	//n계산 하기 
	byte n1 = xtime(m1) ^ (xtime(m2) ^ m2) ^ m3 ^ m4;
	byte n2 = m1 ^ xtime(m2) ^ (xtime(m3) ^ m3) ^ m4;
	byte n3 = m1 ^ m2 ^ xtime(m3) ^ (xtime(m4) ^ m4);
	byte n4 = (xtime(m1) ^ m1) ^ m2 ^ m3 ^ xtime(m4);

	m1_prime = n1;
	m2_prime = n2;
	m3_prime = n3;
	m4_prime = n4;

	byte AES_secret_key[11][16]; //AES 키 생성

	//마스킹 키스케줄 불러오기
	M_KeyExpansion(key, AES_secret_key,
		m, m_prime, m1, m2, m3, m4,
		m1_prime, m2_prime, m3_prime, m4_prime);

	//이중 포문으로 각각 m1~m4까지 마스킹함
	for (int i = 0; i < 4; i++)
	{
		state[i * 4] = plaintext[i * 4] ^ n1;
		state[(i * 4) + 1] = plaintext[(i * 4) + 1] ^ n2;
		state[(i * 4) + 2] = plaintext[(i * 4) + 2] ^ n3;
		state[(i * 4) + 3] = plaintext[(i * 4) + 3] ^ n4;
	}

	//KeyExpansion(key, AES_secret_key); //키 세팅

	////키에 m마스킹해줌

	//for (int i = 0; i < 4; i++)
	//{
	//	AES_secret_key[0][i*4] ^= m ^ n1;
	//	AES_secret_key[0][(i * 4) + 1] ^= m ^ n2;
	//	AES_secret_key[0][(i * 4) + 2] ^= m ^ n3;
	//	AES_secret_key[0][(i * 4) + 3] ^= m ^ n4;
	//}

	//byte mixed_masks[4] = { n1, n2, n3, n4 };

	//for (int round = 1; round <= 9; round++) {
	//	for (int byte_idx = 0; byte_idx < AES_BLOCK_SIZE; byte_idx++) {
	//		AES_secret_key[round][byte_idx] ^=
	//			mixed_masks[byte_idx % 4] ^ m;
	//	}
	//}

	//for (int byte_idx = 0; byte_idx < AES_BLOCK_SIZE; byte_idx++) {
	//	AES_secret_key[10][byte_idx] ^= m_prime;
	//}

	AES_Encrypt(state, AES_secret_key, m, m_prime, m1, m2, m3, m4); //평문 ->암호문 변환

	for (int i = 0; i < 16; i++) {
		printf("%02x ", state[i]);
	} //결과 출력
	printf("\n");
}

