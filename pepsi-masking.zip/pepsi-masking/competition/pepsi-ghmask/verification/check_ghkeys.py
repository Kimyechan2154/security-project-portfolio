from pathlib import Path
import subprocess,ctypes as C,random,json,shutil
r=Path.cwd();d=r/'outputs/pepsi-ghmask';b=d/'key-check';b.mkdir(exist_ok=True)
oracle=(r/'outputs/pepsi-round1-10/tools/check_phases.py').read_text();exec(oracle[oracle.index('def xt(x)'):oracle.index('d=C.CDLL')])
for f in ('myCrypt.c','myCrypt.h'):shutil.copyfile(d/'src'/f,b/f)
shutil.copyfile(d/'origin/masking.c',b/'origin.c');(b/'hal.h').write_text('void trigger_high(void);void trigger_low(void);')
(b/'modified.c').write_text('''#include "myCrypt.c"
void trigger_high(void){}void trigger_low(void){}
__declspec(dllexport) void test_key(byte*k,byte*out,byte*v){build_key_sbox(v[0],v[1]);M_KeyExpansion(k,(byte(*)[16])out,v[0],v[1],v[2],v[3],v[4],v[5],v[6],v[7],v[8],v[9]);}
''')
(b/'upstream.c').write_text('''#define main upstream_main
#include "origin.c"
#undef main
__declspec(dllexport) void test_key(byte*k,byte*out,byte*v){M_MSbox(v[0],v[1]);M_KeyExpansion(k,(byte(*)[16])out,v[0],v[1],v[2],v[3],v[4],v[5],v[6],v[7],v[8],v[9]);}
''')
vc=r'C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat'
libs=[]
for name in ('modified','upstream'):
 (b/'build.cmd').write_text(f'@echo off\ncall "{vc}" >nul\ncl /nologo /utf-8 /O2 /LD {name}.c /link /OUT:{name}.dll /IMPLIB:{name}.lib\n')
 p=subprocess.run(['cmd.exe','/d','/c','build.cmd'],cwd=b,capture_output=True);assert p.returncode==0,p.stdout+p.stderr
 lib=C.CDLL(str(b/f'{name}.dll'));lib.test_key.argtypes=[C.POINTER(C.c_ubyte)]*3;libs.append(lib)
rng=random.Random(20261105)
for sample in range(1000):
 key=rng.randbytes(16);v=list(bytes(6) if sample==0 else rng.randbytes(6));n=mc(v[2:]*4)[:4];v+=n;expected=sum(keys(key),[]);outputs=[]
 for lib in libs:
  out=(C.c_ubyte*176)();lib.test_key((C.c_ubyte*16).from_buffer_copy(key),out,(C.c_ubyte*10)(*v));outputs.append(bytes(out))
  assert all((out[i]^(v[1] if i>=160 else n[i&3]^v[0]))==expected[i] for i in range(176)),sample
 assert outputs[0]==outputs[1]
result={'samples':1000,'key_bytes_per_sample':176,'upstream_vs_modified':'PASS','both_vs_independent_GF_AES':'PASS','final_round_mask':'PASS'}
(b/'result.json').write_text(json.dumps(result,indent=2));print(result)
