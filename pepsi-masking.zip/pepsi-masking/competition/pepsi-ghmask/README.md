# GitHub Masking 기반 제출 후보

제출 파일: pepsi-ghmask-ROUND1.hex / pepsi-ghmask-FULL.hex. 수정 소스: src/myCrypt.c.
기준 원본: https://github.com/Kimyechan2154/school/blob/main/PEPSI/Masking/masking.c
확인한 원본 Git blob: 54e1cc7ce8927b1a2620e2c7f98b90f555f62209.
origin/masking.c는 가져온 텍스트 원본이며 provenance.json에 출처·해시를 기록했습니다. main 브랜치는 나중에 바뀔 수 있으므로 위 blob을 기준으로 합니다.

## 원본에서 가져온 것과 변경
| 원본 | 이번 구현 |
|---|---|
| sbox, Rcon, M_MSbox | 원본 상수와 MSbox 구축식을 사용. 내부 이름은 aes_sbox, round_constants, build_key_sbox |
| M_KeyExpansion의 1~9라운드 | 원본의 펼친 4바이트 워드 수식 유지. 원본 Wm을 round_keys에 직접 저장해 176바이트 중복 버퍼·복사 제거 |
| M_KeyExpansion의 10라운드 | 원본처럼 별도 처리. 최종 키 마스크 m′ 전환식을 안전한 순서의 helper로 구현 |
| 키 스케줄 XOR 식 | 기존 AVR masked_different/same/remask를 사용해 마스크 해제 순서를 통제 |
| M_SubBytes, M_ShiftRows | M_SubBytes_ShiftRows로 합쳐 16개 바이트 처리를 펼침. 두 상태 버퍼와 order[0..15] 셔플 유지 |
| M_ShiftRows에서 행 마스크 적용 후 m′ 제거 | 암호화 준비에서 row_change[row]=m′ XOR m_row를 계산하고 조회 직후 보정. 고정 순서의 별도 마스크 제거 루프를 넣지 않음 |
| 마지막 SubBytes/ShiftRows | 전용 M_SubBytes_ShiftRows_final 함수 사용. 바이트별 마지막 라운드 if 제거 |
| rand/time/고정 예제 main | 기존 대회용 타이머+xorshift32·Encrypt·SimpleSerial2.1 어댑터로 교체 |

원본을 그대로 AVR에 컴파일한 것이 아니라 원본의 마스킹 수식·펼친 키 확장을 이식하고 기존 검증된 제출 어댑터와 셔플링·레지스터 초기화를 결합한 파생 구현입니다. 원본에 없는 셔플링은 기존 버전에서 유지했습니다. 별도 ShiftRows 복사 루프는 추가하지 않았습니다.
모든 라운드 상태 마스킹, MSbox 하나, 행 마스크 흐름, lookup_remasked의 AVR 레지스터 초기화, ROUND1/FULL 트리거 위치를 유지했습니다. 외부 라운드 반복문 등은 남아 있으며 코드의 모든 for/if를 없앤 것은 아닙니다.

## 실행한 검증
- 호스트 독립 AES·출력 별칭·트리거 6012건 통과.
- 실제 제출용 AVR 객체: 두 모드 각 306건 AES 대조, lookup 초기화→로드→재마스킹, HEX 구조·체크섬 통과.
- 원본 M_KeyExpansion과 수정 M_KeyExpansion을 각각 컴파일해 1000개 키·마스크 조합, 각 176바이트를 대조. 완전 일치. 두 구현 모두 독립 GF 기반 AES 키 확장과 일치. 10라운드 마스크 포함.
- 500개 암호화의 14500개 중간 상태를 독립 AES와 비교하여 전체 라운드 마스크 흐름 확인.
- ASan: 두 모드 각각 3968개 부분 중첩·암호문·canary 검사 통과.
- 배포 src 해시와 실제 빌드 소스의 일치 확인. 관찰용 테스트 코드는 src에 포함하지 않음.

## 성능 및 한계
같은 NIST 입력·PRNG 상태 1·시뮬레이터 타이머 0의 FULL 실행 명령 수: 이전 unroll 31220 → 이번 25666 (17.79% 감소).
실제 AVR 클럭 사이클 감소율이나 서버 점수 예측이 아닙니다. 하드웨어 사이클 제한·최대 스택·서버 보안 점수는 미확인입니다. 사전 보정값 배열만으로 누설 제거를 보장하지 않습니다. 타이머+xorshift32의 엔트로피 문제는 그대로 남습니다. baseline 내부 과거 watch-cycles 기록을 실제 하드웨어 사이클로 해석하면 안 됩니다.

## 제출/재빌드
위 HEX 두 개를 각각 제출하고 비교 조건은 이전과 동일하게 유지합니다. PRNG 입력 2바이트는 기존 비교 설정이며 공식 사용량 정의를 새롭게 확정한 의미는 아닙니다. GitHub 저장소에는 변경을 올리지 않았습니다.
src를 firmware/simpleserial-contest로 배치하고 build-support 공용 simpleserial.c/.h를 적용한 복사본에서 make clean 및 make CONTEST_FULL=0/1을 각각 실행합니다. tools/verify.py --host --avr --firmware-root <firmware 경로> --avr-bin <AVR bin 경로>로 재검증할 수 있습니다. Python/PyCryptodome·MSVC·ChipWhisperer AVR 도구 필요. 심층 검사 스크립트의 로컬 경로는 이동 시 조정해야 합니다.
