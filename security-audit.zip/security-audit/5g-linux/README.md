# 5G_Measure_Tool

VMware에 구축한 **Open5GS 5G SA 코어(Ubuntu 22.04 + MongoDB)** 환경을 대상으로,
[`5G_Check_Tool`](https://github.com/Crew-of-Offensive-R-E/5G_Check_Tool)(확인팀)이 판정한
**자동 항목의 `취약`을 `양호`로 전환**하는 조치 도구.

- **확인팀(별도 저장소, `5G_Check_Tool`)** — 각 항목이 기준에 맞는지 점검(읽기 전용)
- **조치팀(본 저장소)** — 확인팀 체크리스트에서 **수동점검 제외 가능한(자동 판정) 항목**만 골라
  실제로 시스템을 바꿔서, `5G_Check_Tool` 을 다시 돌렸을 때 `양호`가 뜨게 만든다.
- 수동 판단이 필요한 항목(정책 확인 등)은 스코프 밖 → `MANUAL`("수동제외")로 표기하고 건너뛴다.
- `main.py` 가 `checks/` 폴더의 항목 파일을 **자동 수집**하는 플러그인 구조(Python).
  확인팀과 동일한 아키텍처를 그대로 미러링했다.

> **조치 원칙:** 시스템을 바꾸기 전 반드시 `common.backup_file()` 로 원본을 백업한다.
> 조치가 실제로 통했는지는 이 저장소가 아니라 확인팀의 `5G_Check_Tool` 재실행으로 검증한다.

---

## 구조

```
5G_Measure_Tool/
├─ main.py            # 실행 진입점 (checks/ 자동 수집, 루트를 import 경로에 등록)
├─ common.py           # 공통 헬퍼 (읽기 + 조치/쓰기) — from common import ... 로 사용
├─ checks/
│  ├─ __init__.py
│  └─ uNN.py / dNN.py  # 항목별 조치 파일 (각자 추가)
└─ .gitignore
```

- 공통 함수는 루트 `common.py` 에 모여 있고, 어느 조치 파일에서든 접두어 없이
  `from common import FIXED, FAILED, MANUAL, result, backup_file, ...` 로 가져다 쓴다.

---

## 실행

```bash
sudo python3 main.py                      # 전체 조치
sudo python3 main.py --only u18 d10       # 특정 항목만
sudo python3 main.py --dry-run            # 실제로 바꾸지 않고 예정 동작만 출력
sudo python3 main.py -u admin -p '****'   # MongoDB 인증 항목 포함
sudo python3 main.py --save results/report.txt
```

- 대부분 항목이 시스템 설정 파일을 변경하므로 **sudo 필요**.
- MongoDB 조치(D-xx)는 `mongosh` 필요: `sudo apt-get install -y mongodb-mongosh`
- 작성 중인 항목은 항상 `--dry-run` 으로 먼저 확인하고, 그다음 `--only <코드>` 로 단건 적용 후
  `5G_Check_Tool` 로 `양호` 전환을 확인한다.
- 출력 예: `[U-18] 조치완료 /etc/shadow 파일 소유자 및 권한 조치`, 마지막에
  `조치완료/조치실패/수동제외/미구현` 요약. `조치실패`가 있으면 종료코드 1.

---

## 항목 추가 방법

`checks/` 에 `uNN.py` 또는 `dNN.py` 를 만들고 `fix()` 만 작성하면 `main.py` 가 자동으로 잡는다.
(main.py 는 수정하지 않는다.) 작성 규약·복붙 템플릿은 [`CONTRIBUTING.md`](CONTRIBUTING.md) 참고.

```python
# checks/u18.py
from common import FIXED, MANUAL, result, backup_file, file_owner_mode_ok, set_file_mode

CODE = "U-18"
TITLE = "/etc/shadow 파일 소유자 및 권한 설정"
TARGET = "/etc/shadow"


def fix(dry_run=False):
    ok, desc = file_owner_mode_ok(TARGET, owner="root", max_mode=0o400)
    if ok:
        return None

    backup_file(TARGET)
    if not set_file_mode(TARGET, 0o400, dry_run=dry_run):
        return result(CODE, TITLE, "조치실패", f"권한 변경 실패 ({desc})")
    return result(CODE, TITLE, FIXED, "권한을 400으로 변경")
```

- MongoDB 인증이 필요한 항목은 `def fix(user=None, password=None, dry_run=False):` 시그니처를 쓴다.
- 상태값 4종: **조치완료 / 조치실패 / 수동제외 / 미구현**
- 파일명은 확인팀과 **동일한 코드**를 그대로 쓴다 (`u18.py` ↔ 확인팀 `checks/u18.py`, `U-18`).
  코드가 어긋나면 두 저장소 매핑이 깨지니 절대 임의로 바꾸지 않는다.

---

## 역할 분배 (조치팀)

확인팀 담당 구간과 1:1로 대응시켰다. (확인팀 지호 ↔ 조치팀 민주 / 확인팀 아윤 ↔ 조치팀 예찬 /
확인팀 재문 ↔ 조치팀 은별)

| 담당 | 범위 | 파일 | 확인팀 대응 |
|------|------|------|------|
| Minju.K | Unix 계정·파일/디렉터리 | `checks/u01.py ~ u33.py` | 지호 |
| Yechan.K | Unix 서비스·패치·로그 | `checks/u34.py ~ u67.py` | 아윤 |
| Eunbyul.H | DBMS(MongoDB) 전체 + 프레임워크·리뷰·병합 | `checks/d01.py ~ d26.py` | 재문 |

---

## Git 규칙 (파일명 · 브랜치 · PR 명칭 통일)

확인팀(`5G_Check_Tool`)과 동일한 규칙을 조치팀 관점(`check` → `fix`)으로 맞췄다.
아래 표 기준으로 모두 통일한다.

| 항목 | 규칙 | 예시 |
|------|------|------|
| 파일명 | `checks/` 아래 `u`/`d` + 2자리 번호, 소문자, 확인팀과 동일 코드 | `u01.py`, `d09.py` (❌ `u1.py`, `U01.py`) |
| 브랜치 | `fix/<범위>` — `develop` 기준으로 분기 | `fix/unix-account`, `fix/dbms` |
| 커밋 메시지 | `fix(<코드>): <내용>` | `fix(U-18): /etc/shadow 권한 조치 구현` |
| PR 제목 | `[조치][<코드 범위>] <내용>` | `[조치][U-14~U-33] Unix 파일·디렉터리 조치` |
| PR 대상 브랜치 | 항상 `develop`. `main` 직접 push 금지 | - |
| `main` 병합 | 조치팀·확인팀 두 팀장이 최종 공동 병합 | - |

PR 본문에는 재현 명령(`sudo python3 main.py --only u18`), 조치 전/후 상태, 백업 경로를 반드시 적는다.
자세한 체크리스트는 PR 템플릿(`.github/pull_request_template.md`)을 따른다.
