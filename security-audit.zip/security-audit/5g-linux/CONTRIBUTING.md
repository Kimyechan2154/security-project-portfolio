# CONTRIBUTING — 조치팀 작성 규약

5G_Measure_Tool 은 `main.py` 가 `checks/` 폴더의 항목 파일을 **자동 수집**하는 구조다.
각자 담당 항목 파일을 `checks/` 에 만들고 `fix()` 만 작성하면 된다. **main.py 는 수정하지 않는다.**

확인팀(`5G_Check_Tool`)의 `check()` 결과 중 `detail` 에 실제 확인값(설정값·권한·경로)이 있으니,
조치 로직을 작성하기 전에 대응하는 확인팀 항목 파일과 `detail` 을 먼저 읽어라.

---

## 1. 역할 분배 (조치팀)

확인팀 담당 구간과 1:1로 대응한다 (자세한 표는 `README.md` 참고).

| 담당 | 범위 | 파일 | 확인팀 대응 |
|------|------|------|------|
| Minju.K | Unix 계정·파일/디렉터리 | `checks/u01.py ~ u33.py` | 지호 |
| Yechan.K | Unix 서비스·패치·로그 | `checks/u34.py ~ u67.py` | 아윤 |
| Eunbyul.H | DBMS(MongoDB) 전체 + 프레임워크·리뷰·병합 | `checks/d01.py ~ d26.py` | 재문 |

- 각 항목의 **자동 조치 가능 여부**는 확인팀 쪽 담당 여부(자동/수동)를 그대로 따른다.
  확인팀에서 `MANUAL`(수동)로 분류된 항목은 조치팀에서도 `MANUAL`("수동제외")로 두고 구현하지 않는다.

---

## 2. 파일 만드는 법

`checks/` 에 `uNN.py` 또는 `dNN.py` 를 만들고 `fix()` 함수를 작성한다. 끝.
**파일명·코드는 확인팀과 반드시 동일**하게 맞춘다 (`checks/u18.py` ↔ `U-18`).
공통 함수는 프로젝트 루트 `common.py` 에서 바로 가져온다 (`checks.` 접두어 불필요).

### 복붙 템플릿 — Unix (인증 불필요)

```python
"""U-NN <항목명> 조치"""
from common import FIXED, result, read_text, backup_file, write_text

CODE = "U-NN"
TITLE = "<항목명>"
TARGET = "/etc/some/config"


def fix(dry_run=False):
    text = read_text(TARGET)
    if text is not None and "<이미 양호 판정 조건>" in text:
        return None

    backup_file(TARGET)
    new_text = text  # ... 조치 로직으로 내용 수정
    if not write_text(TARGET, new_text, dry_run=dry_run):
        return result(CODE, TITLE, "조치실패", "쓰기 실패(권한 확인)")
    return result(CODE, TITLE, FIXED, "변경 내용 요약")
```

### 복붙 템플릿 — DBMS/MongoDB (인증 필요 시)

```python
"""D-NN <항목명> 조치"""
from common import FIXED, result, mongo_eval_json, mongo_eval

CODE = "D-NN"
TITLE = "<항목명>"


def fix(user=None, password=None, dry_run=False):        # ← 인증 필요 항목은 이 시그니처
    data = mongo_eval_json("EJSON.stringify(db.getUsers())", user, password)
    if data is None:
        return result(CODE, TITLE, "조치실패", "MongoDB 조회 실패(미설치/인증)")
    if ...:  # 이미 양호 조건
        return None

    if dry_run:
        return result(CODE, TITLE, FIXED, "dry-run: 조치 예정 내용")
    mongo_eval("db.runCommand({...})", user, password)
    return result(CODE, TITLE, FIXED, "조치 내용 요약")
```

> 인증이 필요 없는 항목은 `def fix(dry_run=False):` 그대로 쓴다.
> `main.py` 가 시그니처를 보고 user/password/dry_run 전달 여부를 자동 결정한다.

### 수동제외 항목

자동 조치 대상이 아닌 항목(정책 판단이 필요하거나 확인팀에서 `MANUAL`/`NA`인 항목)은:

```python
"""U-NN <항목명> — 정책 판단 필요, 자동 조치 대상 아님"""
from common import MANUAL, result

CODE = "U-NN"
TITLE = "<항목명>"


def fix(dry_run=False):
    return result(CODE, TITLE, MANUAL, "정책 확인 필요 — 자동 조치 스코프 제외")
```

---

## 3. 상태값 (status) 4종 — 통일

| 상수 | 출력 | 의미 |
|------|------|------|
| `FIXED`   | 조치완료   | 이번 실행에서 취약 → 양호로 변경 |
| `FAILED`  | 조치실패   | 조치 시도했으나 실패(권한 부족 등) — 문자열 `"조치실패"` 로 직접 반환 |
| `MANUAL`  | 수동제외   | 자동 조치 대상 아님, 스코프 제외 |
| `TODO`    | 미구현     | 아직 작성 전 |

- 이미 양호(취약 아님)라면 `result(...)` 대신 `None` 을 반환한다.
- 한 파일 = 한 항목 = `result(...)` 또는 `None` **한 번 반환**.
- `detail` 에는 무엇을 바꿨는지(백업 경로, 변경 전/후 값)를 남긴다. PR 리뷰·롤백 근거로 쓰인다.
- **조치 전 반드시 `backup_file(TARGET)` 호출.** 백업 없이 파일을 직접 덮어쓰지 않는다.
- `fix()` 는 **멱등**해야 한다 — 이미 양호한 상태에서 다시 실행해도 `None` 을 반환하고
  시스템을 추가로 건드리지 않는다.

## 4. 자주 쓰는 common 함수

읽기: `result, read_text, read_lines, parse_passwd, passwd_user, owner_name, file_owner_mode_ok,
run_command, command_exists, systemctl_is_active, pgrep_any, is_listening_on_port, glob_existing, summarize`

조치: `backup_file, write_text, replace_or_append_line, set_file_mode, set_file_owner, systemctl_restart`

MongoDB: `mongo_eval, mongo_eval_json, get_bind_ip, is_auth_enabled`

---

## 5. 실행·테스트

```bash
sudo python3 main.py --only u18 --dry-run   # 1) 먼저 dry-run 으로 예정 동작 확인
sudo python3 main.py --only u18             # 2) 실제 적용
```
그 다음 `5G_Check_Tool` 저장소에서 `sudo python3 main.py --only u18` 를 돌려
`[U-18] 양호` 로 바뀌는지 확인팀 쪽 도구로 검증한다.

## 6. Git 규칙

- 브랜치: `fix/<범위>` (예: `fix/unix-account`, `fix/dbms`) — `develop` 기준으로 딴다.
- 커밋: `fix(U-18): /etc/shadow 권한 조치 구현`
- PR 제목: `[조치][U-14~U-33] Unix 파일·디렉터리 조치`
- 모든 PR은 **`develop`** 으로. `main` 은 최종에 두 팀장이 공동 병합(직접 push 금지).
- PR 본문에 재현 명령(`sudo python3 main.py --only u18`), 조치 전/후 상태, 백업 경로를 첨부.
