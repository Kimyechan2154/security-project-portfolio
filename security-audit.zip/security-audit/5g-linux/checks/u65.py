"""U-65 NTP·시각 동기화 정책 수동 조치 안내."""

import re

from common import MANUAL, command_exists, read_text, result, run_command, summarize, systemctl_is_active


CODE = "U-65"
TITLE = "NTP 및 시각 동기화 설정"
CONFIGS = ("/etc/chrony/chrony.conf", "/etc/systemd/timesyncd.conf", "/etc/ntp.conf")


def _has_ntp_server_config():
    return any(
        re.search(r"(?im)^\s*(server|pool|NTP=)\s*\S+", read_text(path) or "")
        for path in CONFIGS
    )


def _process_contains(name):
    if not command_exists("ps"):
        return False
    code, out, _ = run_command(["ps", "ax"], timeout=5)
    return code == 0 and name in out


def _service_running():
    return systemctl_is_active("chrony", "chronyd", "systemd-timesyncd", "ntp", "ntpd") or any(
        _process_contains(name) for name in ("chronyd", "ntpd", "systemd-timesyncd")
    )


def _synchronized():
    if not command_exists("timedatectl"):
        return False
    code, out, _ = run_command(["timedatectl", "show", "-p", "NTPSynchronized", "--value"], timeout=10)
    return code == 0 and out.strip().lower() == "yes"


def fix(dry_run=False):
    running = _service_running()
    synchronized = _synchronized()
    configured = _has_ntp_server_config()
    if (running or synchronized) and configured:
        return None
    missing = []
    if not running:
        missing.append("NTP 서비스 실행")
    if not synchronized:
        missing.append("동기화 완료")
    if not configured:
        missing.append("신뢰 NTP 서버 설정")
    return result(
        CODE,
        TITLE,
        MANUAL,
        "내부/승인 NTP 서버와 시간 보정 영향 정책 확인 필요 - 부족 조건: " + summarize(missing),
    )
