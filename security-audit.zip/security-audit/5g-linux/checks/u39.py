"""U-39 불필요한 NFS 서비스 비활성화 조치."""

import os

from common import (
    FAILED,
    FIXED,
    MANUAL,
    pgrep_any,
    result,
    run_command,
    summarize,
    systemctl_is_active,
)


CODE = "U-39"
TITLE = "불필요한 NFS 서비스 비활성화"

NFS_SERVICES = (
    "nfs-server",
    "nfs-kernel-server",
    "nfs-common",
    "nfs-client.target",
    "nfs-lock",
    "nfs-idmap",
    "rpcbind",
    "nfs",
    "nfsd",
)

PROCESS_MARKER = "nfsd/rpcbind (pgrep)"


def _get_active():
    active = [service for service in NFS_SERVICES if systemctl_is_active(service)]
    if pgrep_any("nfsd", "rpcbind"):
        active.append(PROCESS_MARKER)
    return active


def fix(dry_run=False):
    before = _get_active()
    if not before:
        return None
    return result(
        CODE,
        TITLE,
        MANUAL,
        "NFS 사용 여부와 의존 서비스를 확인한 뒤 비활성화해야 함 — 자동 조치 제외: " + summarize(before),
    )
