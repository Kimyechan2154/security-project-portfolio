"""U-64 보안 패치·자동 업데이트 정책 수동 조치 안내."""

import re

from common import MANUAL, command_exists, read_text, result, run_command


CODE = "U-64"
TITLE = "주기적 보안 패치 및 벤더 권고사항 적용"
AUTO_UPGRADES = "/etc/apt/apt.conf.d/20auto-upgrades"


def _auto_security_enabled():
    content = read_text(AUTO_UPGRADES) or ""
    return bool(re.search(r'APT::Periodic::Unattended-Upgrade\s+"1"\s*;', content))


def _security_updates_pending():
    if not command_exists("apt"):
        return None
    code, out, _ = run_command(["apt", "list", "--upgradable"], timeout=30)
    if code != 0:
        return None
    return "security" in out.lower()


def fix(dry_run=False):
    return result(CODE, TITLE, MANUAL, "Checker marks this item MANUAL; vendor policy and operational impact review required.")
    if _auto_security_enabled():
        return None
    pending = _security_updates_pending()
    pending_text = "대기 보안 업데이트 확인" if pending else "대기 여부 미확인/없음"
    return result(
        CODE,
        TITLE,
        MANUAL,
        f"{pending_text} - 패치 검증·적용 주기·서비스 재시작/재부팅 정책 승인 후 unattended-upgrades 활성화 필요",
    )
