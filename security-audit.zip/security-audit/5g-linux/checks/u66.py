"""U-66 기본 rsyslog 정책 조치."""

import os
import re

from common import (
    FAILED,
    FIXED,
    MANUAL,
    backup_file,
    command_exists,
    glob_existing,
    read_text,
    result,
    run_command,
    summarize,
    systemctl_is_active,
    write_text,
)


CODE = "U-66"
TITLE = "정책에 따른 시스템 로깅 설정"
RSYSLOG_CONF = "/etc/rsyslog.conf"
EXTRA_PATTERNS = ("/etc/rsyslog.d/*.conf",)
POLICY_BLOCK = (
    "# BEGIN 5G Measure Tool U-66\n"
    "*.info /var/log/syslog\n"
    "*.alert /var/log/syslog\n"
    "*.emerg *\n"
    "auth,authpriv.* /var/log/auth.log\n"
    "# END 5G Measure Tool U-66\n"
)


def _paths():
    return [RSYSLOG_CONF, "/etc/syslog.conf"] + glob_existing(EXTRA_PATTERNS)


def _rules():
    rules = []
    for path in _paths():
        for line in (read_text(path) or "").splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith("#") and re.match(
                r"^(\*|auth|authpriv|kern|mail|cron|daemon|user|local[0-7])\.", stripped
            ):
                rules.append(f"{path}:{stripped.split()[0]}")
    return rules


def _logging_active():
    return systemctl_is_active("rsyslog", "syslog-ng", "systemd-journald")


def _restart_rsyslog():
    code, out, err = run_command(["systemctl", "restart", "rsyslog"], timeout=30)
    return None if code == 0 else f"rsyslog 재시작 실패({err or out or code})"


def _failure(message, path, original, backup):
    errors = []
    if not write_text(path, original):
        errors.append("원본 설정 복구 실패")
    elif systemctl_is_active("rsyslog", "rsyslog.service"):
        error = _restart_rsyslog()
        if error:
            errors.append(f"원복 후 {error}")
    detail = message + " | " + ("원본 복구 완료" if not errors else summarize(errors))
    return result(CODE, TITLE, FAILED, detail + f" | 백업: {backup}")


def fix(dry_run=False):
    return result(CODE, TITLE, MANUAL, "Checker marks this item MANUAL; vendor policy and operational impact review required.")
    rules = _rules()
    if rules and _logging_active():
        return None
    if rules:
        return result(CODE, TITLE, MANUAL, "syslog 규칙은 있으나 활성 로깅 서비스가 없어 서비스/수집 정책 확인 필요")
    original = read_text(RSYSLOG_CONF)
    if original is None or not systemctl_is_active("rsyslog", "rsyslog.service"):
        return result(
            CODE,
            TITLE,
            MANUAL,
            "활성 rsyslog와 기존 /etc/rsyslog.conf 조합을 확인하지 못함 - syslog-ng/journald 정책에 맞춘 수동 설정 필요",
        )
    separator = "" if not original or original.endswith(("\n", "\r")) else "\n"
    updated = original + separator + POLICY_BLOCK
    if dry_run:
        return result(CODE, TITLE, FIXED, f"dry-run: {RSYSLOG_CONF}에 기본 로깅 정책 블록 추가 예정")
    if os.geteuid() != 0:
        return result(CODE, TITLE, FAILED, "root 권한 필요 - sudo로 실행하세요")
    if not command_exists("rsyslogd"):
        return result(CODE, TITLE, FAILED, "rsyslogd 설정 검증 명령을 찾지 못해 변경하지 않음")

    backup = backup_file(RSYSLOG_CONF)
    if backup is None:
        return result(CODE, TITLE, FAILED, f"{RSYSLOG_CONF}: 백업 실패로 변경하지 않음")
    if not write_text(RSYSLOG_CONF, updated):
        return _failure(f"{RSYSLOG_CONF}: 쓰기 실패", RSYSLOG_CONF, original, backup)
    code, out, err = run_command(["rsyslogd", "-N1", "-f", RSYSLOG_CONF], timeout=30)
    if code != 0:
        return _failure(f"rsyslog 설정 검증 실패({err or out or code})", RSYSLOG_CONF, original, backup)
    restart_error = _restart_rsyslog()
    if restart_error:
        return _failure(restart_error, RSYSLOG_CONF, original, backup)
    if not _rules() or not _logging_active():
        return _failure("조치 후 로깅 규칙/서비스 재확인 실패", RSYSLOG_CONF, original, backup)
    return result(CODE, TITLE, FIXED, f"{RSYSLOG_CONF}: 기본 로깅 정책 추가, rsyslog 재시작 | 백업: {backup}")
