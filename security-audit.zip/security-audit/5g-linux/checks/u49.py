"""U-49 BIND(named) 보안 업데이트 조치."""

import os
import re

from common import (
    FAILED,
    FIXED,
    MANUAL,
    backup_file,
    command_exists,
    glob_existing,
    result,
    run_command,
    summarize,
    systemctl_is_active,
)


CODE = "U-49"
TITLE = "DNS 보안 버전 패치"
PACKAGE = "bind9"

CONFIG_PATTERNS = (
    "/etc/bind/named.conf*",
    "/etc/bind/db.*",
)


def _bind_installed():
    if not command_exists("named"):
        return False, ""
    code, out, _ = run_command(["named", "-v"], timeout=10)
    if code != 0 or not out:
        return False, ""
    return True, out.splitlines()[0]


def _package_installed():
    if not command_exists("dpkg-query"):
        return False
    code, out, _ = run_command(
        ["dpkg-query", "-W", "-f=${Status}", PACKAGE], timeout=10
    )
    return code == 0 and "install ok installed" in out


def _pending_upgrade():
    if not command_exists("apt-get"):
        return [], "apt-get 명령을 찾지 못함"
    code, out, err = run_command(
        ["apt-get", "-s", "install", "--only-upgrade", PACKAGE], timeout=60
    )
    if code != 0:
        return [], f"APT 모의 검사 실패({err or out or code})"

    pending = []
    for line in out.splitlines():
        match = re.match(r"^Inst\s+(\S+)", line)
        if match:
            pending.append(match.group(1))
    return sorted(set(pending)), None


def _backup_configs():
    backups = []
    errors = []
    for path in glob_existing(CONFIG_PATTERNS):
        if not os.path.isfile(path):
            continue
        backup = backup_file(path)
        if backup is None:
            errors.append(f"{path}: 백업 실패")
        else:
            backups.append(backup)
    return backups, errors


def _restart_bind_if_active():
    for unit in ("bind9", "named"):
        if not systemctl_is_active(unit):
            continue
        code, out, err = run_command(["systemctl", "restart", unit], timeout=30)
        if code != 0:
            return f"{unit} 재시작 실패({err or out or code})"
        return None
    return None


def fix(dry_run=False):
    return result(CODE, TITLE, MANUAL, "Checker marks this item MANUAL; vendor policy and operational impact review required.")
    installed, version = _bind_installed()
    if not installed or not _package_installed():
        return None

    pending, check_error = _pending_upgrade()
    if check_error:
        return result(CODE, TITLE, FAILED, check_error)
    if not pending:
        return None

    if dry_run:
        return result(
            CODE,
            TITLE,
            FIXED,
            f"dry-run: BIND 보안 업데이트 예정({version}) — {summarize(pending)}",
        )

    if os.geteuid() != 0:
        return result(CODE, TITLE, FAILED, "root 권한 필요 — sudo로 실행하세요")

    backups, backup_errors = _backup_configs()
    if backup_errors:
        return result(
            CODE,
            TITLE,
            FAILED,
            "BIND 설정 백업 실패로 패키지를 변경하지 않음: "
            + summarize(backup_errors),
        )

    code, out, err = run_command(
        ["apt-get", "install", "-y", "--only-upgrade", PACKAGE], timeout=600
    )
    if code != 0:
        detail = f"BIND 업데이트 실패({err or out or code})"
        if backups:
            detail += f" | 백업: {summarize(backups)}"
        return result(CODE, TITLE, FAILED, detail)

    restart_error = _restart_bind_if_active()
    if restart_error:
        detail = restart_error
        if backups:
            detail += f" | 백업: {summarize(backups)}"
        return result(CODE, TITLE, FAILED, detail)

    remaining, verify_error = _pending_upgrade()
    if verify_error:
        detail = f"업데이트 후 검증 실패: {verify_error}"
        if backups:
            detail += f" | 백업: {summarize(backups)}"
        return result(CODE, TITLE, FAILED, detail)
    if remaining:
        detail = "업데이트 후에도 대기 패키지 존재: " + summarize(remaining)
        if backups:
            detail += f" | 백업: {summarize(backups)}"
        return result(CODE, TITLE, FAILED, detail)

    installed_after, version_after = _bind_installed()
    if not installed_after:
        return result(
            CODE,
            TITLE,
            FAILED,
            "업데이트 후 named 버전 확인 실패"
            + (f" | 백업: {summarize(backups)}" if backups else ""),
        )

    detail = f"BIND 보안 업데이트 완료: {version} → {version_after}"
    if backups:
        detail += f" | 설정 백업: {summarize(backups)}"
    else:
        detail += " | 존재하는 BIND 설정 파일 없음"
    return result(CODE, TITLE, FIXED, detail)
