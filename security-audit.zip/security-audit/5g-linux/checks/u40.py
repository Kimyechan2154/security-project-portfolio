"""U-40 NFS 접근 통제 조치.

파일 소유자·권한은 자동 조치한다. 모든 호스트(*) 공유는 허용할 실제
호스트/네트워크를 정책 없이 결정할 수 없으므로 수동제외로 반환한다.
"""

import os
import re
import stat

from common import (
    FAILED,
    FIXED,
    MANUAL,
    backup_file,
    read_text,
    result,
    restore_backups,
    set_file_mode,
    set_file_owner,
    summarize,
)


CODE = "U-40"
TITLE = "웹서비스 파일 업로드 및 다운로드 제한"

NFS_CONFIGS = ("/etc/exports", "/etc/dfs/dfstab", "/etc/dfs/sharetab")
EXPORTS_PATH = "/etc/exports"
MAX_MODE = 0o644


def _legacy_scan():
    found = []
    permission_issues = []
    wildcard_issues = []

    for path in NFS_CONFIGS:
        if not os.path.exists(path):
            continue
        found.append(path)

        try:
            file_stat = os.stat(path)
            mode = stat.S_IMODE(file_stat.st_mode)
            if file_stat.st_uid != 0 or mode > MAX_MODE:
                permission_issues.append(
                    {
                        "path": path,
                        "mode": mode,
                        "detail": (
                            f"{path}: UID={file_stat.st_uid}, 권한={mode:03o}, "
                            "기준=root/644 이하"
                        ),
                    }
                )
        except (PermissionError, OSError) as exc:
            permission_issues.append(
                {
                    "path": path,
                    "mode": None,
                    "detail": f"{path}: 상태 확인 실패({exc})",
                }
            )

        if path != EXPORTS_PATH:
            continue
        content = read_text(path)
        if content is None:
            wildcard_issues.append(f"{path}: 내용 확인 실패")
            continue
        for number, line in enumerate(content.splitlines(), start=1):
            stripped = line.strip()
            if (
                stripped
                and not stripped.startswith("#")
                and re.search(r"\s+\*[\s(]", stripped)
            ):
                wildcard_issues.append(
                    f"{path}:{number}: 모든 호스트(*) 공유 — {stripped}"
                )

    return found, permission_issues, wildcard_issues


def _legacy_fix(dry_run=False):
    found, permission_issues, wildcard_issues = _scan()
    if not found or (not permission_issues and not wildcard_issues):
        return None

    if wildcard_issues:
        return result(
            CODE,
            TITLE,
            MANUAL,
            "허용할 NFS 호스트/네트워크 정책 확인 필요 — 자동 조치 제외: "
            + summarize(wildcard_issues),
        )

    before = [item["detail"] for item in permission_issues]
    if dry_run:
        return result(
            CODE,
            TITLE,
            FIXED,
            f"dry-run: NFS 설정 파일을 root:root 및 644 이하로 조치 예정 — {summarize(before)}",
        )

    if os.geteuid() != 0:
        return result(CODE, TITLE, FAILED, "root 권한 필요 — sudo로 실행하세요")

    errors = []
    backups = []
    for item in permission_issues:
        path = item["path"]
        backup = backup_file(path)
        if backup is None:
            errors.append(f"{path}: 백업 실패로 변경하지 않음")
            continue
        backups.append(backup)

        current_mode = item["mode"]
        target_mode = MAX_MODE
        if current_mode is not None and current_mode <= MAX_MODE:
            target_mode = current_mode

        if not set_file_mode(path, target_mode):
            errors.append(f"{path}: 권한 {target_mode:03o} 변경 실패")
            continue
        if not set_file_owner(path, "root", "root"):
            errors.append(f"{path}: 소유자 root:root 변경 실패")

    _, remaining_permissions, remaining_wildcards = _scan()
    if remaining_wildcards:
        return result(
            CODE,
            TITLE,
            MANUAL,
            "권한 조치 후 모든 호스트(*) 공유가 확인됨 — 정책 확인 필요: "
            + summarize(remaining_wildcards)
            + (f" | 백업: {summarize(backups)}" if backups else ""),
        )

    if errors or remaining_permissions:
        restore_errors = restore_backups(backups)
        details = []
        if errors:
            details.append(f"오류: {summarize(errors)}")
        if remaining_permissions:
            details.append(
                "남은 취약 파일: "
                + summarize([item["detail"] for item in remaining_permissions])
            )
        if restore_errors:
            details.append(f"원복 오류: {summarize(restore_errors)}")
        elif backups:
            details.append("변경 파일/메타데이터 원복 완료")
        if backups:
            details.append(f"백업: {summarize(backups)}")
        return result(CODE, TITLE, FAILED, " | ".join(details))

    return result(
        CODE,
        TITLE,
        FIXED,
        "NFS 설정 파일을 root:root 및 644 이하 권한으로 조치"
        + (f" | 백업: {summarize(backups)}" if backups else ""),
    )


UPLOAD_DIRS = ("/var/www/html/upload", "/var/www/uploads")


def _scan():
    wildcard_issues = []
    executable_files = []
    errors = []
    if os.path.exists(EXPORTS_PATH):
        content = read_text(EXPORTS_PATH)
        if content is None:
            errors.append(f"{EXPORTS_PATH}: read failed")
        else:
            for number, line in enumerate(content.splitlines(), start=1):
                stripped = line.strip()
                if not stripped or stripped.startswith("#"):
                    continue
                if re.search(r"\*\([^\)]*\)", stripped) or re.search(r"\s+\*$", stripped):
                    wildcard_issues.append(f"{EXPORTS_PATH}:{number}: {stripped}")
    for directory in UPLOAD_DIRS:
        if not os.path.exists(directory):
            continue
        try:
            for root_dir, _, files in os.walk(directory):
                for name in files:
                    path = os.path.join(root_dir, name)
                    try:
                        mode = stat.S_IMODE(os.stat(path).st_mode)
                    except (PermissionError, OSError) as exc:
                        errors.append(f"{path}: stat failed({exc})")
                        continue
                    if mode & 0o111:
                        executable_files.append({"path": path, "mode": mode})
        except (PermissionError, OSError) as exc:
            errors.append(f"{directory}: scan failed({exc})")
    return wildcard_issues, executable_files, errors


def fix(dry_run=False):
    wildcard_issues, executable_files, errors = _scan()
    if not wildcard_issues and not executable_files and not errors:
        return None
    if wildcard_issues or errors:
        detail = []
        if wildcard_issues:
            detail.append("allowed NFS clients/networks must be confirmed: " + summarize(wildcard_issues))
        if errors:
            detail.append("scan errors: " + summarize(errors))
        return result(CODE, TITLE, MANUAL, " | ".join(detail))
    if dry_run:
        return result(CODE, TITLE, FIXED, "dry-run: remove execute bits from upload files — " + summarize([x["path"] for x in executable_files]))
    if os.geteuid() != 0:
        return result(CODE, TITLE, FAILED, "root privileges required")

    backups = []
    for item in executable_files:
        backup = backup_file(item["path"])
        if backup is None:
            return result(CODE, TITLE, FAILED, f"{item['path']}: backup failed; no file changed" + (f" | completed backups: {summarize(backups)}" if backups else ""))
        backups.append(backup)

    failures = []
    for item in executable_files:
        if not set_file_mode(item["path"], item["mode"] & ~0o111):
            failures.append(f"{item['path']}: chmod failed")
            break

    remaining_wildcards, remaining_files, remaining_errors = _scan()
    if failures or remaining_wildcards or remaining_files or remaining_errors:
        restore_errors = restore_backups(backups)
        detail = []
        if failures:
            detail.append("errors: " + summarize(failures))
        if remaining_wildcards:
            detail.append("remaining NFS wildcard: " + summarize(remaining_wildcards))
        if remaining_files:
            detail.append("remaining executable files: " + summarize([x["path"] for x in remaining_files]))
        if remaining_errors:
            detail.append("verification errors: " + summarize(remaining_errors))
        detail.append("restore complete" if not restore_errors else "restore errors: " + summarize(restore_errors))
        detail.append("backups: " + summarize(backups))
        return result(CODE, TITLE, FAILED, " | ".join(detail))
    return result(CODE, TITLE, FIXED, "upload-file execute bits removed: " + summarize([x["path"] for x in executable_files]) + " | backups: " + summarize(backups))
