"""U-37 crontab/at 설정 파일 소유자 및 권한 조치."""

import os
import stat

from common import (
    FAILED,
    FIXED,
    backup_file,
    result,
    restore_backups,
    set_file_mode,
    set_file_owner,
    summarize,
)


CODE = "U-37"
TITLE = "crontab 설정파일 권한 설정 미흡"

CMD_FILES = ("/usr/bin/crontab", "/usr/bin/at")
CONFIG_FILES = (
    "/etc/cron.allow",
    "/etc/cron.deny",
    "/etc/crontab",
    "/etc/at.allow",
    "/etc/at.deny",
)
DIRS = (
    "/var/spool/cron",
    "/var/spool/cron/crontabs",
    "/var/spool/at",
    "/etc/cron.d",
    "/etc/cron.daily",
    "/etc/cron.hourly",
    "/etc/cron.monthly",
    "/etc/cron.weekly",
)


def _get_issues():
    issues = []
    targets = (
        [(path, 0o750, False) for path in CMD_FILES]
        + [(path, 0o640, False) for path in CONFIG_FILES]
        + [(path, 0o750, True) for path in DIRS]
    )
    for path, max_mode, is_dir in targets:
        if is_dir and not os.path.isdir(path):
            continue
        if not is_dir and not os.path.exists(path):
            continue
        try:
            item = os.stat(path)
        except (PermissionError, OSError) as exc:
            issues.append({"path": path, "error": str(exc), "is_dir": is_dir})
            continue
        mode = stat.S_IMODE(item.st_mode)
        if item.st_uid != 0 or mode > max_mode:
            issues.append({
                "path": path,
                "mode": mode,
                "uid": item.st_uid,
                "gid": item.st_gid,
                "max_mode": max_mode,
                "is_dir": is_dir,
                "detail": f"{path}: uid={item.st_uid}, mode={mode:03o}",
            })
    return issues


def _restore_dirs(items):
    errors = []
    for item in reversed(items):
        try:
            os.chown(item["path"], item["uid"], item["gid"])
            os.chmod(item["path"], item["mode"])
        except OSError as exc:
            errors.append(f"{item['path']}: restore failed({exc})")
    return errors


def fix(dry_run=False):
    before = _get_issues()
    if not before:
        return None
    unreadable = [item for item in before if "error" in item]
    if unreadable:
        return result(
            CODE, TITLE, FAILED,
            "metadata read failed; no changes: "
            + summarize([item["path"] for item in unreadable]),
        )
    if dry_run:
        return result(
            CODE, TITLE, FIXED,
            "dry-run: set root:root and checker-compliant modes — "
            + summarize([item["path"] for item in before]),
        )
    if os.geteuid() != 0:
        return result(CODE, TITLE, FAILED, "root privileges required")

    backups = []
    for item in before:
        if item["is_dir"]:
            continue
        backup = backup_file(item["path"])
        if backup is None:
            return result(
                CODE, TITLE, FAILED,
                f"{item['path']}: backup failed; no target changed"
                + (f" | completed backups: {summarize(backups)}" if backups else ""),
            )
        backups.append(backup)

    applied_dirs = []
    errors = []
    for item in before:
        if item["is_dir"]:
            applied_dirs.append(item)
        target_mode = min(item["mode"], item["max_mode"])
        if not set_file_mode(item["path"], target_mode):
            errors.append(f"{item['path']}: chmod failed")
            break
        if not set_file_owner(item["path"], "root", "root"):
            errors.append(f"{item['path']}: chown failed")
            break

    remaining = _get_issues()
    if errors or remaining:
        restore_errors = restore_backups(backups) + _restore_dirs(applied_dirs)
        detail = []
        if errors:
            detail.append("errors: " + summarize(errors))
        if remaining:
            detail.append("remaining: " + summarize([item["path"] for item in remaining]))
        detail.append("restore complete" if not restore_errors else "restore errors: " + summarize(restore_errors))
        if backups:
            detail.append("backups: " + summarize(backups))
        return result(CODE, TITLE, FAILED, " | ".join(detail))

    detail = "cron/at files and directories set to root:root and checker-compliant modes"
    if backups:
        detail += " | backups: " + summarize(backups)
    if applied_dirs:
        detail += " | original directory metadata retained for rollback"
    return result(CODE, TITLE, FIXED, detail)
