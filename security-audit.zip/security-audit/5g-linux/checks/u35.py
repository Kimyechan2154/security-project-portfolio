"""U-35 공유 서비스에 대한 익명 접근 제한 조치."""

import os
import re

from common import (
    FAILED,
    FIXED,
    backup_file,
    command_exists,
    read_text,
    result,
    restore_backups,
    run_command,
    summarize,
    systemctl_is_active,
    write_text,
)


CODE = "U-35"
TITLE = "공유 서비스에 대한 익명 접근 제한 설정"

VSFTPD_FILES = ("/etc/vsftpd.conf", "/etc/vsftpd/vsftpd.conf")
PROFTPD_FILES = ("/etc/proftpd/proftpd.conf", "/etc/proftpd.conf")
NFS_EXPORTS = "/etc/exports"
SAMBA_FILES = ("/etc/samba/smb.conf", "/usr/lib/smb.conf")

SERVICE_UNITS = {
    "vsftpd": ("vsftpd.service",),
    "proftpd": ("proftpd.service",),
    "nfs": ("nfs-server.service", "nfs-kernel-server.service"),
    "samba": ("smbd.service", "samba.service"),
}

PROCESS_NAMES = {
    "vsftpd": ("vsftpd",),
    "proftpd": ("proftpd",),
    "nfs": ("rpc.nfsd",),
    "samba": ("smbd",),
}


def _unit_in_use(unit):
    if not command_exists("systemctl"):
        return False
    for action in ("is-active", "is-enabled"):
        code, _, _ = run_command(["systemctl", action, unit])
        if code == 0:
            return True
    return False


def _process_running(name):
    if not command_exists("pgrep"):
        return False
    code, _, _ = run_command(["pgrep", "-x", name])
    return code == 0


def _active_services():
    active = set()
    for service, units in SERVICE_UNITS.items():
        if any(_unit_in_use(unit) for unit in units):
            active.add(service)
            continue
        if any(_process_running(name) for name in PROCESS_NAMES[service]):
            active.add(service)
    return active


def _existing_files(paths):
    return [path for path in paths if os.path.isfile(path)]


def _active_lines(path):
    text = read_text(path)
    if text is None:
        return None
    return [
        (number, line)
        for number, line in enumerate(text.splitlines(), start=1)
        if line.strip() and not line.lstrip().startswith(("#", ";"))
    ]



def _check_vsftpd():
    issues = []
    for path in _existing_files(VSFTPD_FILES):
        lines = _active_lines(path)
        if lines is None:
            issues.append(f"{path}: read failed")
            continue
        values = []
        for number, line in lines:
            match = re.match(r"^\s*anonymous_enable\s*=\s*(\S+)", line, re.I)
            if match:
                values.append((number, match.group(1).upper()))
        if values and values[-1][1] == "YES":
            issues.append(f"{path}:{values[-1][0]}: anonymous_enable=YES")
    return issues


def _check_proftpd():
    issues = []
    for path in _existing_files(PROFTPD_FILES):
        content = read_text(path)
        if content is None:
            issues.append(f"{path}: read failed")
        elif "<Anonymous" in content and "UserAlias anonymous" in content:
            issues.append(f"{path}: anonymous alias configured")
    return issues


def _check_nfs():
    if not os.path.isfile(NFS_EXPORTS):
        return []
    content = read_text(NFS_EXPORTS)
    if content is None:
        return [f"{NFS_EXPORTS}: read failed"]
    return [f"{NFS_EXPORTS}: anonuid/anongid configured"] if (
        "anonuid" in content or "anongid" in content
    ) else []


def _check_samba():
    issues = []
    for path in _existing_files(SAMBA_FILES):
        lines = _active_lines(path)
        if lines is None:
            issues.append(f"{path}: read failed")
            continue
        for number, line in lines:
            low = line.lower()
            if "guest ok = yes" in low or "map to guest = bad user" in low:
                issues.append(f"{path}:{number}: guest access enabled")
    return issues


def _get_issues():
    active = set()
    if _existing_files(VSFTPD_FILES):
        active.add("vsftpd")
    if _existing_files(PROFTPD_FILES):
        active.add("proftpd")
    if os.path.isfile(NFS_EXPORTS):
        active.add("nfs")
    if _existing_files(SAMBA_FILES):
        active.add("samba")
    issues = []
    if "vsftpd" in active:
        issues.extend(_check_vsftpd())
    if "proftpd" in active:
        issues.extend(_check_proftpd())
    if "nfs" in active:
        issues.extend(_check_nfs())
    if "samba" in active:
        issues.extend(_check_samba())
    return active, issues

def _backup_and_write(path, original, updated, backups):
    if updated == original:
        return None, False

    backup = backup_file(path)
    if backup is None:
        return f"{path}: 백업 실패로 변경하지 않음", False
    backups.append(backup)

    if not write_text(path, updated):
        return f"{path}: 쓰기 실패", False
    return None, True


def _set_vsftpd(path, backups):
    original = read_text(path)
    if original is None:
        return f"{path}: 읽기 실패", False

    active_values = []
    for line in original.splitlines():
        if line.lstrip().startswith(("#", ";")):
            continue
        match = re.match(r"^\s*anonymous_enable\s*=\s*(\S+)", line, re.I)
        if match:
            active_values.append(match.group(1).upper())
    if active_values and active_values[-1] == "NO":
        return None, False

    output = []
    replaced = False
    for line in original.splitlines(keepends=True):
        if (
            not line.lstrip().startswith(("#", ";"))
            and re.match(r"^\s*anonymous_enable\s*=", line, re.I)
        ):
            newline = "\r\n" if line.endswith("\r\n") else "\n"
            output.append(f"anonymous_enable=NO{newline}")
            replaced = True
        else:
            output.append(line)
    if not replaced:
        if output and not output[-1].endswith(("\n", "\r")):
            output[-1] += "\n"
        output.append("anonymous_enable=NO\n")
    return _backup_and_write(path, original, "".join(output), backups)



def _disable_proftpd_anonymous(path, backups):
    original = read_text(path)
    if original is None:
        return f"{path}: read failed", False
    updated = re.sub(r"UserAlias\s+anonymous\b", "UserAlias disabled-anonymous", original)
    return _backup_and_write(path, original, updated, backups)


def _remove_nfs_anonymous_options(path, backups):
    original = read_text(path)
    if original is None:
        return f"{path}: read failed", False
    updated = re.sub(r"(?i)(?:,\s*)?\b(?:anonuid|anongid)\s*=\s*[^,\s\)]+", "", original)
    return _backup_and_write(path, original, updated, backups)


def _disable_samba_guest(path, backups):
    original = read_text(path)
    if original is None:
        return f"{path}: read failed", False
    updated = re.sub(r"(?im)^(\s*guest\s+ok\s*=\s*)yes(\s*(?:[#;].*)?)$", r"\1no\2", original)
    updated = re.sub(r"(?im)^(\s*map\s+to\s+guest\s*=\s*)bad\s+user(\s*(?:[#;].*)?)$", r"\1Never\2", updated)
    return _backup_and_write(path, original, updated, backups)

def _restart_active_units(service):
    errors = []
    for unit in SERVICE_UNITS[service]:
        if not systemctl_is_active(unit):
            continue
        code, out, err = run_command(["systemctl", "restart", unit], timeout=20)
        if code != 0:
            errors.append(f"{unit}: 재시작 실패({err or out or code})")
    return errors


def fix(dry_run=False):
    active, before = _get_issues()
    if not active or not before:
        return None

    if dry_run:
        return result(
            CODE,
            TITLE,
            FIXED,
            f"dry-run: 공유 서비스 익명 접근 차단 예정 — {summarize(before)}",
        )

    if os.geteuid() != 0:
        return result(CODE, TITLE, FAILED, "root 권한 필요 — sudo로 실행하세요")

    errors = []
    backups = []
    changed_services = set()

    actions = {
        "vsftpd": (VSFTPD_FILES, _set_vsftpd),
        "proftpd": (PROFTPD_FILES, _disable_proftpd_anonymous),
        "samba": (SAMBA_FILES, _disable_samba_guest),
    }

    for service, (paths, action) in actions.items():
        if service not in active:
            continue
        existing = _existing_files(paths)
        if not existing:
            errors.append(f"{service}: 설정 파일을 찾지 못함")
            continue
        for path in existing:
            error, changed = action(path, backups)
            if error:
                errors.append(error)
            if changed:
                changed_services.add(service)

    if "nfs" in active and os.path.isfile(NFS_EXPORTS):
        error, changed = _remove_nfs_anonymous_options(NFS_EXPORTS, backups)
        if error:
            errors.append(error)
        if changed:
            changed_services.add("nfs")

    for service in sorted(changed_services):
        errors.extend(_restart_active_units(service))

    if "nfs" in changed_services and command_exists("exportfs"):
        code, out, err = run_command(["exportfs", "-ra"], timeout=20)
        if code != 0:
            errors.append(f"exportfs -ra 실패({err or out or code})")

    if "samba" in changed_services and command_exists("smbcontrol"):
        code, out, err = run_command(
            ["smbcontrol", "all", "reload-config"], timeout=20
        )
        if code != 0:
            errors.append(f"Samba 설정 다시 읽기 실패({err or out or code})")

    _, remaining = _get_issues()
    if errors or remaining:
        restore_errors = restore_backups(backups)
        details = []
        if errors:
            details.append(f"오류: {summarize(errors)}")
        if remaining:
            details.append(f"남은 취약 설정: {summarize(remaining)}")
        if restore_errors:
            details.append(f"원복 오류: {summarize(restore_errors)}")
        elif backups:
            details.append("변경 파일/메타데이터 원복 완료")
        if backups:
            details.append(f"백업: {summarize(backups)}")
        return result(CODE, TITLE, FAILED, " | ".join(details))

    return result(
        CODE,
        TITLE,
        FIXED,
        "익명·게스트 접근 차단 완료"
        + (f" | 백업: {summarize(backups)}" if backups else ""),
    )
