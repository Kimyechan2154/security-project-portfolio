"""U-43 NIS/NIS+ 서비스 비활성화 조치."""

import os

from common import (
    FAILED,
    FIXED,
    MANUAL,
    pgrep_any,
    result,
    run_command,
    summarize,
    systemctl_is_active,
)


CODE = "U-43"
TITLE = "NIS, NIS+ 점검"

NIS_SERVICES = (
    "ypserv",
    "ypbind",
    "ypxfrd",
    "rpc.yppasswdd",
    "rpc.ypupdated",
    "nis",
)

PROCESS_MARKER = "ypserv/ypbind (pgrep)"


def _get_active():
    active = [service for service in NIS_SERVICES if systemctl_is_active(service)]
    if pgrep_any("ypserv", "ypbind"):
        active.append(PROCESS_MARKER)
    return active


def fix(dry_run=False):
    before = _get_active()
    if not before:
        return None
    return result(
        CODE,
        TITLE,
        MANUAL,
        "NIS 계정·인증 의존성을 확인하고 대체 인증으로 전환한 뒤 중지해야 함 — 자동 조치 제외: " + summarize(before),
    )
