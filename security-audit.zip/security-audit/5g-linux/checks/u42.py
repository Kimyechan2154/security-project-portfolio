"""U-42 불필요한 RPC 서비스 비활성화 조치."""

import os
import re

from common import (
    FAILED,
    FIXED,
    MANUAL,
    backup_file,
    pgrep_any,
    read_text,
    result,
    run_command,
    summarize,
    systemctl_is_active,
    write_text,
)


CODE = "U-42"
TITLE = "불필요한 RPC 서비스 비활성화"

RPC_SERVICES = (
    "rpc-statd",
    "rpc-gssd",
    "rpcbind",
    "rpc.cmsd",
    "rpc.ttdbserverd",
    "sadmind",
    "rusersd",
    "walld",
    "sprayd",
    "rstatd",
    "rpc.nisd",
    "rexd",
    "rpc.pcnfsd",
    "rpc.rquotad",
    "cachefsd",
)

XINETD_SERVICES = (
    "rstatd",
    "rusersd",
    "walld",
    "sprayd",
    "rexd",
    "rpc-statd",
    "rpc-gssd",
    "rquotad",
)

XINETD_DIR = "/etc/xinetd.d"
PROCESS_MARKER = "rpcbind/rpc.statd (pgrep)"


def _xinetd_enabled(service):
    content = read_text(os.path.join(XINETD_DIR, service)) or ""
    disable_value = None
    for line in content.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith(("#", ";")):
            continue
        match = re.search(r"\bdisable\s*=\s*(yes|no)\b", stripped, re.I)
        if match:
            disable_value = match.group(1).lower()
    return disable_value == "no"


def _get_active():
    active = [service for service in RPC_SERVICES if systemctl_is_active(service)]
    if pgrep_any("rpcbind", "rpc.statd"):
        active.append(PROCESS_MARKER)
    active.extend(
        f"xinetd:{service}"
        for service in XINETD_SERVICES
        if _xinetd_enabled(service)
    )
    return active


def _disable_xinetd_file(service, backups):
    path = os.path.join(XINETD_DIR, service)
    if not os.path.isfile(path):
        return None, False
    original = read_text(path)
    if original is None:
        return f"{path}: 읽기 실패", False
    updated = re.sub(
        r"(?im)^(\s*(?![#;]).*?\bdisable\s*=\s*)no\b",
        r"\1yes",
        original,
    )
    if updated == original:
        return None, False

    backup = backup_file(path)
    if backup is None:
        return f"{path}: 백업 실패로 변경하지 않음", False
    backups.append(backup)
    if not write_text(path, updated):
        return f"{path}: 쓰기 실패", False
    return None, True


def _restart_xinetd():
    if not systemctl_is_active("xinetd"):
        return None
    code, out, err = run_command(["systemctl", "restart", "xinetd"], timeout=20)
    if code != 0:
        return f"xinetd 재시작 실패({err or out or code})"
    return None


def fix(dry_run=False):
    before = _get_active()
    if not before:
        return None
    return result(
        CODE,
        TITLE,
        MANUAL,
        "RPC/NFS 의존성을 확인한 뒤 대상 서비스를 선별해야 함 — 자동 조치 제외: " + summarize(before),
    )
