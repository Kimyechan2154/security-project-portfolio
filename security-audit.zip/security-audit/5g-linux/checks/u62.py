"""U-62 로그인 경고 메시지 및 SSH Banner 조치."""

import os
import re

from common import (
    FAILED,
    FIXED,
    MANUAL,
    backup_file,
    command_exists,
    read_text,
    result,
    run_command,
    summarize,
    systemctl_is_active,
    write_text,
)


CODE = "U-62"
TITLE = "로그인 시 경고 메시지 설정"
ISSUE = "/etc/issue"
ISSUE_NET = "/etc/issue.net"
MOTD = "/etc/motd"
SSHD_CONFIG = "/etc/ssh/sshd_config"
WARNING = "Authorized users only. All activities may be monitored and reported."
DEFAULT_MARKERS = ("\\n", "\\l", "Ubuntu", "Debian", "GNU/Linux", "Kernel")


def _custom_warning_path():
    for path in (ISSUE_NET, ISSUE, MOTD):
        text = (read_text(path) or "").strip()
        if len(text) >= 20 and not any(marker in text for marker in DEFAULT_MARKERS):
            return path
    return None


def _ssh_banner_path():
    sshd = read_text(SSHD_CONFIG)
    if sshd is None:
        return None
    matches = re.findall(r"(?im)^\s*Banner\s+(\S+)", sshd)
    return next((value for value in reversed(matches) if value.lower() != "none"), None)


def _replace_banner(content, path):
    pattern = re.compile(r"(?im)^\s*#?\s*Banner\s+\S+\s*$")
    lines = content.splitlines(keepends=True)
    output, replaced = [], False
    for line in lines:
        if pattern.match(line.rstrip("\r\n")):
            if not replaced:
                newline = "\r\n" if line.endswith("\r\n") else "\n"
                output.append(f"Banner {path}{newline}")
                replaced = True
            continue
        output.append(line)
    if not replaced:
        separator = "" if not content or content.endswith(("\n", "\r")) else "\n"
        output.append(f"{separator}Banner {path}\n")
    return "".join(output)


def _restore(changes):
    return [f"{c['path']}: 원본 복구 실패" for c in changes if not write_text(c["path"], c["original"])]


def _reload_ssh():
    for unit in ("ssh", "sshd"):
        if not systemctl_is_active(unit, f"{unit}.service"):
            continue
        code, out, err = run_command(["systemctl", "reload", unit], timeout=20)
        if code != 0:
            return unit, f"{unit}: reload 실패({err or out or code})"
        return unit, None
    return None, None


def _failure(message, written, unit, backups):
    errors = _restore(written)
    if unit and not errors:
        code, out, err = run_command(["systemctl", "reload", unit], timeout=20)
        if code != 0:
            errors.append(f"원복 후 {unit} reload 실패({err or out or code})")
    detail = message + " | " + ("원본 복구 완료" if not errors else summarize(errors))
    if backups:
        detail += f" | 백업: {summarize(backups)}"
    return result(CODE, TITLE, FAILED, detail)


def fix(dry_run=False):
    custom_path = _custom_warning_path()
    sshd = read_text(SSHD_CONFIG)
    banner_path = _ssh_banner_path()
    if custom_path and (sshd is None or banner_path == custom_path):
        return None

    changes = []
    if custom_path is None:
        original = read_text(ISSUE_NET)
        if original is None:
            return result(CODE, TITLE, MANUAL, f"경고 문구를 기록할 기존 파일({ISSUE_NET})이 없어 경로·정책 확인 필요")
        changes.append({"path": ISSUE_NET, "original": original, "updated": WARNING + "\n"})
        custom_path = ISSUE_NET
    if sshd is not None and banner_path != custom_path:
        changes.append({"path": SSHD_CONFIG, "original": sshd, "updated": _replace_banner(sshd, custom_path)})

    if dry_run:
        return result(
            CODE, TITLE, FIXED,
            "dry-run: 로그인 경고/SSH Banner 설정 예정 - " + summarize([c["path"] for c in changes]),
        )
    if os.geteuid() != 0:
        return result(CODE, TITLE, FAILED, "root 권한 필요 - sudo로 실행하세요")
    if any(c["path"] == SSHD_CONFIG for c in changes) and not command_exists("sshd"):
        return result(CODE, TITLE, FAILED, "sshd 설정 검증 명령을 찾지 못해 변경하지 않음")

    backups = []
    for change in changes:
        backup = backup_file(change["path"])
        if backup is None:
            return result(
                CODE, TITLE, FAILED,
                f"{change['path']}: 백업 실패로 파일을 변경하지 않음"
                + (f" | 완료된 백업: {summarize(backups)}" if backups else ""),
            )
        backups.append(backup)

    written = []
    for change in changes:
        if not write_text(change["path"], change["updated"]):
            return _failure(f"{change['path']}: 쓰기 실패", written, None, backups)
        written.append(change)
    if any(c["path"] == SSHD_CONFIG for c in written):
        code, out, err = run_command(["sshd", "-t", "-f", SSHD_CONFIG], timeout=20)
        if code != 0:
            return _failure(f"sshd 설정 검증 실패({err or out or code})", written, None, backups)
    unit, reload_error = _reload_ssh()
    if reload_error:
        return _failure(reload_error, written, unit, backups)
    if not _custom_warning_path() or (read_text(SSHD_CONFIG) is not None and not _ssh_banner_path()):
        return _failure("조치 후 로그인 경고/SSH Banner 재확인 실패", written, unit, backups)
    return result(
        CODE, TITLE, FIXED,
        "로그인 경고 메시지 및 SSH Banner 설정 완료: " + summarize([c["path"] for c in changes])
        + f" | 백업: {summarize(backups)}",
    )
