"""U-41 불필요한 automountd/autofs 서비스 비활성화 조치."""

import os

from common import (
    FAILED,
    FIXED,
    MANUAL,
    pgrep_any,
    result,
    run_command,
    summarize,
    systemctl_is_active,
)


CODE = "U-41"
TITLE = "불필요한 automountd 제거"

AUTOFS_SERVICES = ("autofs", "automount", "automountd")
PROCESS_MARKER = "automountd (pgrep)"


def _get_active():
    active = [
        service for service in AUTOFS_SERVICES if systemctl_is_active(service)
    ]
    if pgrep_any("automountd", "automount"):
        active.append(PROCESS_MARKER)
    return active


def fix(dry_run=False):
    before = _get_active()
    if not before:
        return None
    return result(
        CODE,
        TITLE,
        MANUAL,
        "autofs 사용 여부와 마운트 의존성을 확인한 뒤 비활성화해야 함 — 자동 조치 제외: " + summarize(before),
    )
