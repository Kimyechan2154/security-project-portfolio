"""U-44 tftp/talk/ntalk 서비스 비활성화 조치."""

import os
import re

from common import (
    FAILED,
    FIXED,
    MANUAL,
    backup_file,
    is_listening_on_port,
    pgrep_any,
    read_text,
    result,
    run_command,
    summarize,
    systemctl_is_active,
    write_text,
)


CODE = "U-44"
TITLE = "tftp, talk 서비스 비활성화"

SERVICE_UNITS = ("tftp", "tftp.socket", "tftpd-hpa", "talk", "ntalk")
INETD_PATH = "/etc/inetd.conf"
XINETD_DIR = "/etc/xinetd.d"
XINETD_SERVICES = ("tftp", "talk", "ntalk")

PROCESS_MARKER = "tftpd (pgrep)"
PORT_MARKER = "port 69 (tftp)"


def _is_inetd_service_line(line):
    stripped = line.strip()
    if not stripped or stripped.startswith("#"):
        return False
    tokens = stripped.split()
    return bool(tokens and tokens[0].lower() in XINETD_SERVICES)


def _xinetd_enabled(service):
    content = read_text(os.path.join(XINETD_DIR, service)) or ""
    disable_value = None
    for line in content.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith(("#", ";")):
            continue
        match = re.search(r"\bdisable\s*=\s*(yes|no)\b", stripped, re.I)
        if match:
            disable_value = match.group(1).lower()
    return disable_value == "no"


def _get_active():
    active = [unit for unit in SERVICE_UNITS if systemctl_is_active(unit)]
    if pgrep_any("tftpd", "in.tftpd"):
        active.append(PROCESS_MARKER)
    if is_listening_on_port(69):
        active.append(PORT_MARKER)

    inetd = read_text(INETD_PATH) or ""
    for line in inetd.splitlines():
        if _is_inetd_service_line(line):
            active.append(f"inetd:{line.strip().split()[0]}")
    active.extend(
        f"xinetd:{service}"
        for service in XINETD_SERVICES
        if _xinetd_enabled(service)
    )
    return active


def _backup_and_write(path, original, updated, backups):
    if original == updated:
        return None
    backup = backup_file(path)
    if backup is None:
        return f"{path}: 백업 실패로 변경하지 않음"
    backups.append(backup)
    if not write_text(path, updated):
        return f"{path}: 쓰기 실패"
    return None


def _disable_inetd(backups):
    if not os.path.isfile(INETD_PATH):
        return None, False
    original = read_text(INETD_PATH)
    if original is None:
        return f"{INETD_PATH}: 읽기 실패", False

    output = []
    changed = False
    for line in original.splitlines(keepends=True):
        if _is_inetd_service_line(line):
            output.append(f"# U-44 disabled: {line}")
            changed = True
        else:
            output.append(line)
    if not changed:
        return None, False

    error = _backup_and_write(INETD_PATH, original, "".join(output), backups)
    return error, error is None


def _disable_xinetd_file(service, backups):
    path = os.path.join(XINETD_DIR, service)
    if not os.path.isfile(path):
        return None, False
    original = read_text(path)
    if original is None:
        return f"{path}: 읽기 실패", False
    updated = re.sub(
        r"(?im)^(\s*(?![#;]).*?\bdisable\s*=\s*)no\b",
        r"\1yes",
        original,
    )
    if updated == original:
        return None, False
    error = _backup_and_write(path, original, updated, backups)
    return error, error is None


def _restart_if_active(unit):
    if not systemctl_is_active(unit):
        return None
    code, out, err = run_command(["systemctl", "restart", unit], timeout=20)
    if code != 0:
        return f"{unit}: 재시작 실패({err or out or code})"
    return None


def fix(dry_run=False):
    before = _get_active()
    if not before:
        return None
    return result(
        CODE,
        TITLE,
        MANUAL,
        "TFTP/PXE 및 talk 서비스 사용 여부를 확인한 뒤 비활성화해야 함 — 자동 조치 제외: " + summarize(before),
    )
