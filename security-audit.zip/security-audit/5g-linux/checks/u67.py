"""U-67 로그 파일 소유권·권한 수동 검토 안내."""

import os
try:
    import pwd
except ImportError:  # Windows test host
    pwd = None
import stat
from pathlib import Path

from common import MANUAL, result, summarize


CODE = "U-67"
TITLE = "로그 디렉터리 소유자 및 권한 설정"
LOG_DIR = Path("/var/log")


def _findings():
    if pwd is None:
        return None, ["pwd module unavailable on this host"]
    # Match the checker: missing /var/log is GOOD.
    if not LOG_DIR.exists():
        return 0, []

    checked = 0
    findings = []
    try:
        for root_dir, _, files in os.walk(LOG_DIR):
            for name in files:
                path = Path(root_dir) / name
                try:
                    item = path.stat()
                    owner = pwd.getpwuid(item.st_uid).pw_name
                    mode = stat.S_IMODE(item.st_mode)
                except (KeyError, PermissionError, OSError):
                    continue
                checked += 1
                if owner not in {"root", "syslog"} or mode & stat.S_IWOTH:
                    findings.append(f"{path}(owner={owner},mode={mode:03o})")
                    if len(findings) >= 5:
                        return checked, findings
    except (PermissionError, OSError) as exc:
        return None, [f"{LOG_DIR}: scan failed({exc})"]
    return checked, findings


def fix(dry_run=False):
    checked, findings = _findings()
    if checked is not None and not findings:
        return None
    if checked is None:
        detail = summarize(findings)
    else:
        detail = (
            f"CORE 기준 후보 {len(findings)}/{checked}개 - 서비스별 정상 소유 계정·그룹과 logrotate/tmpfiles 정책 확인 필요: "
            + summarize(findings)
        )
    return result(CODE, TITLE, MANUAL, detail)
