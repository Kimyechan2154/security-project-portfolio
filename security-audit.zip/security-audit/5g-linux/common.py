"""
common.py — 조치팀 공통 유틸리티 (프로젝트 루트, 단일 파일)

main.py 가 프로젝트 루트를 sys.path 에 등록하므로, 어떤 조치 파일에서든
경로 접두어 없이 아래처럼 짧게 import 해서 쓴다.

    from common import FIXED, FAILED, MANUAL, result, backup_file, write_text

※ 확인팀(5G_Check_Tool) common.py 의 읽기 헬퍼를 그대로 가져오고,
   여기에 조치(쓰기) 헬퍼를 추가했다. 대상 환경이 같으므로(Ubuntu 22.04 + MongoDB)
   읽기 판정 로직은 확인팀 것과 동일하게 맞춰 재사용한다.

[ 상태 상수 ]
    FIXED   "조치완료"  — 이번 실행에서 취약 상태를 양호로 변경함
    FAILED  "조치실패"  — 조치 시도했지만 실패(권한 부족 등)
    MANUAL  "수동제외"  — 자동 조치 대상이 아님(정책 판단 필요, 스코프 제외)
    TODO    "미구현"    — 아직 작성 전

    fix() 는 이미 양호라고 판단되면 result(...) 대신 None 을 반환한다.
    main.py 는 None 을 결과·집계에서 완전히 제외한다.
"""

import glob
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import time
from pathlib import Path

try:
    import pwd
    import grp
except ImportError:  # pragma: no cover
    pwd = grp = None

# ──────────────────────────────────────────────
# 상태 상수 (main.py 요약이 이 문자열로 집계)
# ──────────────────────────────────────────────
FIXED = "조치완료"
FAILED = "조치실패"
MANUAL = "수동제외"
TODO = "미구현"

NOLOGIN_SHELLS = {
    "", "/bin/false", "/sbin/nologin", "/usr/sbin/nologin",
    "/bin/nologin", "/usr/bin/false", "/dev/null",
}

MONGOD_CONF = "/etc/mongod.conf"
ADMIN_ROLES = [
    "root", "dbOwner", "userAdmin", "userAdminAnyDatabase",
    "dbAdminAnyDatabase", "readWriteAnyDatabase", "clusterAdmin",
    "clusterManager", "clusterMonitor", "hostManager",
    "backup", "restore", "__system",
]

BACKUP_DIR = "/var/backups/5g-measure-tool"
_BACKUP_METADATA = {}


# ──────────────────────────────────────────────
# 결과 생성
# ──────────────────────────────────────────────
def result(code, title, status, detail=""):
    """표준 결과 딕셔너리. 예: return result(CODE, TITLE, FIXED, "PermitRootLogin no 로 변경")"""
    return {"code": code, "title": title, "status": status, "detail": detail}


# ──────────────────────────────────────────────
# 파일 읽기 (확인팀 common.py 와 동일)
# ──────────────────────────────────────────────
def read_text(path):
    """파일을 문자열로 읽는다. 실패 시 None (예외 없음)."""
    try:
        return Path(path).read_text(encoding="utf-8", errors="ignore")
    except (FileNotFoundError, PermissionError, OSError):
        return None


def read_lines(path):
    """파일을 줄 리스트로 반환한다. 없으면 빈 리스트."""
    text = read_text(path)
    return [] if text is None else text.splitlines()


def parse_passwd(path="/etc/passwd"):
    """/etc/passwd 를 파싱해 [{"name","uid","gid","gecos","home","shell"}] 반환."""
    users = []
    for line in read_lines(path):
        if not line or line.startswith("#"):
            continue
        parts = line.split(":")
        if len(parts) < 7:
            continue
        try:
            uid, gid = int(parts[2]), int(parts[3])
        except ValueError:
            continue
        users.append({
            "name": parts[0], "uid": uid, "gid": gid,
            "gecos": parts[4], "home": parts[5], "shell": parts[6].strip(),
        })
    return users


def passwd_user(name):
    for user in parse_passwd():
        if user["name"] == name:
            return user
    return None


def owner_name(path):
    st = os.stat(path)
    if pwd is None:
        return str(st.st_uid)
    try:
        return pwd.getpwuid(st.st_uid).pw_name
    except KeyError:
        return str(st.st_uid)


def file_owner_mode_ok(path, owner="root", max_mode=0o640):
    """소유자·권한 기준 충족 여부. Returns (bool, "소유자 x, 권한 y")."""
    st = os.stat(path)
    mode = stat.S_IMODE(st.st_mode)
    actual = owner_name(path)
    desc = f"소유자 {actual}, 권한 {mode:03o}"
    if actual != owner:
        return False, desc
    if mode > max_mode or mode & stat.S_IWOTH:
        return False, desc
    return True, desc


def run_command(args, timeout=3):
    try:
        done = subprocess.run(
            args, check=False, capture_output=True, text=True, timeout=timeout,
        )
        return done.returncode, done.stdout.strip(), done.stderr.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired, PermissionError, OSError) as exc:
        return 127, "", str(exc)


def command_exists(name):
    return shutil.which(name) is not None


def systemctl_is_active(*names):
    if not command_exists("systemctl"):
        return False
    for name in names:
        code, out, _ = run_command(["systemctl", "is-active", name])
        if code == 0 and out.strip() == "active":
            return True
    return False


def pgrep_any(*patterns):
    if command_exists("pgrep"):
        for pat in patterns:
            code, _, _ = run_command(["pgrep", "-x", pat])
            if code == 0:
                return True
    proc = Path("/proc")
    if not proc.exists():
        return False
    wanted = set(patterns)
    for comm in proc.glob("[0-9]*/comm"):
        name = read_text(comm)
        if name and name.strip() in wanted:
            return True
    return False


def is_listening_on_port(port):
    for command in (["ss", "-lntup"], ["netstat", "-lntup"]):
        if not command_exists(command[0]):
            continue
        code, out, _ = run_command(command)
        if code == 0 and re.search(rf":{port}\s", out):
            return True
    return False


def glob_existing(patterns):
    paths = []
    for pattern in patterns:
        paths.extend(glob.glob(pattern))
    return sorted(set(paths))


def summarize(items, limit=6):
    if not items:
        return ""
    head = items[:limit]
    suffix = "" if len(items) <= limit else f" 외 {len(items) - limit}건"
    return ", ".join(head) + suffix


# ──────────────────────────────────────────────
# 조치(쓰기) 헬퍼 — 확인팀 common.py 에는 없음, 조치팀 전용
# 원칙: 손대기 전에 반드시 backup_file() 로 백업부터 남긴다.
# ──────────────────────────────────────────────
def backup_file(path):
    """조치 전 원본을 BACKUP_DIR 에 타임스탬프 붙여 복사. 백업 경로 반환(실패 시 None)."""
    src = Path(path)
    if not src.exists():
        return None
    try:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        # Prevent same-basename and same-second backups from overwriting each other.
        identity = hashlib.sha256(
            str(src.resolve()).encode("utf-8")
        ).hexdigest()[:12]
        dest = Path(BACKUP_DIR) / f"{src.name}.{identity}.{time.time_ns()}.bak"
        source_stat = src.stat()
        shutil.copy2(src, dest)
        _BACKUP_METADATA[str(dest)] = {
            "source": str(src),
            "mode": stat.S_IMODE(source_stat.st_mode),
            "uid": source_stat.st_uid,
            "gid": source_stat.st_gid,
        }
        return str(dest)
    except (PermissionError, OSError):
        return None


def restore_backups(backups):
    """현재 실행에서 만든 백업을 역순으로 원위치하고 오류 목록을 반환한다."""
    errors = []
    for backup in reversed(backups):
        metadata = _BACKUP_METADATA.get(str(backup))
        if metadata is None:
            errors.append(f"{backup}: 원본 경로 메타데이터 없음")
            continue
        try:
            shutil.copy2(backup, metadata["source"])
            os.chmod(metadata["source"], metadata["mode"])
            if hasattr(os, "chown"):
                os.chown(metadata["source"], metadata["uid"], metadata["gid"])
        except (PermissionError, OSError) as exc:
            errors.append(f"{metadata['source']}: 원복 실패({exc})")
    return errors


def write_text(path, content, dry_run=False):
    """파일 전체를 덮어쓴다. dry_run=True 면 쓰지 않고 True만 반환(사전 확인용)."""
    if dry_run:
        return True
    try:
        Path(path).write_text(content, encoding="utf-8")
        return True
    except (PermissionError, OSError):
        return False


def replace_or_append_line(path, pattern, new_line, dry_run=False):
    """
    파일에서 정규식 pattern 에 매칭되는 줄을 new_line 으로 치환한다.
    매칭되는 줄이 없으면 파일 끝에 new_line 을 추가한다.
    조치 전 backup_file() 로 백업하는 것을 전제로 한다(이 함수는 백업하지 않음).
    Returns (bool changed, str reason).
    """
    lines = read_lines(path)
    regex = re.compile(pattern)
    matched = False
    out_lines = []
    for line in lines:
        if regex.search(line):
            matched = True
            out_lines.append(new_line)
        else:
            out_lines.append(line)
    if not matched:
        out_lines.append(new_line)

    new_content = "\n".join(out_lines) + "\n"
    if dry_run:
        return True, "dry-run: 변경 예정"
    ok = write_text(path, new_content)
    return ok, ("변경됨" if ok else "쓰기 실패")


def set_file_mode(path, mode, dry_run=False):
    """8진수 mode(int, 예: 0o600)로 권한 변경. Returns bool."""
    if dry_run:
        return True
    try:
        os.chmod(path, mode)
        return True
    except (PermissionError, OSError):
        return False


def set_file_owner(path, owner, group=None, dry_run=False):
    """소유자(및 선택적으로 그룹) 변경. 이름 문자열로 받는다. Returns bool."""
    if pwd is None:
        return False
    if dry_run:
        return True
    try:
        uid = pwd.getpwnam(owner).pw_uid
        gid = grp.getgrnam(group).gr_gid if group else -1
        os.chown(path, uid, gid)
        return True
    except (KeyError, PermissionError, OSError):
        return False


def systemctl_restart(name, dry_run=False):
    """서비스 재시작. Returns (bool ok, str detail)."""
    if dry_run:
        return True, "dry-run: 재시작 예정"
    code, out, err = run_command(["systemctl", "restart", name], timeout=15)
    return code == 0, (err or out or f"exit={code}")


# ──────────────────────────────────────────────
# MongoDB 헬퍼 (읽기 + 조치) — DBMS(D-xx) 항목에서 사용
# 자격 증명은 명령행에 남기지 말고 mongo_eval() 인자로만 전달한다.
# ──────────────────────────────────────────────
def mongo_eval(js_code, user=None, password=None, auth_db="admin",
               auth_mechanism=None, timeout=15):
    cmd = ["mongosh", "--quiet", "--eval", js_code]
    if user and password:
        cmd += ["-u", user, "-p", password, "--authenticationDatabase", auth_db]
    if auth_mechanism:
        cmd += ["--authenticationMechanism", auth_mechanism]
    return run_command(cmd, timeout=timeout)


def mongo_eval_json(js_code, user=None, password=None, auth_db="admin",
                    auth_mechanism=None):
    code, out, _ = mongo_eval(js_code, user, password, auth_db, auth_mechanism)
    if code != 0:
        return None
    try:
        return json.loads(out)
    except (json.JSONDecodeError, ValueError):
        return None


def get_bind_ip():
    text = read_text(MONGOD_CONF)
    if text is None:
        return None
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("#"):
            continue
        if s.startswith("bindIp:"):
            return s.split(":", 1)[1].strip().strip('"').strip("'")
    return None


def is_auth_enabled():
    text = read_text(MONGOD_CONF)
    if text is None:
        return False
    in_security = False
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("#"):
            continue
        if s == "security:":
            in_security = True
            continue
        if in_security and s.startswith("authorization:"):
            val = s.split(":", 1)[1].strip().strip('"').strip("'")
            return val.lower() == "enabled"
        if in_security and s and not line.startswith((" ", "\t")):
            in_security = False
    return False
