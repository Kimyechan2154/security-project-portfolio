#!/usr/bin/env python3
"""
5G_Measure_Tool — KISA U-xx / D-xx 취약점 자동 조치 도구 (조치팀)

확인팀(5G_Check_Tool)이 판정한 자동 항목 중 "취약"을 "양호"로 전환한다.
checks/ 폴더의 항목 파일(uXX.py / dXX.py)을 자동 수집해 fix() 를 실행한다.
공통 코드는 프로젝트 루트의 common.py 하나에 모아 두고, 아래처럼 짧게 import 한다.

    from common import FIXED, FAILED, MANUAL, result, backup_file, ...

(main.py 가 시작 시 프로젝트 루트를 sys.path 에 등록하므로 'checks.' 접두어 불필요)

각 항목 파일 규약:
    # checks/u01.py
    def fix():
        return {"code": "U-01", "title": "root 계정 원격 접속 제한",
                "status": "조치완료", "detail": "PermitRootLogin no 로 변경, sshd 재시작"}
    # 확인 결과 이미 양호(취약 아님)라면 result(...) 대신 None 을 반환한다.
    # main.py 는 None 을 받은 항목을 출력·결과·집계에서 완전히 제외한다.
    # MongoDB 인증이 필요하면  def fix(user=None, password=None):
    # dry_run 을 지원하려면   def fix(dry_run=False): / def fix(user=None, password=None, dry_run=False):

원칙: 조치 전 원본을 common.backup_file() 로 반드시 백업한다. 조치 결과는
5G_Check_Tool 을 재실행해 "양호"로 바뀌는지 확인팀 쪽에서 검증한다(본 도구는 조치만 담당).

실행:
    sudo python3 main.py                     # 전체 조치
    sudo python3 main.py --only u01 d10       # 특정 항목만
    sudo python3 main.py --dry-run            # 실제로 바꾸지 않고 예정 동작만 출력
    sudo python3 main.py -u admin -p '****'   # MongoDB 인증 항목 포함
    sudo python3 main.py --save results/report.txt
"""

import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import argparse
import datetime
import importlib
import inspect
import pkgutil

import checks
from common import FIXED, FAILED, MANUAL, TODO


def load_checks(only=None):
    """checks/ 의 항목 모듈을 자동 수집한다 (새 항목 추가 시 main.py 수정 불필요)."""
    only_norm = {o.lower().replace("-", "") for o in only} if only else None
    modules = []
    for _, name, _ in pkgutil.iter_modules(checks.__path__):
        if only_norm is not None and name.lower() not in only_norm:
            continue
        module = importlib.import_module(f"checks.{name}")
        if hasattr(module, "fix"):
            modules.append(module)
    modules.sort(key=lambda m: m.__name__)
    return modules


def run_fix(module, user=None, password=None, dry_run=False):
    """fix() 시그니처를 보고 user/password/dry_run 인자를 필요한 것만 넘긴다."""
    params = inspect.signature(module.fix).parameters
    kwargs = {}
    if "user" in params and "password" in params:
        kwargs.update(user=user, password=password)
    if "dry_run" in params:
        kwargs["dry_run"] = dry_run
    return module.fix(**kwargs)


def main():
    parser = argparse.ArgumentParser(
        description="KISA 주요정보통신기반시설 취약점 자동 조치 도구 (조치팀)")
    parser.add_argument("-u", "--user", help="MongoDB 인증 사용자")
    parser.add_argument("-p", "--password", help="MongoDB 인증 비밀번호")
    parser.add_argument("--only", nargs="+", metavar="CODE",
                        help="특정 항목만 실행 (예: --only u01 d10)")
    parser.add_argument("--dry-run", action="store_true",
                        help="실제로 변경하지 않고 예정 동작만 출력")
    parser.add_argument("--save", metavar="PATH", help="결과를 텍스트 파일로 저장")
    args = parser.parse_args()

    results, lines = [], []
    for module in load_checks(only=args.only):
        try:
            r = run_fix(module, user=args.user, password=args.password, dry_run=args.dry_run)
            if r is None:
                continue  # 이미 양호(취약 아님) — 출력·결과·집계에서 완전히 제외
            results.append(r)
            line = f"[{r['code']}] {r['status']:<6} {r['title']}"
            print(line)
            lines.append(line)
            if r.get("detail"):
                detail = f"        {r['detail']}"
                print(detail)
                lines.append(detail)
        except Exception as exc:  # 개별 항목 오류 격리
            code = getattr(module, "CODE", module.__name__)
            line = f"[{code}] 오류     {exc}"
            print(line)
            lines.append(line)

    def cnt(status):
        return sum(1 for r in results if r.get("status") == status)

    summary = [
        "", "=" * 60,
        (f"총 {len(results)}개 | 조치완료 {cnt(FIXED)} | "
         f"조치실패 {cnt(FAILED)} | 수동제외 {cnt(MANUAL)} | 미구현 {cnt(TODO)}"),
        ("(dry-run: 실제 변경 없음)" if args.dry_run else ""),
        "=" * 60,
    ]
    print("\n".join(s for s in summary if s))
    lines.extend(s for s in summary if s)

    if args.save:
        os.makedirs(os.path.dirname(args.save) or ".", exist_ok=True)
        header = f"# 5G_Measure_Tool 조치 결과 {datetime.datetime.now():%Y-%m-%d %H:%M:%S}"
        with open(args.save, "w", encoding="utf-8") as fp:
            fp.write(header + "\n" + "\n".join(lines) + "\n")
        print(f"\n결과 저장: {args.save}")

    sys.exit(1 if cnt(FAILED) else 0)


if __name__ == "__main__":
    main()
