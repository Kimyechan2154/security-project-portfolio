# -*- coding: utf-8 -*-
"""D-16: Windows 인증 모드 사용 - MSSQL 전용, MongoDB N/A."""


def check():
    return {
        "code": "D-16",
        "title": "Windows 인증 모드 사용",
        "status": "N/A",
        "detail": (
            "본 항목은 MSSQL의 Windows 인증 모드와 sa 계정 활성화 여부를 "
            "점검하는 MSSQL 전용 항목이다. MongoDB에는 MSSQL의 Windows/혼합 "
            "인증 모드 및 sa 계정 구조가 없어 점검 대상이 아니다(N/A). "
            "매핑표에도 MongoDB 대체 항목이 배정되지 않았다"
        ),
    }


if __name__ == "__main__":
    print(check())
