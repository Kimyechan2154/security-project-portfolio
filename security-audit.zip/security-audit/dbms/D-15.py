# -*- coding: utf-8 -*-
"""D-15: Oracle Listener 전용 항목 - MongoDB N/A."""


def check():
    return {
        "code": "D-15",
        "title": "리스너 로그·trace 파일 변경 제한",
        "status": "N/A",
        "detail": (
            "본 항목은 Oracle Listener의 listener.ora 권한과 "
            "ADMIN_RESTRICTIONS 설정을 점검하는 Oracle 전용 항목이다. "
            "MongoDB에는 Oracle Listener 구성요소가 없어 점검 대상이 아니다(N/A). "
            "매핑표에도 MongoDB 대체 항목이 배정되지 않았다"
        ),
    }


if __name__ == "__main__":
    print(check())
