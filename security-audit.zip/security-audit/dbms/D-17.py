# -*- coding: utf-8 -*-

"""
D-17: 감사(Audit) 로그 파일 접근 권한 제한

- MongoDB Community는 감사 기능을 지원하지 않으므로 N/A
- auditLog.destination이 "file"일 때만 파일 권한 점검
- 허용 권한: 400, 440, 600, 640
- MongoDB 서버와 같은 호스트에서 실행해야 함
- MongoDB 설정 조회 권한과 OS 파일 메타데이터 조회 권한 필요
"""

import os
import stat
from pathlib import Path

try:
    import grp
    import pwd
except ImportError:
    grp = None
    pwd = None

try:
    from pymongo import MongoClient
    from pymongo.errors import PyMongoError
except ImportError:
    MongoClient = None
    PyMongoError = Exception


URI = os.environ.get(
    "MONGO_URI",
    "mongodb://localhost:27017",
)

CODE = "D-17"
TITLE = "감사(Audit) 로그 파일 접근 권한 제한"

SAFE_MODES = {
    0o400,
    0o440,
    0o600,
    0o640,
}

ALLOWED_OWNERS = {
    value.strip()
    for value in os.environ.get(
        "MONGO_AUDIT_ALLOWED_OWNERS",
        "mongodb,mongod,root",
    ).split(",")
    if value.strip()
}

ALLOWED_GROUPS = {
    value.strip()
    for value in os.environ.get(
        "MONGO_AUDIT_ALLOWED_GROUPS",
        "mongodb,mongod,root",
    ).split(",")
    if value.strip()
}

LOCAL_FS_CONFIRMED = os.environ.get(
    "MONGO_LOCAL_FS_CHECK",
    "false",
).lower() in {
    "true",
    "1",
    "yes",
}


def _result(status, detail):
    return {
        "code": CODE,
        "title": TITLE,
        "status": status,
        "detail": detail,
    }


def _identity_names(file_stat):
    """파일 UID/GID를 계정명으로 변환한다."""
    owner = str(file_stat.st_uid)
    group = str(file_stat.st_gid)

    if pwd is not None:
        try:
            owner = pwd.getpwuid(file_stat.st_uid).pw_name
        except KeyError:
            pass

    if grp is not None:
        try:
            group = grp.getgrgid(file_stat.st_gid).gr_name
        except KeyError:
            pass

    return owner, group


def check():
    if MongoClient is None:
        return _result(
            "N/A",
            "[점검불가] pymongo 모듈이 없어 "
            "MongoDB 감사 설정을 조회할 수 없음",
        )

    client = None

    try:
        client = MongoClient(
            URI,
            serverSelectionTimeoutMS=3000,
        )
        admin = client.admin

        # 에디션과 버전 확인
        build = admin.command("buildInfo")
        version = build.get("version", "unknown")

        modules = {
            str(module).lower()
            for module in (build.get("modules") or [])
        }

        if "enterprise" not in modules:
            return _result(
                "N/A",
                f"MongoDB Community 에디션(version={version})은 "
                "감사 기능을 지원하지 않아 점검 대상 파일이 없음",
            )

        # 감사 설정 확인
        parsed = (
            admin.command("getCmdLineOpts").get("parsed", {})
            or {}
        )

        audit = parsed.get("auditLog") or {}

        destination = audit.get("destination")
        path = audit.get("path")
        audit_format = audit.get("format")

        if not destination:
            return _result(
                "N/A",
                "감사 출력이 설정되지 않아 "
                "점검할 감사 로그 파일이 없음",
            )

        if destination != "file":
            return _result(
                "N/A",
                f"감사 출력 대상이 파일이 아님"
                f"(destination={destination!r})",
            )

        if not path:
            return _result(
                "취약",
                "auditLog.destination은 file이지만 "
                "auditLog.path가 설정되지 않음",
            )

        # 상대경로는 MongoDB 프로세스의 작업 디렉터리를
        # 확정하지 않으면 정확하게 검사할 수 없다.
        if not Path(path).is_absolute():
            return _result(
                "N/A",
                f"[점검불가] auditLog.path가 상대경로라 "
                f"실제 파일 위치를 확정할 수 없음(path={path})",
            )

        # auditLog.path는 MongoDB 서버의 경로다.
        # 원격 점검기에서 같은 문자열의 로컬 파일을
        # 잘못 검사하지 않도록 실행 환경을 확인한다.
        if not LOCAL_FS_CONFIRMED:
            return _result(
                "N/A",
                "[점검불가] MongoDB 서버와 동일한 "
                "파일시스템에서 실행됐는지 확인되지 않음. "
                "동일 호스트에서 MONGO_LOCAL_FS_CHECK=true로 실행 필요",
            )

        try:
            file_stat = os.stat(path)
            mode = stat.S_IMODE(file_stat.st_mode)

        except FileNotFoundError:
            return _result(
                "취약",
                f"감사 출력이 file로 설정됐지만 "
                f"로그 파일을 찾을 수 없음(path={path})",
            )

        except OSError as e:
            return _result(
                "N/A",
                f"[점검불가] 감사 로그 파일의 권한을 "
                f"확인할 수 없음(path={path}, "
                f"error={type(e).__name__})",
            )

        format_note = (
            f", format={audit_format}"
            if audit_format
            else ""
        )

        owner, group = _identity_names(file_stat)
        owner_ok = owner in ALLOWED_OWNERS
        group_has_access = bool(mode & 0o070)
        group_ok = not group_has_access or group in ALLOWED_GROUPS

        if mode in SAFE_MODES and owner_ok and group_ok:
            if mode in {0o440, 0o640}:
                permission_note = (
                    "승인된 그룹 읽기 허용, "
                    "그룹 쓰기와 other 접근 차단"
                )
            else:
                permission_note = (
                    "그룹과 other 접근 차단"
                )

            return _result(
                "양호",
                f"감사 로그 파일 권한이 {oct(mode)}로 "
                f"허용 기준을 충족함"
                f"({permission_note}). "
                f"owner={owner}, group={group}, "
                f"path={path}{format_note}",
            )

        problems = []
        if mode not in SAFE_MODES:
            problems.append(
                f"권한 {oct(mode)}가 허용값(400/440/600/640)에 포함되지 않음"
            )
        if not owner_ok:
            problems.append(
                f"소유자 {owner}가 허용 소유자({', '.join(sorted(ALLOWED_OWNERS))})가 아님"
            )
        if not group_ok:
            problems.append(
                f"읽기 권한이 있는 그룹 {group}이 허용 그룹"
                f"({', '.join(sorted(ALLOWED_GROUPS))})이 아님"
            )

        return _result(
            "취약",
            "감사 로그 파일 접근 제한이 안전 기준을 충족하지 않음: "
            f"{'; '.join(problems)}. owner={owner}, group={group}, "
            f"path={path}{format_note}",
        )

    except PyMongoError as e:
        return _result(
            "N/A",
            f"[점검불가] MongoDB 연결 또는 설정 조회 실패: "
            f"{type(e).__name__}. "
            "MONGO_URI와 설정 조회 권한 확인 필요",
        )

    finally:
        if client is not None:
            client.close()


if __name__ == "__main__":
    print(check())
