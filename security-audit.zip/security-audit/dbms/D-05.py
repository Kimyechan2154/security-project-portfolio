# -*- coding: utf-8 -*-
"""D-05: 비밀번호 재사용에 대한 제약 설정 — MongoDB N/A"""


def check():
    return {
        "code": "D-05",
        "title": "비밀번호 재사용에 대한 제약 설정",
        "status": "N/A",
        "detail": (
            "MongoDB는 이전에 사용한 비밀번호 이력(password history)을 보관하거나 "
            "동일 비밀번호로의 재설정을 차단하는 정책 기능을 자체적으로 제공하지 않는다. "
            "SCRAM 기반 인증은 사용자별로 salted hash 한 개만 저장하며 과거 비밀번호를 "
            "누적하지 않으므로 '재사용 이력 비교'라는 점검 자체가 성립하지 않는다. "
            "따라서 본 항목은 MongoDB에 대응 구성요소가 없어 점검 대상에서 제외한다(N/A). "
            "매핑표에도 대체 항목이 배정되지 않았다."
        ),
    }


if __name__ == "__main__":
    print(check())