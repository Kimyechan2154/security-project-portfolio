"""D-01: 기본 계정의 비밀번호·정책 변경.

MongoDB는 설치 시 초기 비밀번호가 설정된 기본 관리자 계정을 자동으로
생성하지 않는다. 따라서 계정 이름을 추측할 수 있다는 이유만으로 취약 판정하지
않고, 무인증 접근을 차단하는 authorization 활성화 여부를 자동 점검한다.
"""

import os

try:
    from pymongo import MongoClient
    from pymongo.errors import PyMongoError
except ImportError:
    MongoClient = None
    PyMongoError = Exception


URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017")

CODE = "D-01"
TITLE = "기본 계정의 비밀번호·정책 변경"


def _result(status, detail):
    return {
        "code": CODE,
        "title": TITLE,
        "status": status,
        "detail": detail,
    }


def check():
    if MongoClient is None:
        return _result(
            "N/A",
            "[점검불가] pymongo 모듈이 없어 MongoDB 설정을 조회할 수 없음",
        )

    client = None
    try:
        client = MongoClient(URI, serverSelectionTimeoutMS=3000)
        client.admin.command("ping")
    except PyMongoError as e:
        if client is not None:
            client.close()
        return _result(
            "N/A",
            f"[점검불가] MongoDB 접속 실패: {type(e).__name__}. "
            "MONGO_URI와 접속 정보를 확인해야 함",
        )

    try:
        parsed = client.admin.command("getCmdLineOpts").get("parsed", {}) or {}
        security = parsed.get("security") or {}
        authorization = security.get("authorization", "disabled")
    except PyMongoError as e:
        return _result(
            "N/A",
            f"[점검불가] MongoDB 설정 조회 실패: {type(e).__name__}. "
            "getCmdLineOpts 조회 권한이 있는 계정으로 실행해야 함",
        )
    finally:
        if client is not None:
            client.close()

    auth_enabled = (
        authorization is True
        or str(authorization).strip().lower() == "enabled"
    )

    if auth_enabled:
        return _result(
            "양호",
            "security.authorization=enabled 확인. 무인증 접근이 차단되어 있음. "
            "MongoDB는 초기 비밀번호가 설정된 기본 관리자 계정을 자동 생성하지 "
            "않으므로 계정 이름만으로 취약 판정하지 않음",
        )

    return _result(
        "취약",
        "security.authorization이 비활성화되어 무인증 접근이 가능함. "
        "/etc/mongod.conf에서 security.authorization을 enabled로 설정한 뒤 "
        "MongoDB 서비스를 재시작해야 함",
    )


if __name__ == "__main__":
    print(check())
