"""Regenerate the site's QR assets: pip install reportlab pillow."""
from pathlib import Path
from PIL import Image, ImageDraw
from reportlab.graphics.barcode.qrencoder import QRCode, QRErrorCorrectLevel

URL = 'https://hiding-lab-kimyechan.est-ai-chall-6154.chatgpt.site/'
ROOT = Path(__file__).resolve().parents[1]
qr = QRCode(None, QRErrorCorrectLevel.M)
qr.addData(URL)
qr.make()
matrix = qr.modules
border, scale = 4, 20
units = len(matrix) + border * 2
im = Image.new('RGB', (units * scale, units * scale), 'white')
draw = ImageDraw.Draw(im)
path = []
for y, row in enumerate(matrix):
    for x, dark in enumerate(row):
        if dark:
            a, b = x + border, y + border
            draw.rectangle((a*scale, b*scale, (a+1)*scale-1, (b+1)*scale-1), fill='black')
            path.append(f'M{a},{b}h1v1h-1z')
im.save(ROOT / 'dist/hiding-qr.png', dpi=(300, 300))
svg = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {units} {units}" shape-rendering="crispEdges"><title>Hiding site QR code</title><rect width="{units}" height="{units}" fill="white"/><path d="{"".join(path)}" fill="black"/></svg>\n'
(ROOT / 'dist/hiding-qr.svg').write_text(svg, encoding='utf-8')
with Image.open(ROOT / 'dist/hiding-qr.png') as saved:
    assert saved.size == (units*scale, units*scale)
    for y, row in enumerate(matrix):
        for x, dark in enumerate(row):
            assert saved.getpixel(((x+border)*scale+scale//2,(y+border)*scale+scale//2)) == ((0,0,0) if dark else (255,255,255))
print(f'Created and checked PNG/SVG: {units*scale}px; {URL}')
