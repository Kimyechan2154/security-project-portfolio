# PEPSI · Side-Channel Lab

기존 PEPSI CPA C 코드를 중심으로 만든 로컬 분석 웹 도구입니다.

## 지금 사용하기

현재 PC에서는 필요한 환경과 빌드가 준비되어 있습니다.

1. `start.cmd`를 더블클릭합니다.
2. 브라우저에서 `http://127.0.0.1:8765`를 엽니다.
3. 합성 예제에서 단일 바이트, 전체 키 복구, Trace 수 비교를 실행해 보세요.
4. 자신의 `.trace`와 평문 `.txt`를 업로드하면 같은 C 엔진으로 분석합니다.

이미 서버가 실행 중이면 기존 화면을 엽니다. 새로 서버를 실행한 콘솔을 닫으면 서버도 종료됩니다.

## 구현된 기능

- 다크 연구실 UI, 한국어 안내, 작은 화면 대응
- Trace/plaintext 업로드 및 파일 크기·행 수·유한값 검증
- 첫 trace와 앞 100개 평균 파형, 드래그 ROI 선택
- 한 바이트 분석, 16바이트 전체 분석, 선택 바이트의 Trace 수별 비교
- 256개 키 후보 점수, 우승 후보의 피크 위치, 키 복구 현황
- C 프로세스에서 실제 계산, 대기열과 진행률, 실행·대기 취소
- SQLite 기반 분석 기록: 서버 재시작 후에도 유지
- 결과 JSON/CSV 다운로드, 입력 데이터 재다운로드
- 알려진 키가 있는 경우에만 정답 여부·정답 후보 순위 표시
- 외부 네트워크 없이 작동하는 번들 폰트와 UI

## 데이터 형식

Trace는 little-endian IEEE-754 float32, 행마다 한 trace입니다. 원래 프로젝트 기본 설정은 32바이트 헤더와 trace당 1,696 points입니다. 헤더의 내용을 해석하거나 장비 포맷을 자동 감지하지 않으므로 실제 데이터 규격에 맞게 설정하세요.

`파일 크기 = 헤더 bytes + trace 수 × point 수 × 4`

평문은 trace 순서에 맞춘 AES 16바이트 HEX 블록입니다. 공백·줄바꿈 및 UTF-8 BOM을 허용합니다. 예: `2B 7E 15 16 ...`처럼 바이트 단위로 띄우거나 붙여 써도 됩니다. 모든 trace에 평문이 하나씩 있어야 합니다.

앱에서 다운로드한 trace는 **헤더가 0바이트**입니다. 함께 표시되는 point 수와 헤더 0을 설정해 재업로드하세요. 검증용 정답 키는 선택 사항이며 32자리 HEX입니다.

제한: trace 파일 256 MiB, 평문 4 MiB, 최대 100,000 traces / 200,000 points. 실제 사용량은 파일 크기 제한도 함께 적용됩니다. 분석 구간의 끝점은 제외합니다. 표시용 그래프만 피크 보존 방식으로 축약하며 실제 계산은 선택 구간 전체를 사용합니다.

## 합성 예제

2,000 traces × 384 points. 고정 난수 seed 20260909, HW 누설과 가우시안 노이즈로 생성합니다. 정답 키는 `2B7E151628AED2A6ABF7158809CF4F3C`입니다. 측정 장비의 실측 데이터가 아닙니다.

이 PC에서 합성 trace 1,000개로 전체 16바이트를 복구한 결과는 16/16 일치, 약 7.06초였습니다. 성능과 정확도는 실제 입력에 따라 달라집니다. 업로드된 원래 과제에는 실측 trace/plaintext 파일이 없어 해당 파일의 키 복구는 아직 검증되지 않았습니다.

## 구조

```text
original/           원래 C 소스, 변경 없이 보존
cpa-core/include/   S-box/HW 테이블, 엔진 인터페이스
cpa-core/src/       CPA 계산과 JSONL CLI
backend/app.py      FastAPI, 파일 검증, 프로세스 대기열, 기록
frontend/src/       React + TypeScript 화면
runtime-data/       로컬 데이터와 기록 (공유/Git 제외)
tests/             수치 비교·입출력·취소 테스트
docs/               엔진 변경 내역과 검증 기록
```

FastAPI는 Python에서 CPA를 재계산하지 않고 C CLI를 호출합니다. NumPy는 파일 검증, 예제 생성, 파형 미리보기에 사용합니다. 분석은 한 번에 하나씩 실행되며 최대 4개 작업이 실행/대기할 수 있습니다. 개별 C 프로세스는 20분 제한이 있습니다. 서버 재시작으로 중단된 작업은 실패로 기록하고 다시 실행할 수 있습니다.

## 다른 PC에서 개발 환경 준비

Python 3.11 이상, Node.js 20.19 이상, CMake 3.20 이상, C 컴파일러가 필요합니다. Windows에서는 Visual Studio의 C++ 데스크톱 개발 도구를 설치하세요. 원본 C 소스의 소유권은 사용자에게 있습니다. AI가 추가한 웹/API 코드는 별도 폴더로 구분했습니다.

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
cmake -S cpa-core -B cpa-core/build -A x64
cmake --build cpa-core/build --config Release
cd frontend
npm ci
npm run build
cd ..
.\.venv\Scripts\python.exe run_local.py
```

현재 PC에서는 CMake가 Visual Studio 하위 폴더에 있으며 일반 터미널 PATH에는 없을 수 있습니다. Visual Studio 개발자 터미널에서 실행하거나 `Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe` 경로를 사용하세요.

Linux/macOS는 `-A x64`를 생략하고 Release 빌드 타입을 지정합니다. 기본 실행 파일 경로는 `cpa-core/build/cpa_cli`입니다. Windows 빌드와 실행만 이번에 실제 검증했습니다.

개발 시 API를 8765 포트에서 실행한 뒤 `frontend`에서 `npm run dev`를 실행하면 Vite의 5173 포트가 API에 연결됩니다.

```powershell
.\.venv\Scripts\python.exe -m uvicorn backend.app:app --host 127.0.0.1 --port 8765
.\.venv\Scripts\python.exe -m pytest tests -q
```

앱은 로컬 전용입니다. 사용자 계정, 공개 서비스 배포, 마스킹 분석, 시간축 정렬, 필터링은 포함하지 않습니다. 외부 배포 전에 별도 설계가 필요합니다.

## 해석 주의점

- Peak Ratio는 1위/2위 피크의 비율이지 정답 확률이 아닙니다.
- 키 후보가 있다는 사실만으로 정답이라고 표시하지 않습니다. 검증용 키가 있을 때만 대조합니다.
- 모든 점의 분산이 0이면 키 대신 유효 신호 없음을 표시합니다.
- Trace 수 비교는 같은 데이터 앞 N개의 수렴 관찰입니다. 독립 반복 실험의 성공률이 아닙니다.
- 원본의 float 곱셈 후 double 누적과 Pearson 공식을 유지했습니다. 큰 DC 성분 등으로 인한 수치 불안정성을 해결하는 알고리즘 교체는 하지 않았습니다.
