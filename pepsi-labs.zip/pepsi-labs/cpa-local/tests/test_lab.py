import json
import re
import subprocess
import time
from pathlib import Path

import numpy as np
import pytest
from fastapi.testclient import TestClient

from backend import app as lab


@pytest.fixture(scope='module')
def client(tmp_path_factory):
    lab.DATA = tmp_path_factory.mktemp('lab-data')
    lab.DB = lab.DATA / 'lab.sqlite3'
    with TestClient(lab.app) as c:
        yield c


def wait_job(client, ident):
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        j = client.get('/api/analyses/' + ident).json()
        if j['status'] not in ('queued', 'running'):
            return j
        time.sleep(.05)
    pytest.fail('Job did not finish')


def get_demo(client):
    response = client.post('/api/datasets/demo')
    assert response.status_code == 200
    return response.json()


def create_job(client, ds, **kwargs):
    settings = dict(dataset_id=ds['id'], mode='single', target=0, count=1000, start=0, end=ds['points'])
    settings.update(kwargs)
    response = client.post('/api/analyses', json=settings)
    assert response.status_code == 202, response.text
    return response.json()['id']


def test_tables_preserved_and_aes_definition():
    original = (lab.ROOT/'original/main.c').read_text(encoding='utf-8')
    extracted = (lab.ROOT/'cpa-core/include/aes_tables.h').read_text(encoding='utf-8')
    for name in ('sbox', 'hw_table'):
        def table(s):
            body = re.search(name + r'\[256\]\s*=\s*\{([^}]+)', s).group(1)
            return [int(x,0) for x in re.findall(r'0x[0-9a-fA-F]+|\d+',body)]
        assert table(original) == table(extracted)
    box = [int(v,16) for v in re.findall(r'0x[0-9a-fA-F]{2}', extracted)]
    def multiply(a,b):
        result=0
        for _ in range(8):
            if b&1: result ^= a
            a = ((a<<1)^ (0x11b if a&128 else 0)) & 255
            b >>= 1
        return result
    def subbyte(x):
        inverse = 0 if x==0 else next(y for y in range(1,256) if multiply(x,y)==1)
        v=inverse
        for shift in range(1,5):
            v ^= ((inverse<<shift)|(inverse>>(8-shift)))&255
        return v^0x63
    assert box == [subbyte(x) for x in range(256)]


def test_native_matches_original_formula_and_nonzero_roi(client):
    ds = get_demo(client)
    job = wait_job(client, create_job(client, ds, count=200, start=12, end=60))
    assert job['status']=='completed'
    r=job['results'][0]
    x=np.fromfile(lab.DATA/ds['id']/'traces.f32',dtype='<f4').reshape(ds['count'],ds['points'])[:200,12:60]
    pt=np.fromfile(lab.DATA/ds['id']/'plaintext.u8',dtype=np.uint8).reshape(-1,16)[:200,0]
    original=(lab.ROOT/'original/main.c').read_text(encoding='utf-8')
    body=re.search(r'sbox\[256\]\s*=\s*\{([^}]+)',original).group(1)
    box=np.array([int(v,16) for v in re.findall(r'0x[0-9a-fA-F]{2}',body)])
    hw=np.array([i.bit_count() for i in range(256)])
    sx=x.sum(axis=0,dtype=np.float64)
    sx2=(x*x).sum(axis=0,dtype=np.float64)
    scores=[]
    curves=[]
    for k in range(256):
        y=hw[box[pt^k]].astype(np.float32)
        sy=y.sum(dtype=np.float64)
        sy2=(y*y).sum(dtype=np.float64)
        sxy=(x*y[:,None]).sum(axis=0,dtype=np.float64)
        curve=np.abs((200*sxy-sx*sy)/np.sqrt((200*sx2-sx*sx)*(200*sy2-sy*sy)))
        scores.append(curve.max());curves.append(curve)
    np.testing.assert_allclose(r['scores'],scores,atol=1e-11,rtol=1e-11)
    assert r['key']==int(np.argmax(scores))==43
    assert r['point']==12+int(np.argmax(curves[43]))
    np.testing.assert_allclose(r['curve'],curves[43],atol=1e-11,rtol=1e-11)


def test_all_bytes_and_exports(client):
    ds=get_demo(client)
    job=wait_job(client,create_job(client,ds,mode='all'))
    assert job['status']=='completed'
    assert len(job['results'])==16
    assert [r['key'] for r in job['results']]==ds['known_key']
    assert all(r['correct'] and r['true_key_rank']==1 for r in job['results'])
    export=client.get('/api/analyses/'+job['id']+'/export')
    assert export.json()['fingerprint']==ds['fingerprint']
    csv=client.get('/api/analyses/'+job['id']+'/export?format=csv')
    assert len(csv.text.splitlines())==4097
    assert 'attachment' in csv.headers['content-disposition']
    assert any(j['id']==job['id'] for j in client.get('/api/analyses').json())


def test_convergence(client):
    ds=get_demo(client)
    j=wait_job(client,create_job(client,ds,mode='convergence',count=400,steps=[50,100,400]))
    assert j['status']=='completed'
    assert [r['count'] for r in j['results']]==[50,100,400]
    assert j['results'][-1]['key']==43


def test_upload_roundtrip_and_bad_formats(client):
    ds=get_demo(client)
    raw=client.get('/api/datasets/'+ds['id']+'/download/trace').content
    plain=client.get('/api/datasets/'+ds['id']+'/download/plaintext').content
    def upload(trace=raw,pt=plain,**values):
        return client.post('/api/datasets/upload',data={'points':384,'header_bytes':0,**values},
                           files={'trace':('sample.trace',trace),'plaintext':('plain.txt',pt)})
    good=upload()
    assert good.status_code==200,good.text
    assert good.json()['fingerprint']==ds['fingerprint']
    assert good.json()['known_key'] is None
    j=wait_job(client,create_job(client,good.json(),count=200))
    assert j['results'][0]['correct'] is None
    assert upload(raw[:-1]).status_code==422
    assert upload(pt=b'00').status_code==422
    assert upload(header_bytes=32).status_code==422
    assert upload(known_key='garbage').status_code==422
    bad=bytearray(raw)
    bad[:4]=np.float32(np.nan).tobytes()
    assert upload(bytes(bad)).status_code==422
    key='2B7E151628AED2A6ABF7158809CF4F3C'
    assert upload(known_key=key).json()['known_key']==ds['known_key']


def test_invalid_ranges_and_origin(client):
    ds=get_demo(client)
    base=dict(dataset_id=ds['id'],count=1000,start=0,end=384,target=0)
    for patch in [dict(count=2001),dict(start=40,end=20),dict(end=385),dict(target=16),dict(count=1),dict(mode='convergence',steps=[0,10])]:
        assert client.post('/api/analyses',json=base|patch).status_code==422
    assert client.post('/api/analyses',json=base,headers={'Origin':'https://example.com'}).status_code==403
    assert client.get('/api/analyses/missing').status_code==404


def test_zero_variance_never_claims_key(client):
    ds=get_demo(client)
    pt=np.fromfile(lab.DATA/ds['id']/'plaintext.u8',dtype=np.uint8).reshape(-1,16)[:40]
    flat=lab.store_dataset(np.zeros((40,12),dtype=np.float32),pt,'constant','uploaded')
    j=wait_job(client,create_job(client,flat,count=40,end=12))
    r=j['results'][0]
    assert r['valid'] is False and r['key']==-1 and r['point']==-1
    assert r['correct'] is None and r['peak']==0


def test_cancel_active_and_queued(client):
    ds=get_demo(client)
    first=create_job(client,ds,mode='all',count=2000)
    second=create_job(client,ds,mode='all',count=2000)
    assert client.post('/api/analyses/'+second+'/cancel').status_code==200
    assert client.post('/api/analyses/'+first+'/cancel').status_code==200
    assert wait_job(client,first)['status']=='cancelled'
    assert wait_job(client,second)['status']=='cancelled'
    follow=wait_job(client,create_job(client,ds,count=100))
    assert follow['status']=='completed'
