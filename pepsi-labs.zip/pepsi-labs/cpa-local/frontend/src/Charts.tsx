import {useEffect,useId,useRef,useState} from 'react';
import type {PointerEvent} from 'react';
import {hex} from './types';

type Point={x:number;y:number};
type Series={name:string;color:string;points:Point[];faint?:boolean};
function useChartWidth(){
  const ref=useRef<HTMLDivElement>(null);
  const [width,setWidth]=useState(600);
  useEffect(()=>{const element=ref.current;if(!element)return;const measure=()=>setWidth(Math.max(220,Math.floor(element.getBoundingClientRect().width)-18));measure();const observer=new ResizeObserver(measure);observer.observe(element);return()=>observer.disconnect()},[]);
  return {ref,width};
}
function decimate(points:Point[]):Point[]{
  if(points.length<=2400)return points;
  const size=Math.ceil(points.length/1200),out:Point[]=[];
  for(let i=0;i<points.length;i+=size){const chunk=points.slice(i,i+size);let min=chunk[0],max=chunk[0];for(const p of chunk){if(p.y<min.y)min=p;if(p.y>max.y)max=p}out.push(...(min.x<=max.x?[min,max]:[max,min]))}
  return out;
}
export function LineChart({series,height=210,yLabel='',xLabel='SAMPLE INDEX',selection,onSelect,yMax,empty='분석을 실행하면 그래프가 나타납니다.'}:{series:Series[];height?:number;yLabel?:string;xLabel?:string;selection?:[number,number];onSelect?:(a:number,b:number)=>void;yMax?:number;empty?:string}){
  series=series.map(s=>({...s,points:decimate(s.points)}));
  const id=useId().replaceAll(':','');
  const {ref,width}=useChartWidth();
  const [hover,setHover]=useState<Point|null>(null);
  const [drag,setDrag]=useState<number|null>(null);
  const all=series.flatMap(s=>s.points);
  if(!all.length)return <div ref={ref} className="chart-empty" style={{height}}><div className="empty-pulse">⌁</div><span>{empty}</span></div>;
  const W=width,H=height,L=42,R=16,T=20,B=33;
  const ticks=W<400?3:6;
  const minX=all.reduce((v,p)=>Math.min(v,p.x),Infinity),maxX=all.reduce((v,p)=>Math.max(v,p.x),minX+1);
  const rawMin=all.reduce((v,p)=>Math.min(v,p.y),Infinity),rawMax=all.reduce((v,p)=>Math.max(v,p.y),-Infinity);
  const lo=yMax!==undefined?0:rawMin-(rawMax-rawMin||1)*.12;
  const hi=yMax??rawMax+(rawMax-rawMin||1)*.12;
  const sx=(x:number)=>L+(x-minX)/(maxX-minX)*(W-L-R);
  const sy=(y:number)=>H-B-(y-lo)/(hi-lo||1)*(H-T-B);
  const at=(e:PointerEvent<SVGSVGElement>)=>{
    const r=e.currentTarget.getBoundingClientRect();
    const x=minX+Math.max(0,Math.min(1,((e.clientX-r.left)/r.width*W-L)/(W-L-R)))*(maxX-minX);
    const p=series[0].points.reduce((a,b)=>Math.abs(b.x-x)<Math.abs(a.x-x)?b:a);
    setHover(p);return Math.round(x);
  };
  return <div ref={ref} className={'chart-wrap '+(onSelect?'selectable':'')}>
    <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" role="img" aria-label={yLabel||'분석 그래프'} onPointerMove={at} onPointerLeave={()=>{if(drag===null)setHover(null)}} onPointerDown={e=>{if(onSelect){e.currentTarget.setPointerCapture(e.pointerId);setDrag(at(e))}}} onPointerUp={e=>{if(drag!==null&&onSelect){const end=at(e);if(end!==drag)onSelect(Math.min(drag,end),Math.max(drag,end)+1);setDrag(null)}}} style={{height}}>
      <defs><linearGradient id={id} x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor={series[0].color} stopOpacity=".12"/><stop offset="100%" stopColor={series[0].color} stopOpacity="0"/></linearGradient><clipPath id={id+'clip'}><rect x={L} y={T} width={W-L-R} height={H-T-B}/></clipPath></defs>
      {[0,1,2,3,4].map(i=>{const y=T+i*(H-T-B)/4;return <g key={i}><line x1={L} x2={W-R} y1={y} y2={y} className="gridline"/><text x={L-12} y={y+4} textAnchor="end">{(hi-i*(hi-lo)/4).toFixed(2)}</text></g>})}
      {Array.from({length:ticks+1},(_,i)=>{const x=L+i*(W-L-R)/ticks;return <g key={i}><line x1={x} x2={x} y1={T} y2={H-B} className="gridline vertical"/><text x={x} y={H-12} textAnchor="middle">{Math.round(minX+i*(maxX-minX)/ticks)}</text></g>})}
      <g clipPath={`url(#${id}clip)`}>
      {selection&&<rect x={sx(selection[0])} y={T} width={Math.max(0,sx(selection[1]-1)-sx(selection[0]))} height={H-T-B} fill="#99dec1" opacity=".04" stroke="#99dec1" strokeDasharray="4 4"/>}
      {series.map((s,j)=>{const path=s.points.map((p,i)=>`${i?'L':'M'}${sx(p.x).toFixed(2)},${sy(p.y).toFixed(2)}`).join(' ');return <g key={s.name}>{j===0&&<path d={`${path} L${sx(s.points.at(-1)!.x)},${H-B} L${sx(s.points[0].x)},${H-B} Z`} fill={`url(#${id})`}/>}<path d={path} fill="none" stroke={s.color} strokeWidth={s.faint?1:1.7} opacity={s.faint?.38:.95} vectorEffect="non-scaling-stroke"/></g>})}
      {drag!==null&&hover&&<rect x={sx(Math.min(drag,hover.x))} y={T} width={Math.abs(sx(drag)-sx(hover.x))} height={H-T-B} fill="#c5f1dd" opacity=".2"/>}
      {hover&&<g><line x1={sx(hover.x)} x2={sx(hover.x)} y1={T} y2={H-B} stroke="#b6dbce" strokeDasharray="3 3"/><circle cx={sx(hover.x)} cy={sy(hover.y)} r="3" fill={series[0].color}/></g>}
      </g>
    </svg>
    <div className="chart-meta"><span>{yLabel}</span><span>{hover?`${hover.x} → ${hover.y.toFixed(4)}`:xLabel}</span></div>
  </div>;
}

export function CandidateChart({scores,best}:{scores:number[];best:number}){
  const {ref,width:chartWidth}=useChartWidth();
  const [hover,setHover]=useState<number|null>(null);
  const W=chartWidth,H=192,L=42,R=14,T=20,B=27;
  const peak=Math.max(.1,...scores)*1.12;
  const width=(W-L-R)/256;
  return <div ref={ref} className="chart-wrap"><svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" role="img" aria-label="256개 키 후보의 최대 상관계수" style={{height:192}} onPointerLeave={()=>setHover(null)}>
    {[0,1,2,3].map(i=><g key={i}><line x1={L} x2={W-R} y1={T+i*(H-T-B)/3} y2={T+i*(H-T-B)/3} className="gridline"/><text x={L-9} y={T+i*(H-T-B)/3+4} textAnchor="end">{(peak*(1-i/3)).toFixed(2)}</text></g>)}
    {scores.map((s,k)=><rect key={k} x={L+k*width} y={H-B-s/peak*(H-T-B)} width={Math.max(1,width-1)} height={s/peak*(H-T-B)} fill={k===best?'#b3edd2':hover===k?'#a1b8b0':'#506a62'} onPointerMove={()=>setHover(k)}><title>{`0x${hex(k)}: ${s.toFixed(6)}`}</title></rect>)}
    {(W<400?[0,64,128,192,255]:[0,32,64,96,128,160,192,224,255]).map(k=><text key={k} x={L+k*width} y={H-6} textAnchor="middle">{hex(k)}</text>)}
    {best>=0&&<text x={Math.max(L+25,L+best*width)} y={14} fill="#b3edd2" textAnchor="middle">{`0x${hex(best)}`}</text>}
  </svg><div className="chart-meta"><span>MAX |r|</span><span>{hover===null?'KEY GUESS · HEX':`0x${hex(hover)} → ${scores[hover].toFixed(6)}`}</span></div></div>;
}
