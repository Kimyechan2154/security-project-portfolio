export type Dataset = {id:string;name:string;source:'synthetic'|'uploaded';count:number;points:number;bytes:number;created:string;fingerprint:string;known_key:number[]|null;format:string};
export type Mode = 'single'|'all'|'convergence';
export type Config = {dataset_id:string;mode:Mode;target:number;count:number;start:number;end:number;steps?:number[]};
export type Result = {target:number;count:number;start:number;end:number;valid:boolean;key:number;peak:number;second:number;ratio:number;point:number;elapsed:number;scores:number[];peak_points:number[];curve:number[];correct:boolean|null;true_key_rank:number|null};
export type Job = {id:string;created:string;status:'queued'|'running'|'completed'|'cancelled'|'failed';progress:number;config:Config;dataset_name:string;source:string;fingerprint:string;known_key:number[]|null;results:Result[];error:string|null;elapsed:number;result_count?:number};
export type Preview = {series:{x:number;first:number;mean:number}[];averaged:number;downsampled:boolean};
export const hex = (n:number) => n<0?'—':n.toString(16).padStart(2,'0').toUpperCase();
export const num = (n:number) => n.toLocaleString('en-US');
export const modeName:Record<Mode,string> = {single:'단일 바이트',all:'전체 키 복구',convergence:'Trace 수 비교'};
export const stateName = {queued:'대기 중',running:'분석 중',completed:'완료',cancelled:'취소됨',failed:'실패'};
export async function api<T>(path:string, options?:RequestInit):Promise<T> {
  const res = await fetch('/api'+path,options);
  if(!res.ok){let message='요청을 처리하지 못했습니다.';try{const b=await res.json();message=typeof b.detail==='string'?b.detail:JSON.stringify(b.detail)}catch{}throw new Error(message)}
  return res.json();
}
