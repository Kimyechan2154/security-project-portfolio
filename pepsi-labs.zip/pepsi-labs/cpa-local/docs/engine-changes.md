# CPA 엔진 보존과 변경 범위

원본 파일은 `original/`에 바이트 단위로 복사했으며 수정하지 않았습니다.

## 보존한 로직

- AES S-box와 Hamming Weight 표 전체
- `intermediate = sbox[plaintext[trace][byte] ^ keyGuess]`
- `HW(intermediate)` 누설 모델
- trace 순서의 ΣX, ΣX², ΣY, ΣY², ΣXY 누적
- `r = abs((N*sumXY - sumX*sumY) / sqrt((N*sumX2 - sumX*sumX)*(N*sumY2 - sumY*sumY)))`
- 분모의 분산 항이 0 이하이면 해당 포인트를 건너뛰기
- 후보별 최대 피크와 1위/2위 피크의 비교 순서 및 `>` 비교
- float 곱셈 후 double 누적 (원본의 계산 정밀도 유지)

## 웹 연동을 위해 변경한 부분

- 고정 매크로를 count, points, start, end, target 런타임 설정으로 전환
- 파일별/행별 포인터 할당을 연속 메모리 배열로 전환
- C 엔진은 검증·정규화된 내부 `.f32` / `.u8` 파일을 입력받음
- 사용자 trace 헤더 건너뛰기와 평문 HEX 해석은 API 업로드 경계에서 처리
- 진단 출력은 JSON Lines 진행률/결과와 stderr 오류로 분리
- 결과에 256개 후보 점수와 후보별 피크 위치, 우승 후보 곡선 추가
- 여러 바이트와 여러 trace 수의 실행 순서는 백엔드 작업 관리자가 담당
- 각 호출은 X 통계량을 다시 계산함: 기존 전체-byte 실행에서 1회만 계산하던 부분과 성능상 차이가 있음. 계산 결과는 동일한 입력/순서로 산출.
- NaN/Inf, 잘못된 범위, 메모리 실패를 명시적으로 처리
- 유효 후보가 없으면 원본의 기본값 0x00 대신 `valid=false,key=-1`로 반환
- 원본의 `ratio>=1.2 => correct key found` 문구 제거; 알려진 정답과 대조한 결과만 correct로 표시
- 고정 `trace0.txt` 덮어쓰기를 제거하고 파형은 API 미리보기로 제공

상관계수 수식, 누설 모델, 키 탐색 방식을 최적화하거나 교체하지 않았습니다. 단, 실제 원본 측정 데이터가 없으므로 원래 장비 데이터에서의 결과 동일성은 아직 미검증입니다.

## 테스트 근거

테스트는 원본에서 추출한 테이블과 새 테이블 전체를 비교합니다. S-box는 GF(2^8) 역원·affine transform으로 독립 생성한 값과도 비교합니다. NumPy로 원래 float 곱셈과 double 누적을 재현한 256개 후보 점수 및 우승 곡선을 C 출력과 `1e-11` 허용 오차로 비교합니다. ROI 시작점이 0이 아닌 경우도 포함합니다.
