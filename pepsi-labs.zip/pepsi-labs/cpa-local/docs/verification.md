# 검증 기록 — 2026-09-09

## 자동 검증

`python -m pytest tests -q` — 8 passed.

1. 원본/추출 S-box 및 HW 테이블 일치, AES 정의로 S-box 독립 검증
2. 기존 Pearson 수식과 256개 점수/곡선 일치, nonzero ROI 피크 위치
3. 합성 예제 16바이트 정답 복구, JSON/CSV 전체 결과 내보내기
4. 50/100/400개 trace 수별 실제 C 계산
5. Trace/평문 다운로드 후 재업로드, 동일 데이터 지문; 크기/HEX/NaN/정답 키 형식 오류 거부
6. 잘못된 count/ROI/byte/수렴 단계, 외부 Origin, 존재하지 않는 기록 처리
7. 분산 0 입력에서 가짜 0x00 정답을 반환하지 않음
8. 실행 중/대기 중 작업 취소와 후속 작업의 정상 실행

테스트 라이브러리 Starlette에서 httpx 및 anyio API 사용에 관한 deprecation warning 2개가 나타났으나 기능 검증은 모두 통과했습니다.

## 실제 로컬 실행

- Visual Studio 2022 / MSVC x64 Release 빌드 성공
- React TypeScript 타입 검사 및 Vite production build 성공
- C 엔진으로 합성 데이터 1,000 traces × 384 points × 16 bytes 분석: 16/16 일치
- 해당 로컬 작업의 총 실행 시간 약 7.063초
- 서버 재시작 후 기존 SQLite 기록을 다시 읽어 화면에 표시

실측 데이터 원본은 제공되지 않아 실측 데이터의 키 복구 및 기존 과제 결과와의 일치 여부는 확인하지 못했습니다.

## 브라우저 검증 — 2026-09-10

- 최신 로컬 번들 폰트를 포함한 production build 완료
- 실제 파일 선택 창으로 trace/plaintext 업로드, 헤더 0 / 384 points 검증 통과
- 업로드 데이터의 단일 바이트 CPA 실행 및 정답 미지정 시 "추정값" 표시 확인
- Trace 수 비교 화면과 수렴 그래프 확인
- 기록에서 기존 전체 키 복구 결과를 다시 열고 BYTE 01로 전환, 정답 일치 표시 확인
- 결과 JSON 링크를 눌러 브라우저 다운로드 시작 확인
- 390px 화면 검수: 숫자 겹침 수정, 가로 넘침 없음, 차트 축 글자 크기 조정
- 브라우저 JavaScript 오류 로그 없음
