from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import re
import sqlite3
import subprocess
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from typing import Literal

ROOT = Path(__file__).resolve().parents[1]
DATA = Path(os.environ.get('SCA_DATA_DIR', ROOT / 'runtime-data')).resolve()
DB = DATA / 'lab.sqlite3'
ENGINE = ROOT / 'cpa-core' / 'build' / ('Release/cpa_cli.exe' if os.name == 'nt' else 'cpa_cli')
MAX_BYTES = 256 * 1024 * 1024
LOCK = threading.RLock()
POOL = ThreadPoolExecutor(max_workers=1, thread_name_prefix='cpa')
CANCEL: dict[str, threading.Event] = {}
PROCESSES: dict[str, subprocess.Popen] = {}


def now():
    return datetime.now(timezone.utc).isoformat()


def connect():
    db = sqlite3.connect(DB, timeout=20)
    db.execute('PRAGMA journal_mode=WAL')
    return db


def save(table, record):
    assert table in ('datasets', 'jobs')
    with LOCK, connect() as db:
        db.execute(f'INSERT OR REPLACE INTO {table} VALUES (?,?)',
                   (record['id'], json.dumps(record, ensure_ascii=False, allow_nan=False)))


def get(table, ident):
    assert table in ('datasets', 'jobs')
    with connect() as db:
        row = db.execute(f'SELECT payload FROM {table} WHERE id=?', (ident,)).fetchone()
    if not row:
        raise HTTPException(404, '항목을 찾을 수 없습니다.')
    return json.loads(row[0])


def records(table):
    assert table in ('datasets', 'jobs')
    with connect() as db:
        rows = db.execute(f'SELECT payload FROM {table} ORDER BY rowid DESC').fetchall()
    return sorted((json.loads(r[0]) for r in rows), key=lambda r: r['created'], reverse=True)


def setup():
    DATA.mkdir(parents=True, exist_ok=True)
    with connect() as db:
        for table in ('datasets', 'jobs'):
            db.execute(f'CREATE TABLE IF NOT EXISTS {table} (id TEXT PRIMARY KEY, payload TEXT NOT NULL)')
    for job in records('jobs'):
        if job['status'] in ('queued', 'running'):
            job.update(status='failed', error='서버 재시작으로 분석이 중단됐습니다. 다시 실행해 주세요.')
            save('jobs', job)


@asynccontextmanager
async def lifespan(app):
    setup()
    yield
    with LOCK:
        for event in CANCEL.values():
            event.set()
        for proc in PROCESSES.values():
            if proc.poll() is None:
                proc.kill()


app = FastAPI(title='PEPSI Side-Channel Lab', version='1.0.0', lifespan=lifespan)


@app.middleware('http')
async def local_limits(request: Request, call_next):
    origin = request.headers.get('origin')
    if request.method not in ('GET', 'HEAD', 'OPTIONS') and origin:
        if origin not in ('http://127.0.0.1:8765', 'http://localhost:8765',
                          'http://127.0.0.1:5173', 'http://localhost:5173'):
            return JSONResponse({'detail': '로컬 앱에서 요청해 주세요.'}, status_code=403)
    try:
        if int(request.headers.get('content-length', 0)) > MAX_BYTES + 4*1024*1024:
            return JSONResponse({'detail': '파일 크기는 최대 256 MiB입니다.'}, status_code=413)
    except ValueError:
        return JSONResponse({'detail': '잘못된 요청 크기입니다.'}, status_code=400)
    response = await call_next(request)
    response.headers['X-Content-Type-Options'] = 'nosniff'
    return response


def store_dataset(traces, plaintext, name, source, known_key=None, ident=None):
    ident = ident or uuid.uuid4().hex
    folder = DATA / ident
    folder.mkdir(exist_ok=True)
    traces = np.ascontiguousarray(traces, dtype='<f4')
    plaintext = np.ascontiguousarray(plaintext, dtype=np.uint8)
    traces.tofile(folder / 'traces.f32')
    plaintext.tofile(folder / 'plaintext.u8')
    digest = hashlib.sha256(traces.tobytes() + plaintext.tobytes()).hexdigest()
    ds = {'id': ident, 'name': name[:120], 'source': source, 'count': len(traces),
          'points': traces.shape[1], 'bytes': traces.nbytes, 'created': now(),
          'fingerprint': digest, 'known_key': known_key, 'format': 'float32 · little-endian'}
    save('datasets', ds)
    return ds


@app.get('/api/health')
def health():
    return {'ok': True, 'engine': ENGINE.exists(), 'version': '1.0.0', 'local': True}


@app.get('/api/datasets')
def datasets():
    return records('datasets')


@app.post('/api/datasets/demo')
def demo():
    with LOCK:
        try:
            return get('datasets', 'demo-v1')
        except HTTPException:
            pass
        text = (ROOT / 'cpa-core/include/aes_tables.h').read_text(encoding='utf-8')
        box = np.array([int(h, 16) for h in re.findall(r'0x[0-9a-fA-F]{2}', text)], dtype=np.uint8)
        hw = np.array([n.bit_count() for n in range(256)], dtype=np.float32)
        rng = np.random.default_rng(20260909)
        pt = rng.integers(0, 256, (2000, 16), dtype=np.uint8)
        key = np.frombuffer(bytes.fromhex('2B7E151628AED2A6ABF7158809CF4F3C'), dtype=np.uint8)
        x = np.arange(384)
        traces = rng.normal(0, 2.2, (2000, 384))
        traces += 0.7*np.sin(x / 8) + 0.3*np.cos(x / 2.7)
        for b in range(16):
            leak = hw[box[pt[:, b] ^ key[b]]] - 4
            pulse = np.exp(-((x - (24 + b*21))/1.6)**2)
            traces += 1.0 * leak[:, None] * pulse
        return store_dataset(traces, pt, 'AES-128 · Reference traces', 'synthetic',
                             key.tolist(), 'demo-v1')


@app.post('/api/datasets/upload')
def upload(trace: UploadFile = File(...), plaintext: UploadFile = File(...),
           points: int = Form(1696, ge=1, le=200000),
           header_bytes: int = Form(32, ge=0, le=4096),
           name: str = Form(''), known_key: str = Form('')):
    raw = trace.file.read(MAX_BYTES + 1)
    plain_raw = plaintext.file.read(4*1024*1024 + 1)
    if len(raw) > MAX_BYTES or len(plain_raw) > 4*1024*1024:
        raise HTTPException(413, 'Trace는 256 MiB, 평문은 4 MiB까지 지원합니다.')
    payload = len(raw) - header_bytes
    if payload <= 0 or payload % (points*4):
        raise HTTPException(422, 'Trace 파일 크기와 헤더·포인트 설정이 맞지 않습니다.')
    count = payload // (points*4)
    if not 2 <= count <= 100000:
        raise HTTPException(422, 'Trace 수는 2~100,000개여야 합니다.')
    try:
        txt = plain_raw.decode('utf-8-sig')
        compact = re.sub(r'\s+', '', txt)
        if not re.fullmatch(r'[0-9a-fA-F]+', compact) or len(compact) != count*32:
            raise ValueError()
        pt = np.frombuffer(bytes.fromhex(compact), dtype=np.uint8).reshape(count, 16)
    except (UnicodeError, ValueError):
        raise HTTPException(422, f'평문은 trace와 같은 순서의 {count:,}개 AES 블록(16바이트 HEX)이어야 합니다.')
    data = np.frombuffer(raw, dtype='<f4', offset=header_bytes).reshape(count, points)
    if not np.isfinite(data).all() or np.abs(data).max() > 1e15:
        raise HTTPException(422, 'Trace 값이 유효하지 않습니다. float32 LE 포맷과 헤더를 확인해 주세요.')
    key = None
    if known_key.strip():
        k = re.sub(r'\s+', '', known_key)
        if not re.fullmatch(r'[0-9a-fA-F]{32}', k):
            raise HTTPException(422, '검증용 키는 32자리 HEX여야 합니다.')
        key = list(bytes.fromhex(k))
    return store_dataset(data, pt, name.strip() or trace.filename or 'Uploaded traces', 'uploaded', key)


@app.get('/api/datasets/{ident}/preview')
def preview(ident: str):
    ds = get('datasets', ident)
    traces = np.memmap(DATA / ds['id'] / 'traces.f32', dtype='<f4', mode='r', shape=(ds['count'], ds['points']))
    # Bucket extrema retain narrow spikes when the display is downsampled.
    width = max(1, int(np.ceil(ds['points'] / 1200)))
    mean = np.asarray(traces[:min(100, ds['count'])]).mean(axis=0)
    series = []
    for i in range(0, ds['points'], width):
        chunk = traces[0, i:i+width]
        for offset in sorted(set([int(chunk.argmin()), int(chunk.argmax())])):
            p = i + offset
            series.append({'x': p, 'first': float(traces[0, p]), 'mean': float(mean[p])})
    return {'series': series, 'averaged': min(100, ds['count']), 'downsampled': width > 1}


class Analysis(BaseModel):
    dataset_id: str
    mode: Literal['single', 'all', 'convergence'] = 'single'
    target: int = Field(0, ge=0, le=15)
    count: int = Field(1000, ge=2, le=100000)
    start: int = Field(0, ge=0)
    end: int = Field(384, ge=1)
    steps: list[int] = Field(default_factory=list, max_length=8)


@app.post('/api/analyses', status_code=202)
def analyze(config: Analysis):
    ds = get('datasets', config.dataset_id)
    if config.count > ds['count'] or not 0 <= config.start < config.end <= ds['points']:
        raise HTTPException(422, 'Trace 수 또는 분석 구간이 데이터 범위를 벗어났습니다.')
    if not ENGINE.exists():
        raise HTTPException(503, 'C 엔진 빌드가 필요합니다. README를 확인해 주세요.')
    if config.mode == 'convergence':
        config.steps = sorted(set(config.steps or [min(x, config.count) for x in (50,100,250,500,1000,config.count)]))
        if any(s < 2 or s > config.count for s in config.steps):
            raise HTTPException(422, '비교할 trace 수는 2 이상, 선택한 trace 수 이하여야 합니다.')
    with LOCK:
        if sum(j['status'] in ('queued', 'running') for j in records('jobs')) >= 4:
            raise HTTPException(429, '대기 중인 분석이 많습니다. 완료 후 다시 실행해 주세요.')
        ident = uuid.uuid4().hex
        job = {'id': ident, 'created': now(), 'status': 'queued', 'progress': 0,
               'config': config.model_dump(), 'dataset_name': ds['name'], 'source': ds['source'],
               'fingerprint': ds['fingerprint'], 'known_key': ds['known_key'],
               'results': [], 'error': None, 'elapsed': 0, 'engine_version': 'pepsi-cpa-1.0'}
        save('jobs', job)
        CANCEL[ident] = threading.Event()
        POOL.submit(run_job, job, ds, CANCEL[ident])
    return job


def run_job(job, ds, cancel):
    ident = job['id']
    start_time = time.monotonic()
    try:
        if cancel.is_set():
            job['status'] = 'cancelled'
            return
        job.update(status='running', started=now())
        save('jobs', job)
        c = job['config']
        tasks = ([(c['count'], b) for b in range(16)] if c['mode'] == 'all' else
                 [(n, c['target']) for n in c['steps']] if c['mode'] == 'convergence' else
                 [(c['count'], c['target'])])
        folder = DATA / ds['id']
        for index, (count, target) in enumerate(tasks):
            if cancel.is_set():
                break
            command = [str(ENGINE), str(folder / 'traces.f32'), str(folder / 'plaintext.u8'),
                       str(count), str(ds['points']), str(c['start']), str(c['end']), str(target)]
            proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                    text=True, encoding='utf-8', shell=False,
                                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
            with LOCK:
                PROCESSES[ident] = proc
                if cancel.is_set() and proc.poll() is None:
                    proc.kill()
            timeout = threading.Timer(1200, lambda p=proc: p.kill() if p.poll() is None else None)
            timeout.start()
            result = None
            try:
                for line in proc.stdout:
                    if cancel.is_set():
                        break
                    message = json.loads(line)
                    if message['type'] == 'progress':
                        job['progress'] = round(100 * (index + message['completed']/256) / len(tasks), 1)
                        job['elapsed'] = round(time.monotonic()-start_time, 2)
                        save('jobs', job)
                    else:
                        result = message
                if cancel.is_set() and proc.poll() is None:
                    proc.kill()
                code = proc.wait()
                if cancel.is_set():
                    break
                if code or result is None:
                    raise RuntimeError('C 엔진 계산이 중단됐습니다. 입력 데이터 또는 실행 시간 제한을 확인해 주세요.')
            finally:
                timeout.cancel()
                if proc.poll() is None:
                    proc.kill()
                proc.wait()
                proc.stdout.close()
                proc.stderr.close()
                with LOCK:
                    PROCESSES.pop(ident, None)
            known = ds['known_key']
            result['correct'] = (result['key'] == known[target]) if known and result['valid'] else None
            result['true_key_rank'] = (1 + sum(s > result['scores'][known[target]] for s in result['scores'])) if known else None
            job['results'].append(result)
            save('jobs', job)
        job['status'] = 'cancelled' if cancel.is_set() else 'completed'
        if job['status'] == 'completed':
            job['progress'] = 100
    except Exception as exc:
        job.update(status='cancelled' if cancel.is_set() else 'failed', error=str(exc))
    finally:
        job['elapsed'] = round(time.monotonic() - start_time, 3)
        job['finished'] = now()
        save('jobs', job)
        with LOCK:
            CANCEL.pop(ident, None)


@app.get('/api/analyses')
def analyses():
    return [{k: v for k, v in job.items() if k != 'results'} |
            {'result_count': len(job['results'])} for job in records('jobs')]


@app.get('/api/analyses/{ident}')
def analysis(ident: str):
    return get('jobs', ident)


@app.post('/api/analyses/{ident}/cancel')
def cancel_analysis(ident: str):
    with LOCK:
        job = get('jobs', ident)
        if job['status'] not in ('queued', 'running'):
            return job
        event = CANCEL.get(ident)
        if event:
            event.set()
        proc = PROCESSES.get(ident)
        if proc and proc.poll() is None:
            proc.kill()
    return {'id': ident, 'cancellation_requested': True}


@app.get('/api/analyses/{ident}/export')
def export(ident: str, format: Literal['json', 'csv'] = 'json'):
    job = get('jobs', ident)
    if format == 'json':
        content = json.dumps(job, ensure_ascii=False, indent=2, allow_nan=False)
        media = 'application/json'
    else:
        out = io.StringIO(newline='')
        writer = csv.writer(out)
        writer.writerow(['byte','trace_count','key_guess','peak','peak_point','is_best','known_key_rank','roi_start','roi_end'])
        for r in job['results']:
            for k, score in enumerate(r['scores']):
                writer.writerow([r['target'], r['count'], f'{k:02X}', score, r['peak_points'][k],
                                 r['valid'] and k==r['key'], r['true_key_rank'], r['start'], r['end']])
        content, media = '\ufeff' + out.getvalue(), 'text/csv'
    return Response(content, media_type=media, headers={
        'Content-Disposition': f'attachment; filename="pepsi-analysis-{ident[:8]}.{format}"'})


@app.get('/api/datasets/{ident}/download/{kind}')
def download_dataset(ident: str, kind: Literal['trace','plaintext']):
    ds = get('datasets', ident)
    if kind == 'trace':
        # Download uses a zero-byte header, explicitly named to avoid ambiguity.
        return FileResponse(DATA / ds['id'] / 'traces.f32', filename=f'pepsi-{ds["points"]}points-header0.trace')
    pt = np.fromfile(DATA / ds['id'] / 'plaintext.u8', dtype=np.uint8).reshape(-1,16)
    content = '\n'.join(' '.join(f'{int(b):02X}' for b in row) for row in pt)
    return Response(content, media_type='text/plain', headers={'Content-Disposition':'attachment; filename="plaintext.txt"'})


DIST = ROOT / 'frontend/dist'
if DIST.exists():
    app.mount('/', StaticFiles(directory=DIST, html=True), name='frontend')
