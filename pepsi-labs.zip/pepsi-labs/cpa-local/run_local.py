"""Local launcher. Double-click start.cmd on Windows after setup."""
import json
import os
import threading
import urllib.request
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
URL = 'http://127.0.0.1:8765'

if __name__ == '__main__':
    os.chdir(ROOT)
    try:
        with urllib.request.urlopen(URL + '/api/health', timeout=2) as response:
            health = json.load(response)
        if health.get('engine') and health.get('version') == '1.0.0':
            webbrowser.open(URL)
            raise SystemExit(0)
    except (OSError, ValueError):
        pass
    if not (ROOT / 'frontend/dist/index.html').exists():
        raise SystemExit('Build the frontend first. See README.md.')
    import uvicorn
    timer = threading.Timer(1.5, lambda: webbrowser.open(URL))
    timer.daemon = True
    timer.start()
    uvicorn.run('backend.app:app', host='127.0.0.1', port=8765, log_level='warning')
