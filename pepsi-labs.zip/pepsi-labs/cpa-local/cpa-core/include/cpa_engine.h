#ifndef CPA_ENGINE_H
#define CPA_ENGINE_H
#include <stdint.h>
typedef struct {
    int count, points, start, end, target;
} CpaConfig;
typedef struct {
    int key, point, valid;
    double peak, second, ratio;
    double scores[256];
    int peak_points[256];
    double *curve;
} CpaResult;
typedef void (*CpaProgress)(int completed, void *context);
int cpa_analyze(const float *traces, const uint8_t *plaintext,
                const CpaConfig *config, CpaResult *result,
                CpaProgress progress, void *context);
void cpa_result_free(CpaResult *result);
#endif
