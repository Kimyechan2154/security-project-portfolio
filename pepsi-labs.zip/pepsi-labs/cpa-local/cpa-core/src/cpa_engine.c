/* Extraction of the user's CPA loop. See docs/engine-changes.md. */
#include "cpa_engine.h"
#include "aes_tables.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>

void cpa_result_free(CpaResult *r) { free(r->curve); r->curve = NULL; }

int cpa_analyze(const float *traces, const uint8_t *pt, const CpaConfig *c,
                CpaResult *out, CpaProgress progress, void *ctx) {
    if (!out) return 1;
    memset(out, 0, sizeof(*out));
    out->key = out->point = -1;
    if (!traces || !pt || !c || c->count < 2 || c->points < 1 ||
        c->start < 0 || c->end > c->points || c->start >= c->end ||
        c->target < 0 || c->target > 15) return 1;
    const int width = c->end - c->start;
    double *sumX = calloc(width, sizeof(double));
    double *sumX2 = calloc(width, sizeof(double));
    double *sumXY = calloc(width, sizeof(double));
    double *curve = calloc(width, sizeof(double));
    out->curve = calloc(width, sizeof(double));
    int status = 0;
    if (!sumX || !sumX2 || !sumXY || !curve || !out->curve) { status = 2; goto cleanup; }
    for (int i = 0; i < c->count; i++) {
        for (int p = 0; p < width; p++) {
            float x = traces[(size_t)i * c->points + c->start + p];
            if (!isfinite(x)) { status = 3; goto cleanup; }
            sumX[p] += x;
            /* Preserve the original float product before double accumulation. */
            sumX2[p] += x * x;
        }
    }
    for (int k = 0; k < 256; k++) {
        double sumY = 0, sumY2 = 0, peak = 0;
        int point = -1;
        memset(sumXY, 0, width * sizeof(double));
        memset(curve, 0, width * sizeof(double));
        for (int i = 0; i < c->count; i++) {
            uint8_t intermediate = sbox[pt[(size_t)i * 16 + c->target] ^ k];
            int hw = hw_table[intermediate];
            sumY += hw;
            sumY2 += hw * hw;
            for (int p = 0; p < width; p++)
                sumXY[p] += traces[(size_t)i * c->points + c->start + p] * hw;
        }
        for (int p = 0; p < width; p++) {
            double dx = c->count * sumX2[p] - sumX[p] * sumX[p];
            double dy = c->count * sumY2 - sumY * sumY;
            if (dx <= 0 || dy <= 0) continue;
            double r = fabs((c->count * sumXY[p] - sumX[p] * sumY) / sqrt(dx * dy));
            if (!isfinite(r)) continue;
            curve[p] = r;
            if (r > peak) { peak = r; point = c->start + p; }
        }
        out->scores[k] = peak;
        out->peak_points[k] = point;
        if (peak > out->peak) {
            out->second = out->peak;
            out->peak = peak;
            out->key = k;
            out->point = point;
            memcpy(out->curve, curve, width * sizeof(double));
        } else if (peak > out->second) out->second = peak;
        if (progress && (k + 1) % 16 == 0) progress(k + 1, ctx);
    }
    out->ratio = out->second > 0 ? out->peak / out->second : 0;
    out->valid = out->key >= 0;
cleanup:
    free(sumX); free(sumX2); free(sumXY); free(curve);
    if (status) cpa_result_free(out);
    return status;
}
