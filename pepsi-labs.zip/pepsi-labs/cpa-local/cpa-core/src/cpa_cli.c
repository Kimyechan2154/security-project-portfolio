#define _CRT_SECURE_NO_WARNINGS
#include "cpa_engine.h"
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <limits.h>
#include <time.h>

static int number(const char *s, int *out) {
    char *tail; errno = 0; long v = strtol(s, &tail, 10);
    if (errno || *tail || tail == s || v < 0 || v > INT_MAX) return 1;
    *out = (int)v; return 0;
}
static void progress(int done, void *ctx) {
    (void)ctx;
    printf("{\"type\":\"progress\",\"completed\":%d}\n", done); fflush(stdout);
}
int main(int argc, char **argv) {
    int error = 1; FILE *tf = NULL, *pf = NULL;
    float *traces = NULL; uint8_t *plaintext = NULL;
    CpaResult r = {0}; CpaConfig c;
    if (argc != 8) {
        fprintf(stderr, "Usage: cpa_cli traces.f32 plaintext.u8 count points start end byte\n");
        return 1;
    }
    if (number(argv[3], &c.count) || number(argv[4], &c.points) ||
        number(argv[5], &c.start) || number(argv[6], &c.end) || number(argv[7], &c.target) ||
        c.count < 2 || c.count > 100000 || c.points < 1 || c.points > 200000 ||
        c.start >= c.end || c.end > c.points || c.target > 15 ||
        (size_t)c.count * c.points > 67108864) goto cleanup;
    tf = fopen(argv[1], "rb"); pf = fopen(argv[2], "rb");
    if (!tf || !pf) { error = 2; goto cleanup; }
    traces = malloc((size_t)c.count * c.points * sizeof(float));
    plaintext = malloc((size_t)c.count * 16);
    if (!traces || !plaintext) { error = 3; goto cleanup; }
    if (fread(traces, sizeof(float), (size_t)c.count*c.points, tf) != (size_t)c.count*c.points ||
        fread(plaintext, 1, (size_t)c.count*16, pf) != (size_t)c.count*16) { error = 4; goto cleanup; }
    clock_t before = clock();
    error = cpa_analyze(traces, plaintext, &c, &r, progress, NULL);
    if (error) goto cleanup;
    printf("{\"type\":\"result\",\"target\":%d,\"count\":%d,\"start\":%d,\"end\":%d,\"valid\":%s,",
        c.target, c.count, c.start, c.end, r.valid ? "true" : "false");
    printf("\"key\":%d,\"peak\":%.17g,\"second\":%.17g,\"ratio\":%.17g,\"point\":%d,\"elapsed\":%.6f,\"scores\":[",
        r.key, r.peak, r.second, r.ratio, r.point, (double)(clock()-before)/CLOCKS_PER_SEC);
    for(int k=0;k<256;k++) printf("%s%.17g", k?",":"", r.scores[k]);
    printf("],\"peak_points\":[");
    for(int k=0;k<256;k++) printf("%s%d", k?",":"", r.peak_points[k]);
    printf("],\"curve\":[");
    for(int p=0;p<c.end-c.start;p++) printf("%s%.17g", p?",":"", r.curve[p]);
    printf("]}\n");
cleanup:
    if(tf) fclose(tf); if(pf) fclose(pf);
    free(traces); free(plaintext); cpa_result_free(&r);
    if(error) fprintf(stderr, "CPA input or calculation error (%d)\n", error);
    return error;
}
