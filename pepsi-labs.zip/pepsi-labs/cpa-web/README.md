# CPA 분석 도구 — 김예찬의 개인 프로젝트

Read-only showcase of precomputed synthetic AES-128 CPA results from the author's existing C engine. This is a personal project, not a laboratory-affiliated website. No user uploads, private analysis history, credentials, or executable backend are included. The public site does not run new CPA computations.

Authored static files are in `dist`. Serve that directory with any static HTTP server. No build is required.

## Light redesign

The existing demo is restyled in white with black typography and a restrained orange chart accent. All four charts, 16-byte selection and recovery, five convergence conditions, leakage model, guide, and reliability notices remain. `demo-data.json` is unchanged.

Copy editing follows the meaning-preserving principles described at https://github.com/epoko77-ai/im-not-ai: remove unnecessary English slogans and vague promotional language while preserving technical terms, numerical results, and caveats. The repository was read as reference only; no external skill or installer was installed or executed.

UI checks: `node work/verify-full-light.mjs` from the surrounding workspace validates static references and CSS, unchanged data, rendering/state transitions with a DOM stub, all byte selections, waveform switching, comparison rows, keyboard tooltips, and retry. It is not a browser visual test.

DM Sans is bundled under the SIL Open Font License in `dist/FONT-LICENSE.txt`.
