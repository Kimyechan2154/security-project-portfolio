import asyncio
import json
import unittest
from unittest.mock import AsyncMock, patch
from cpart.bindings import LLMConfig, LLMResponse, ClassifyResult, ProblemType
from cpart.classifier import Classifier
from cpart.openai_adapter import OpenAIAdapter
from cpart.parsing import object_json
from cpart.runner import Execution, DockerRunner
from cpart.solver import Solver, ExpectedFlagVerifier, solve_with_retries
from cpart.integration import wire_workflow


class FakeLLM:
    def __init__(self, replies): self.replies, self.messages = iter(replies), []
    async def chat(self, messages):
        self.messages.append(messages)
        return LLMResponse(next(self.replies), 'offline-fixture', {})


CLASSIFY = dict(problem_type='crypto_encoding', confidence=0.9, strategy='Reverse XOR',
                key_functions=['main'], reasoning='XOR loop observed')
CODE = json.dumps({'solver_code': 'print("fixture")'})


class Tests(unittest.IsolatedAsyncioTestCase):
    async def test_classification(self):
        result = await Classifier(FakeLLM([json.dumps(CLASSIFY)])).classify({'strings': []})
        self.assertEqual(result.problem_type, ProblemType.CRYPTO_ENCODING)

    async def test_invalid_classifications(self):
        for key, value in [('problem_type', 'invented'), ('confidence', True),
                           ('confidence', 2), ('key_functions', 'main')]:
            obj = dict(CLASSIFY, **{key: value})
            with self.assertRaises(ValueError):
                await Classifier(FakeLLM([json.dumps(obj)])).classify({})

    async def test_json_rejects_ambiguous_output(self):
        for text in ['{"x":1,"x":2}', '[]', '{"x":NaN}', 'hello {"x":1}']:
            with self.assertRaises(ValueError): object_json(text)
        self.assertEqual(object_json('```json\n{"x":1}\n```'), {'x': 1})

    async def test_no_execution_by_default(self):
        result = await Solver(FakeLLM([CODE])).solve({}, ClassifyResult(), [])
        self.assertFalse(result.success)
        self.assertIn('execution disabled', result.error)
        self.assertTrue(result.solver_code)

    async def test_no_verifier_never_claims_success(self):
        runner = AsyncMock()
        runner.run.return_value = Execution('{"flag":"flag{fake}"}')
        result = await Solver(FakeLLM([CODE]), runner=runner).solve({}, ClassifyResult(), [])
        self.assertFalse(result.success)
        self.assertEqual(result.flag, '')

    async def test_retry_feedback_and_verification(self):
        runner = AsyncMock()
        runner.run.side_effect = [Execution('{"flag":"bad"}'), Execution('{"flag":"good"}')]
        llm = FakeLLM([CODE, CODE])
        solver = Solver(llm, runner=runner, verifier=ExpectedFlagVerifier('good'))
        result = await solve_with_retries(solver, {}, ClassifyResult())
        self.assertTrue(result.success)
        self.assertEqual(result.attempts, 2)
        self.assertIn('rejected', llm.messages[1][1]['content'])

    async def test_syntax_error_never_runs(self):
        runner = AsyncMock()
        result = await Solver(FakeLLM(['{"solver_code":"def bad("}']), runner=runner).solve(
            {}, ClassifyResult(), [])
        self.assertIn('SyntaxError', result.error)
        runner.run.assert_not_called()

    async def test_nonzero_exit_and_invalid_output(self):
        for execution in [Execution('', 'broken', 1), Execution('not JSON'), Execution('{"flag":""}')]:
            runner = AsyncMock()
            runner.run.return_value = execution
            result = await Solver(FakeLLM([CODE]), runner=runner,
                                  verifier=ExpectedFlagVerifier('x')).solve({}, ClassifyResult(), [])
            self.assertFalse(result.success)
            self.assertTrue(result.error)

    async def test_adapter_contract_and_stream_fallback(self):
        calls = []
        def transport(payload):
            calls.append(payload)
            return {'model':'test', 'choices':[{'finish_reason':'stop','message':{'content':'ok'}}],
                    'usage':{'prompt_tokens':12,'completion_tokens':3}}
        adapter = OpenAIAdapter(LLMConfig(), transport=transport)
        response = await adapter.chat([{'role':'user','content':'test'}])
        self.assertEqual(response.usage, {'input_tokens':12,'output_tokens':3})
        self.assertEqual([chunk async for chunk in adapter.stream([])], ['ok'])
        self.assertEqual(calls[0]['max_completion_tokens'], 4096)

    async def test_truncated_response_rejected(self):
        adapter = OpenAIAdapter(LLMConfig(), transport=lambda _: {
            'choices':[{'finish_reason':'length','message':{'content':'partial'}}]})
        with self.assertRaises(ValueError): await adapter.chat([])

    async def test_workflow_wiring(self):
        class Workflow:
            def set_llm_adapter(self, value): self.adapter = value
            def set_classifier(self, value): self.classifier = value
            def set_solvers(self, value): self.solvers = value
        workflow = Workflow()
        wire_workflow(workflow, FakeLLM([]))
        self.assertEqual(len(workflow.solvers), 3)
        self.assertNotIn(ProblemType.UNKNOWN, workflow.solvers)

    async def test_missing_docker_fails_closed(self):
        with patch('asyncio.create_subprocess_exec', side_effect=FileNotFoundError('docker')):
            with self.assertRaises(FileNotFoundError):
                await DockerRunner().run('print(1)')

    async def test_cancellation_propagates(self):
        runner = AsyncMock()
        runner.run.side_effect = asyncio.CancelledError()
        with self.assertRaises(asyncio.CancelledError):
            await Solver(FakeLLM([CODE]), runner=runner).solve({}, ClassifyResult(), [])


if __name__ == '__main__': unittest.main()
