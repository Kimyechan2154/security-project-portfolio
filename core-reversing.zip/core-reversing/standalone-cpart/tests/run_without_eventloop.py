"""Fallback harness for environments that prohibit asyncio loopback sockets.
Only runs deterministic mocked tests. Does NOT test scheduling/threads/network.
Run from project root: python tests/run_without_eventloop.py
"""
import inspect
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from test_cpart import Tests


async def inline_transport(function, *args, **kwargs):
    return function(*args, **kwargs)


def complete(coroutine):
    try:
        yielded = coroutine.send(None)
    except StopIteration as result:
        return result.value
    else:
        coroutine.close()
        raise AssertionError(f'Test unexpectedly needs real event loop: {yielded!r}')


class RestrictedTests(unittest.TestCase): pass


for name, function in inspect.getmembers(Tests, inspect.iscoroutinefunction):
    if name.startswith('test_'):
        def run(self, function=function):
            with patch('asyncio.to_thread', inline_transport):
                complete(function(self))
        setattr(RestrictedTests, name, run)

del Tests  # Do not let unittest discover the original async class here.
if __name__ == '__main__': unittest.main(verbosity=2)
