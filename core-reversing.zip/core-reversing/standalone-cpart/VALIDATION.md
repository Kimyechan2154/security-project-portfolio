# 검증 기록

- 작성 기준: 2026-11-04 확인한 인터페이스. 최신 원격 저장소 통합은 미검증.
- 제한 환경용 하네스: 13개 로직 테스트. API transport와 외부 실행기는 모의 객체 사용.
- 확인 범위: JSON 오류/중복 키/숫자 범위, 분류 규격, 코드 문법 오류, 실행 비활성화,
  검증기 누락 시 실패, 정답 오판 방지, 오류 피드백 재시도, 취소 전파, 코어 등록,
  API 결과 형식/사용량/잘린 응답, Docker 부재 시 실패.
- 일반 asyncio 테스트는 실행 환경의 socketpair/accept 단계에서 정지하여 중단.
  제한 하네스에서는 실제 이벤트 루프/스레드 스케줄링을 테스트하지 않음.
- 실제 OpenAI 호출: 미실시(API 키/비용 사용하지 않음).
- 실제 Docker 격리 실행, 타임아웃/출력 제한 실환경 동작: 미실시.
- 일반 바이너리 풀이 성능/팀 RetryController 연동: 미검증.

일반 환경: `python -m unittest discover -s tests -v`

이벤트 루프 생성이 차단된 환경: `python tests/run_without_eventloop.py`

실제 Docker 확인: 이미지 준비 후 `python demo.py --docker`

실제 LLM 확인: 키 설정 후 `python demo.py --live --docker --model gpt-4o`
