# Reversing Agent C 파트 — 독립 구현

2026-11-04에 직접 확인한 팀 저장소 인터페이스를 기준으로 작성했습니다.
최신 저장소를 내려받거나 병합한 버전이 아닙니다. 기존 파일을 덮어쓰지 않습니다.
Python 3.11 이상, 기본 기능/테스트는 외부 패키지 없이 실행합니다.

## 가장 먼저 실행

ZIP 압축을 풀고 `reversing_cpart` 폴더에서 PowerShell을 엽니다.

```powershell
python -m unittest discover -s tests -v
python demo.py
```

기본 데모는 고정 응답을 사용하는 모의 LLM입니다. 분류와 XOR 풀이 코드 생성 흐름을
확인하며, 코드를 실제로 실행하지 않으므로 success=false가 정상입니다.
생성된 코드는 출력의 solver_code에 있습니다. 모의 테스트 통과는 실제 LLM 정확도 증명이 아닙니다.

## 실제 LLM 연결

```powershell
$env:OPENAI_API_KEY = '본인_API_키'
python demo.py --live --model gpt-4o
Remove-Item Env:OPENAI_API_KEY
```

실행 시 OpenAI로 분석 데이터가 전송되며 API 사용 비용이 발생합니다. 사용 가능한
Chat Completions 지원 모델을 --model로 지정하세요. 키는 코드/깃허브에 저장하지 마세요.
이 구현은 환경변수를 읽으며 .env 파일을 자체적으로 로드하지 않습니다.
OpenAI만 구현했고 Anthropic은 포함하지 않았습니다. stream()은 실시간 스트리밍이
아닌 chat() 완료 후 한 덩어리를 반환하는 호환용 구현입니다. 모델별 차이를 줄이기
위해 temperature를 요청에서 생략합니다. API 오류는 상위 호출자에게 전달합니다.

## 선택: Docker에서 코드 실행

Docker의 Linux 컨테이너 환경이 실행 중이어야 합니다. 이미지는 사용자가 먼저 준비합니다.

```powershell
docker pull python:3.13-slim
python demo.py --docker
python demo.py --live --docker --model gpt-4o
```

실행 컨테이너에는 네트워크/호스트 폴더/API 키를 전달하지 않습니다. 읽기 전용 파일시스템,
비특권 사용자, 메모리/CPU/PID/시간/출력 제한을 적용합니다. 임의 코드를 호스트 Python으로
실행하는 우회 경로는 없습니다. 컨테이너 격리는 완전한 보안 경계를 보장하지 않으므로
실제 미확인 문제는 별도의 실습 VM에서 처리하세요. 대상 바이너리 자체는 실행하지 않습니다.

데모는 사전에 정답을 알고 있는 XOR 문제입니다. ExpectedFlagVerifier는 테스트 전용이며,
일반 문제에는 팀에서 정의한 독립 검증기가 필요합니다. 검증기가 없거나 실패하면
success=false이며, 검증되지 않은 후보를 flag 필드에 넣지 않습니다.

## 파일별 역할

| 파일 | 역할 |
|---|---|
| cpart/openai_adapter.py | API 호출, 응답/사용량 표준화, 오류 처리 |
| cpart/classifier.py | 분석 자료 → ClassifyResult |
| cpart/solver.py | 코드 생성, 실행 연결, 검증, 재시도 |
| cpart/runner.py | 선택적 Docker 실행기 |
| cpart/parsing.py | 엄격한 JSON 검사와 입력 길이 제한 |
| cpart/integration.py | 기존 Workflow에 모듈 등록 |
| cpart/contracts.py | 독립 실행용 공통 데이터 규격 |
| cpart/bindings.py | 팀 규격 사용 여부를 명시적으로 선택 |
| tests/test_cpart.py | 네트워크/API 키 없는 단위 테스트 |

## 팀 저장소에 합치는 방법

1. `cpart` 폴더만 팀 저장소 루트(src와 같은 위치)에 복사합니다.
2. 기존 `src/models/analysis_result.py`, `src/llm/adapter.py`는 덮어쓰지 않습니다.
3. 팀 모드를 **프로그램 시작 전** 설정합니다. 이 모드에서는 실제 팀 타입을 import합니다.

```powershell
$env:REVAGENT_TEAM_MODE = '1'
```

4. Agent 생성 후 analyze 전에 아래처럼 연결합니다(팀 저장소에서 실행할 코드).

```python
from src.core.agent import Agent
from src.llm.adapter import LLMConfig
from cpart.openai_adapter import OpenAIAdapter
from cpart.integration import wire_workflow

agent = Agent()
adapter = OpenAIAdapter(LLMConfig(provider='openai', model='gpt-4o'))
wire_workflow(agent.workflow, adapter)  # 기본: 코드 생성만
# B팀 분석기 등록도 필요: agent.workflow.set_analysis_tools(analysis_tools)
# 이후 await agent.analyze(binary_path)
```

DockerRunner와 팀 검증기를 wire_workflow(..., runner=..., verifier=...)에 전달하면 실행/검증을
활성화할 수 있습니다. 검증기는 `async def verify(self, candidate, analysis) -> bool`을
구현해야 합니다. 정답 여부는 LLM 판단이나 flag 모양 정규식만으로 결정하지 마세요.
기존 create_adapter 팩토리는 수정하지 않았으므로 위와 같이 직접 생성합니다.

팀 Workflow는 `await classifier.classify(filtered)`와
`await solver.solve(analysis, classify, errors_so_far)`를 호출합니다.
분류 결과는 기존 3개 유형을 지원하고 unknown은 풀이기로 등록하지 않습니다.
팀 Workflow가 재시도하므로 solve_with_retries()를 중복 적용하지 않습니다.
상위 RetryController가 success=false를 실패로 처리하는지는 실제 저장소 통합 시 확인하세요.
분류기는 형식 오류 시 예외를 반환합니다(분류 재시도는 아직 포함하지 않음).

## 범위 및 검증 한계

- 분석 자료 추출은 B팀 영역입니다. 분석기가 없어도 샘플 자료로 C 파트를 개발할 수 있습니다.
- 입력은 글자 수로 제한하며 정확한 토큰 수 계산은 아닙니다.
- 일반 바이너리 자동 검증, Ghidra 연동, 모든 CTF 문제 해결은 구현 범위가 아닙니다.
- 실제 API 호출과 Docker 실환경 테스트 여부는 VALIDATION.md를 확인하세요.
- API 문서: https://developers.openai.com/api/reference/resources/chat
