"""Offline simulation by default. --docker executes a fixed XOR fixture."""
import argparse
import asyncio
import json
from dataclasses import asdict
from cpart.bindings import LLMConfig, LLMResponse
from cpart.classifier import Classifier
from cpart.openai_adapter import OpenAIAdapter
from cpart.runner import DockerRunner
from cpart.solver import Solver, ExpectedFlagVerifier, solve_with_retries

EXPECTED = 'flag{xor_demo}'
DATA = [ord(c) ^ 42 for c in EXPECTED]


class FixtureAdapter:
    """Canned responses, not a real LLM and not a solver accuracy benchmark."""
    def __init__(self): self.calls = 0
    async def chat(self, messages):
        self.calls += 1
        if self.calls == 1:
            obj = dict(problem_type='crypto_encoding', confidence=1.0,
                       strategy='XOR every byte with 42', key_functions=['main'],
                       reasoning='Known demo fixture')
        else:
            obj = {'solver_code': 'import json\ndata = ' + repr(DATA) +
                   '\nprint(json.dumps({"flag": "".join(chr(x ^ 42) for x in data)}))'}
        return LLMResponse(json.dumps(obj), 'offline-fixture', {})


async def main(args):
    adapter = OpenAIAdapter(LLMConfig(model=args.model)) if args.live else FixtureAdapter()
    analysis = {'strings': [], 'disassembly': {
        'main': f'for i: input[i] XOR 42 must equal target[i]; target={DATA}'}}
    classified = await Classifier(adapter).classify(analysis)
    solver = Solver(adapter, runner=DockerRunner() if args.docker else None,
                    verifier=ExpectedFlagVerifier(EXPECTED))
    result = await solve_with_retries(solver, analysis, classified)
    print(json.dumps({'mode':'live API' if args.live else 'offline canned responses',
                      'classification': asdict(classified), 'solve': asdict(result)}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--live', action='store_true', help='Call paid API using OPENAI_API_KEY')
    parser.add_argument('--docker', action='store_true', help='Execute generated Python in Docker')
    parser.add_argument('--model', default='gpt-4o')
    asyncio.run(main(parser.parse_args()))
