import asyncio
import json
import os
import urllib.error
import urllib.request

from .bindings import LLMAdapter, LLMResponse


class OpenAIAdapter(LLMAdapter):
    """Chat Completions; HTTP timeout and bounded responses, no secret logging."""
    def __init__(self, config, *, api_key=None, timeout=45, transport=None):
        super().__init__(config)
        if config.provider != 'openai':
            raise ValueError('This adapter supports only openai')
        if not config.model or config.max_tokens <= 0 or timeout <= 0:
            raise ValueError('Invalid model, max_tokens or timeout')
        self.key = api_key or os.getenv('OPENAI_API_KEY')
        self.timeout = timeout
        self.transport = transport or self._post
        if not self.key and transport is None:
            raise ValueError('Set OPENAI_API_KEY in the environment')

    def _post(self, payload):
        req = urllib.request.Request(
            'https://api.openai.com/v1/chat/completions',
            data=json.dumps(payload).encode(),
            headers={'Authorization': 'Bearer ' + self.key,
                     'Content-Type': 'application/json'}, method='POST')
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                data = response.read(2_000_001)
        except urllib.error.HTTPError as exc:
            raise RuntimeError(f'OpenAI HTTP {exc.code}; check key, quota and model') from None
        except (urllib.error.URLError, TimeoutError):
            raise RuntimeError('OpenAI connection failed or timed out') from None
        if len(data) > 2_000_000:
            raise ValueError('API response exceeds limit')
        return json.loads(data)

    async def chat(self, messages):
        # Omit temperature: some model families do not support it.
        payload = dict(model=self.config.model, messages=messages,
                       max_completion_tokens=self.config.max_tokens)
        data = await asyncio.to_thread(self.transport, payload)
        try:
            choice = data['choices'][0]
            content = choice['message']['content']
            if choice.get('finish_reason') != 'stop':
                raise ValueError('Incomplete or refused LLM response')
            if not isinstance(content, str) or not content.strip():
                raise ValueError('Empty LLM response')
            usage = data.get('usage', {})
            return LLMResponse(content=content, model=data.get('model', self.config.model),
                               usage={'input_tokens': usage.get('prompt_tokens', 0),
                                      'output_tokens': usage.get('completion_tokens', 0)})
        except (KeyError, IndexError, TypeError):
            raise ValueError('Malformed API response') from None

    async def stream(self, messages):
        """MVP fallback: one chunk after chat completes, not live streaming."""
        yield (await self.chat(messages)).content
