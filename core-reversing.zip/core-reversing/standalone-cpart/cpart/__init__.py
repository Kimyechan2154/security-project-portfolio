"""C-part implementation; standalone contracts are replaced on integration."""
