import json
import math
from dataclasses import asdict, is_dataclass
from enum import Enum


def object_json(text):
    text = text.strip()
    if text.startswith('```'):
        lines = text.splitlines()
        if lines[0] not in ('```', '```json') or lines[-1] != '```':
            raise ValueError('Invalid JSON fence')
        text = '\n'.join(lines[1:-1])
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('Duplicate JSON key: ' + key)
            result[key] = value
        return result
    obj = json.loads(text, object_pairs_hook=unique,
                     parse_constant=lambda _: (_ for _ in ()).throw(ValueError('Nonfinite number')))
    if not isinstance(obj, dict):
        raise ValueError('Expected a JSON object')
    return obj


def text_field(obj, key, limit=12000):
    value = obj.get(key)
    if not isinstance(value, str) or len(value) > limit:
        raise ValueError('Invalid field: ' + key)
    return value


def confidence(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError('confidence must be numeric')
    if not math.isfinite(value) or not 0 <= value <= 1:
        raise ValueError('confidence must be in [0,1]')
    return float(value)


def context_json(value, limit=24000):
    def convert(obj):
        if is_dataclass(obj): return asdict(obj)
        if isinstance(obj, Enum): return obj.value
        raise TypeError('Context must be dict or dataclass')
    # A hard cap bounds input size, not an exact tokenizer count.
    text = json.dumps(value, default=convert, ensure_ascii=False)
    return text if len(text) <= limit else text[:limit] + '\n[CONTEXT TRUNCATED]'
