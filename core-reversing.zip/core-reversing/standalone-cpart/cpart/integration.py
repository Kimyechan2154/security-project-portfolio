from .bindings import ProblemType
from .classifier import Classifier
from .solver import Solver


def wire_workflow(workflow, adapter, *, runner=None, verifier=None):
    """Call before Agent.analyze(); analysis tools remain B team's dependency."""
    workflow.set_llm_adapter(adapter)
    workflow.set_classifier(Classifier(adapter))
    workflow.set_solvers({kind: Solver(adapter, runner=runner, verifier=verifier)
                          for kind in ProblemType if kind != ProblemType.UNKNOWN})
