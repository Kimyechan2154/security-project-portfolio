"""Execute only generated solver Python in an explicitly enabled Docker container.
No target binary is executed and no host directories or secrets are mounted.
"""
import asyncio
import uuid
from dataclasses import dataclass


@dataclass
class Execution:
    stdout: str = ''
    stderr: str = ''
    exit_code: int = 0


class DockerRunner:
    def __init__(self, image='python:3.13-slim', timeout=10, output_limit=65536):
        if timeout <= 0 or output_limit <= 0:
            raise ValueError('Limits must be positive')
        self.image, self.timeout, self.output_limit = image, timeout, output_limit

    async def run(self, code):
        name = 'revsolver-' + uuid.uuid4().hex
        process = None
        tasks = []
        async def capture(pipe):
            output = bytearray()
            while chunk := await pipe.read(4096):
                output.extend(chunk)
                if len(output) > self.output_limit:
                    raise RuntimeError('Solver output limit exceeded')
            return output.decode('utf-8', errors='replace')
        try:
            process = await asyncio.create_subprocess_exec(
                'docker', 'run', '--rm', '--pull=never', '--name', name, '-i',
                '--network=none', '--read-only', '--cap-drop=ALL',
                '--security-opt=no-new-privileges', '--pids-limit=32',
                '--memory=128m', '--memory-swap=128m', '--cpus=0.5',
                '--user=65534:65534', '--log-driver=none',
                '--tmpfs=/tmp:rw,noexec,nosuid,size=16m',
                self.image, 'python', '-I', '-B', '-',
                stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE)
            async def feed():
                process.stdin.write(code.encode('utf-8'))
                try:
                    await process.stdin.drain()
                except (BrokenPipeError, ConnectionResetError):
                    pass
                finally:
                    process.stdin.close()
            tasks = [asyncio.create_task(capture(process.stdout)),
                     asyncio.create_task(capture(process.stderr)),
                     asyncio.create_task(feed()), asyncio.create_task(process.wait())]
            stdout, stderr, _, status = await asyncio.wait_for(
                asyncio.gather(*tasks), timeout=self.timeout)
            return Execution(stdout, stderr, status)
        finally:
            for task in tasks:
                if not task.done(): task.cancel()
            if process and process.returncode is None:
                process.kill()
                await process.wait()
            if tasks: await asyncio.gather(*tasks, return_exceptions=True)
            if process:
                # Killing the CLI does not necessarily stop its container.
                cleanup = await asyncio.create_subprocess_exec(
                    'docker', 'rm', '-f', name, stdout=asyncio.subprocess.DEVNULL,
                    stderr=asyncio.subprocess.DEVNULL)
                try:
                    await asyncio.wait_for(cleanup.wait(), timeout=5)
                except TimeoutError:
                    cleanup.kill()
                    await cleanup.wait()
