from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum


class ProblemType(str, Enum):
    KEY_VALIDATION = 'key_validation'
    CRYPTO_ENCODING = 'crypto_encoding'
    ALGORITHM = 'algorithm'
    UNKNOWN = 'unknown'


@dataclass
class ClassifyResult:
    problem_type: ProblemType = ProblemType.UNKNOWN
    confidence: float = 0.0
    strategy: str = ''
    key_functions: list[str] = field(default_factory=list)
    reasoning: str = ''


@dataclass
class SolveResult:
    success: bool = False
    flag: str = ''
    solver_type: str = ''
    solver_code: str = ''
    error: str = ''
    attempts: int = 0


@dataclass
class LLMConfig:
    provider: str = 'openai'
    model: str = 'gpt-4o'
    max_tokens: int = 4096
    temperature: float = 0.2


@dataclass
class LLMResponse:
    content: str
    model: str
    usage: dict


class LLMAdapter(ABC):
    def __init__(self, config):
        self.config = config

    @abstractmethod
    async def chat(self, messages): ...

    @abstractmethod
    async def stream(self, messages):
        yield ''
