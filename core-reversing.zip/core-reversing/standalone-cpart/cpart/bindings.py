"""Explicit integration: never silently mask a broken team installation."""
import os

if os.getenv('REVAGENT_TEAM_MODE') == '1':
    from src.llm.adapter import LLMAdapter, LLMConfig, LLMResponse
    from src.models.analysis_result import ClassifyResult, SolveResult, ProblemType
else:
    from .contracts import LLMAdapter, LLMConfig, LLMResponse
    from .contracts import ClassifyResult, SolveResult, ProblemType
