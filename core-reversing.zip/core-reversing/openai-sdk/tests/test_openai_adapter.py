"""SDK를 호출하지 않는 계약 테스트. 이벤트 루프/네트워크가 필요하지 않습니다.

모의 SDK의 즉시 완료 await만 직접 구동합니다. 실제 통신/스케줄링 테스트는 아닙니다.
"""
import asyncio
import sys
import unittest
from types import SimpleNamespace as NS
from unittest.mock import patch

from src.llm.adapter import LLMConfig, create_adapter
from src.llm.openai_adapter import OpenAIAdapter


def complete(coro):
    try:
        yielded = coro.send(None)
    except StopIteration as result:
        return result.value
    coro.close()
    raise AssertionError(f"Mock unexpectedly suspended: {yielded!r}")


def response(text="ok", reason="stop", refusal=None, usage=True):
    return NS(model="test-model", choices=[NS(finish_reason=reason,
              message=NS(content=text, refusal=refusal))],
              usage=NS(prompt_tokens=10, completion_tokens=2) if usage else None)


class FakeStream:
    def __init__(self, chunks): self.chunks, self.closed = iter(chunks), False
    def __aiter__(self): return self
    async def __anext__(self):
        try: return next(self.chunks)
        except StopIteration: raise StopAsyncIteration
    async def close(self): self.closed = True


class FakeClient:
    def __init__(self, result=None, error=None):
        self.result, self.error, self.calls, self.closed = result, error, [], False
        self.chat = NS(completions=NS(create=self.create))
    async def create(self, **kwargs):
        self.calls.append(kwargs)
        if self.error: raise self.error
        return self.result
    async def close(self): self.closed = True


def chunk(text=None, reason=None):
    return NS(choices=[NS(delta=NS(content=text, refusal=None), finish_reason=reason)])


class AdapterTests(unittest.TestCase):
    def test_chat_and_usage(self):
        client = FakeClient(response())
        adapter = OpenAIAdapter(LLMConfig(), client=client)
        result = complete(adapter.chat([{"role":"user", "content":"hi"}]))
        self.assertEqual(result.content, "ok")
        self.assertEqual(result.usage, {"input_tokens":10,"output_tokens":2})
        self.assertEqual(client.calls[0]["max_completion_tokens"], 8192)
        self.assertEqual(client.calls[0]["temperature"], 0.2)

    def test_reasoning_models_omit_temperature(self):
        for model in ("o1", "o1-2024-12-17", "o3", "o3-mini", "gpt-5"):
            client = FakeClient(response())
            adapter = OpenAIAdapter(LLMConfig(model=model), client=client)
            complete(adapter.chat([{"role":"user", "content":"hi"}]))
            self.assertNotIn("temperature", client.calls[0])
            self.assertNotIn("max_tokens", client.calls[0])

    def test_invalid_responses(self):
        for result in (response(""), response(reason="length"), response(refusal="no"),
                       NS(choices=[])):
            with self.assertRaises(ValueError):
                complete(OpenAIAdapter(LLMConfig(), client=FakeClient(result)).chat(
                    [{"role":"user", "content":"hi"}]))

    def test_missing_usage(self):
        result = complete(OpenAIAdapter(LLMConfig(), client=FakeClient(response(usage=False))).chat(
            [{"role":"user", "content":"hi"}]))
        self.assertEqual(result.usage, {"input_tokens":0,"output_tokens":0})

    def test_input_validation(self):
        client = FakeClient(response())
        for messages in ([], "hi", [{}], [{"role":"tool","content":"hi"}],
                         [{"role":"user","content":None}]):
            with self.assertRaises(ValueError):
                complete(OpenAIAdapter(LLMConfig(), client=client).chat(messages))
        self.assertFalse(client.calls)

    def test_configuration_validation(self):
        for config in (LLMConfig(provider="anthropic"), LLMConfig(model=""),
                       LLMConfig(max_tokens=0), LLMConfig(max_tokens=True),
                       LLMConfig(temperature=float("nan"))):
            with self.assertRaises(ValueError): OpenAIAdapter(config, client=FakeClient())

    def test_sdk_errors_and_cancellation_propagate(self):
        for error in (TimeoutError(), RuntimeError("api error"), asyncio.CancelledError()):
            with self.assertRaises(type(error)):
                complete(OpenAIAdapter(LLMConfig(), client=FakeClient(error=error)).chat(
                    [{"role":"user", "content":"hi"}]))

    def test_stream_and_cleanup(self):
        stream = FakeStream([NS(choices=[]), chunk("hel"), chunk("lo"), chunk(reason="stop")])
        adapter = OpenAIAdapter(LLMConfig(), client=FakeClient(stream))
        async def collect(): return [s async for s in adapter.stream([{"role":"user","content":"hi"}])]
        self.assertEqual(complete(collect()), ["hel", "lo"])
        self.assertTrue(stream.closed)

    def test_incomplete_stream_cleanup(self):
        stream = FakeStream([chunk("partial"), chunk(reason="length")])
        adapter = OpenAIAdapter(LLMConfig(), client=FakeClient(stream))
        async def collect(): return [s async for s in adapter.stream([{"role":"user","content":"hi"}])]
        with self.assertRaises(ValueError): complete(collect())
        self.assertTrue(stream.closed)

    def test_factory_and_owned_client_cleanup(self):
        client = FakeClient(response())
        with patch.dict(sys.modules, {"openai":NS(AsyncOpenAI=lambda **kw:client)}):
            adapter = create_adapter(LLMConfig())
            self.assertIsInstance(adapter, OpenAIAdapter)
            complete(adapter.close())
            self.assertTrue(client.closed)

    def test_borrowed_client_not_closed(self):
        client = FakeClient(response())
        complete(OpenAIAdapter(LLMConfig(), client=client).close())
        self.assertFalse(client.closed)


if __name__ == "__main__": unittest.main()
