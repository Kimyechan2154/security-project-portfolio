# Reversing Agent

AI-powered CTF Reversing Agent — 바이너리를 입력하면 자동 분석 + 풀이 전략 제시 + solver 생성

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
cp config/.env.example .env  # API 키 설정
```

## Usage

```bash
revagent analyze <binary_path>
```

## Branch 구조

| Branch | 담당 | 설명 |
|--------|------|------|
| `main` | 통합 | 안정 버전 |
| `feat/analysis-tools` | 역할 B | 분석 도구 래핑 |
| `feat/llm-solver` | 역할 C | LLM 연동 + Solver |

## License

MIT

