"""실제 API 호출 1회 확인: python -m scripts.check_openai --model gpt-4o"""
import argparse
import asyncio
import json
import os
import sys

from src.llm.adapter import LLMConfig, create_adapter


async def check(args):
    adapter = create_adapter(LLMConfig(provider="openai", model=args.model,
                                       max_tokens=args.max_tokens))
    async with adapter:
        # 실제 호출은 하나만 수행합니다. 성공 여부를 모의 응답으로 대체하지 않습니다.
        response = await asyncio.wait_for(adapter.chat([
            {"role": "user", "content": "Reply with exactly: adapter-ok"}
        ]), timeout=60)
    passed = response.content.strip() == "adapter-ok"
    print(json.dumps({"api_call_completed": True, "passed": passed,
                      "model": response.model, "reply": response.content,
                      "usage": response.usage}, ensure_ascii=False, indent=2))
    return 0 if passed else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", default="gpt-4o")
    parser.add_argument("--max-tokens", type=int, default=2048,
                        help="추론 토큰을 포함한 출력 한도")
    args = parser.parse_args()
    # 키 누락은 이벤트 루프/네트워크 생성 전에 확인합니다.
    if not os.getenv("OPENAI_API_KEY", "").strip():
        print("OPENAI_API_KEY 환경변수를 먼저 설정하세요.", file=sys.stderr)
        return 2
    try:
        return asyncio.run(check(args))
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        # SDK 예외 본문에는 요청 정보가 있을 수 있어 종류/상태만 출력합니다.
        print(f"API check failed: {type(exc).__name__}; "
              f"status={getattr(exc, 'status_code', 'n/a')}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
