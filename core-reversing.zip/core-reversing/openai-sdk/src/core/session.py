"""세션 관리 — 분석 세션의 상태 추적 및 결과 저장."""

import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

from src.core.workflow import PipelineResult


@dataclass
class SessionInfo:
    session_id: str = ""
    binary_path: str = ""
    start_time: float = 0.0
    end_time: float = 0.0
    status: str = "pending"  # pending | running | completed | failed

    @property
    def duration(self) -> float:
        if self.end_time > 0:
            return self.end_time - self.start_time
        return time.time() - self.start_time


class SessionManager:
    def __init__(self, output_dir: str = "output/"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self._current: Optional[SessionInfo] = None

    def start(self, binary_path: str) -> SessionInfo:
        session_id = f"session_{int(time.time())}"
        self._current = SessionInfo(
            session_id=session_id,
            binary_path=binary_path,
            start_time=time.time(),
            status="running",
        )
        return self._current

    def finish(self, result: PipelineResult) -> None:
        if self._current is None:
            return
        self._current.end_time = time.time()
        self._current.status = (
            "completed" if result.solve and result.solve.success else "failed"
        )
        self._save(result)

    @property
    def current(self) -> Optional[SessionInfo]:
        return self._current

    def _save(self, result: PipelineResult) -> None:
        if self._current is None:
            return

        session_dir = self.output_dir / self._current.session_id
        session_dir.mkdir(parents=True, exist_ok=True)

        # 세션 정보 저장
        info_path = session_dir / "session.json"
        with open(info_path, "w") as f:
            json.dump(asdict(self._current), f, indent=2, ensure_ascii=False)

        # 파이프라인 결과 요약 저장
        summary = {
            "binary": self._current.binary_path,
            "duration": f"{self._current.duration:.1f}s",
            "completed_stages": result.completed_stages,
            "error": result.error,
        }
        if result.classify:
            summary["problem_type"] = result.classify.problem_type.value
            summary["strategy"] = result.classify.strategy
        if result.solve:
            summary["flag"] = result.solve.flag
            summary["solver_type"] = result.solve.solver_type
            summary["attempts"] = result.solve.attempts

        summary_path = session_dir / "summary.json"
        with open(summary_path, "w") as f:
            json.dump(summary, f, indent=2, ensure_ascii=False)

