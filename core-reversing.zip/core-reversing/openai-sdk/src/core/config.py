"""설정 로드 — config.yaml + .env 환경변수 관리."""

from dataclasses import dataclass, field
from pathlib import Path

import yaml
from dotenv import load_dotenv


@dataclass
class LLMConfig:
    provider: str = "openai"
    model: str = "gpt-4o"
    max_tokens: int = 8192
    temperature: float = 0.2
    token_budget: int = 6000


@dataclass
class SolverConfig:
    max_retries: int = 3
    step_timeout: int = 300
    session_timeout: int = 900


@dataclass
class AppConfig:
    llm: LLMConfig = field(default_factory=LLMConfig)
    solver: SolverConfig = field(default_factory=SolverConfig)
    output_dir: str = "output/"


def load_config(config_path: str = "config/config.yaml") -> AppConfig:
    load_dotenv()

    path = Path(config_path)
    if not path.exists():
        return AppConfig()

    with open(path) as f:
        raw = yaml.safe_load(f) or {}

    llm_raw = raw.get("llm", {})
    solver_raw = raw.get("solver", {})

    return AppConfig(
        llm=LLMConfig(
            provider=llm_raw.get("provider", "openai"),
            model=llm_raw.get("model", "gpt-4o"),
            max_tokens=llm_raw.get("max_tokens", 8192),
            temperature=llm_raw.get("temperature", 0.2),
            token_budget=llm_raw.get("token_budget", 6000),
        ),
        solver=SolverConfig(
            max_retries=solver_raw.get("max_retries", 3),
            step_timeout=solver_raw.get("step_timeout", 300),
            session_timeout=solver_raw.get("session_timeout", 900),
        ),
        output_dir=raw.get("output", {}).get("dir", "output/"),
    )

