"""Agent 메인 루프 — 사용자 입력 → 파이프라인 실행 → 결과 출력."""

from pathlib import Path

from rich.console import Console
from rich.panel import Panel

from src.core.config import AppConfig, load_config
from src.core.session import SessionManager
from src.core.workflow import PipelineResult, Workflow

console = Console()


class Agent:
    def __init__(self, config: AppConfig | None = None):
        self.config = config or load_config()
        self.workflow = Workflow(self.config)
        self.session_mgr = SessionManager(self.config.output_dir)

    async def analyze(self, binary_path: str) -> PipelineResult:
        path = Path(binary_path)
        if not path.exists():
            console.print(f"[red]Error: {binary_path} not found[/]")
            return PipelineResult(error=f"File not found: {binary_path}")

        console.print(Panel(
            f"[bold]Target:[/] {path.name}\n"
            f"[bold]Size:[/] {path.stat().st_size:,} bytes\n"
            f"[bold]Provider:[/] {self.config.llm.provider} / {self.config.llm.model}",
            title="[bold cyan]Reversing Agent[/]",
        ))

        session = self.session_mgr.start(binary_path)
        console.print(f"Session: {session.session_id}\n")

        result = await self.workflow.run(binary_path)

        self.session_mgr.finish(result)
        self._print_summary(result)

        return result

    def _print_summary(self, result: PipelineResult) -> None:
        session = self.session_mgr.current
        duration = f"{session.duration:.1f}s" if session else "?"

        if result.solve and result.solve.success:
            console.print(Panel(
                f"[bold green]Flag:[/] {result.solve.flag}\n"
                f"[bold]Solver:[/] {result.solve.solver_type}\n"
                f"[bold]Attempts:[/] {result.solve.attempts}\n"
                f"[bold]Duration:[/] {duration}",
                title="[bold green]Success[/]",
            ))
        else:
            lines = [f"[bold]Stages completed:[/] {', '.join(result.completed_stages)}"]
            if result.classify:
                lines.append(
                    f"[bold]Problem type:[/] {result.classify.problem_type.value}"
                )
                lines.append(f"[bold]Strategy:[/] {result.classify.strategy}")
            if result.solve:
                lines.append(f"[bold]Attempts:[/] {result.solve.attempts}")
            lines.append(f"[bold]Error:[/] {result.error or result.solve.error if result.solve else result.error}")
            lines.append(f"[bold]Duration:[/] {duration}")

            console.print(Panel(
                "\n".join(lines),
                title="[bold red]Analysis Summary (Flag not found)[/]",
            ))

        if session:
            console.print(
                f"\nResults saved to: {self.config.output_dir}{session.session_id}/"
            )

