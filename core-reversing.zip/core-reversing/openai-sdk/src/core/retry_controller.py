"""재시도 관리 — Solve 단계의 무한 반복 방지 및 비용 통제."""

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Coroutine


@dataclass
class AttemptRecord:
    """각 시도의 기록."""
    attempt: int
    success: bool
    error: str = ""
    duration: float = 0.0
    result: Any = None


@dataclass
class RetryResult:
    """재시도 전체 결과."""
    success: bool
    final_result: Any = None
    attempts: list[AttemptRecord] = field(default_factory=list)
    total_duration: float = 0.0

    @property
    def num_attempts(self) -> int:
        return len(self.attempts)

    @property
    def errors(self) -> list[str]:
        return [a.error for a in self.attempts if a.error]


class RetryController:
    def __init__(
        self,
        max_retries: int = 3,
        step_timeout: float = 300.0,
        session_timeout: float = 900.0,
    ):
        self.max_retries = max_retries
        self.step_timeout = step_timeout
        self.session_timeout = session_timeout
        self._session_start: float | None = None

    async def execute(
        self,
        func: Callable[..., Coroutine],
        *args: Any,
        on_failure: Callable[[str], Coroutine] | None = None,
        **kwargs: Any,
    ) -> RetryResult:
        """func를 최대 max_retries회까지 재시도. 실패 시 on_failure로 전략 재조정 가능."""
        self._session_start = time.monotonic()
        attempts: list[AttemptRecord] = []

        for attempt_num in range(1, self.max_retries + 1):
            if self._session_expired():
                break

            start = time.monotonic()
            try:
                result = await asyncio.wait_for(
                    func(*args, **kwargs),
                    timeout=self.step_timeout,
                )
                duration = time.monotonic() - start
                attempts.append(AttemptRecord(
                    attempt=attempt_num, success=True,
                    duration=duration, result=result,
                ))
                return RetryResult(
                    success=True, final_result=result,
                    attempts=attempts,
                    total_duration=time.monotonic() - self._session_start,
                )
            except asyncio.TimeoutError:
                duration = time.monotonic() - start
                error = f"Timeout after {self.step_timeout}s"
                attempts.append(AttemptRecord(
                    attempt=attempt_num, success=False,
                    error=error, duration=duration,
                ))
            except Exception as e:
                duration = time.monotonic() - start
                error = str(e)
                attempts.append(AttemptRecord(
                    attempt=attempt_num, success=False,
                    error=error, duration=duration,
                ))

            # 실패 시 on_failure 콜백 호출 (전략 재조정)
            if on_failure and attempt_num < self.max_retries:
                try:
                    await on_failure(attempts[-1].error)
                except Exception:
                    pass

        return RetryResult(
            success=False, attempts=attempts,
            total_duration=time.monotonic() - self._session_start,
        )

    def _session_expired(self) -> bool:
        if self._session_start is None:
            return False
        return (time.monotonic() - self._session_start) >= self.session_timeout

