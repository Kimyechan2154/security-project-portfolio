"""파이프라인 오케스트레이션 — Triage → Classify → Solve → Verify."""

from dataclasses import dataclass
from enum import Enum
from typing import Optional

from rich.console import Console

from src.core.config import AppConfig
from src.core.retry_controller import RetryController
from src.core.token_budget import TokenBudgetManager
from src.models.analysis_result import (
    AnalysisResult,
    ClassifyResult,
    ProblemType,
    SolveResult,
)

console = Console()


class Stage(str, Enum):
    TRIAGE = "triage"
    DISASM = "disasm"
    CLASSIFY = "classify"
    SOLVE = "solve"
    VERIFY = "verify"


@dataclass
class PipelineResult:
    """파이프라인 전체 실행 결과."""
    analysis: Optional[AnalysisResult] = None
    classify: Optional[ClassifyResult] = None
    solve: Optional[SolveResult] = None
    completed_stages: list[str] = None
    error: str = ""

    def __post_init__(self):
        if self.completed_stages is None:
            self.completed_stages = []


class Workflow:
    """CTF 풀이 파이프라인 오케스트레이터."""

    def __init__(self, config: AppConfig):
        self.config = config
        self.token_budget = TokenBudgetManager(config.llm.token_budget)
        self.retry = RetryController(
            max_retries=config.solver.max_retries,
            step_timeout=config.solver.step_timeout,
            session_timeout=config.solver.session_timeout,
        )
        self._analysis_tools = None  # B팀 모듈 — 주입
        self._llm_adapter = None     # C팀 모듈 — 주입
        self._classifier = None      # C팀 모듈 — 주입
        self._solvers = None         # C팀 모듈 — 주입

    def set_analysis_tools(self, tools) -> None:
        self._analysis_tools = tools

    def set_llm_adapter(self, adapter) -> None:
        self._llm_adapter = adapter

    def set_classifier(self, classifier) -> None:
        self._classifier = classifier

    def set_solvers(self, solvers: dict) -> None:
        self._solvers = solvers

    async def run(self, binary_path: str) -> PipelineResult:
        """전체 파이프라인 실행."""
        result = PipelineResult()

        # 1. Triage + Disasm (분석 도구 실행)
        console.print(f"\n[bold cyan][ Stage 1: Triage ][/]")
        analysis = await self._run_triage(binary_path)
        if analysis is None:
            result.error = "Triage failed — no analysis tools available"
            return result
        result.analysis = analysis
        result.completed_stages.append(Stage.TRIAGE)
        self._print_triage_summary(analysis)

        # 2. Classify (LLM 분류)
        console.print(f"\n[bold cyan][ Stage 2: Classify ][/]")
        filtered = self.token_budget.filter(analysis)
        console.print(
            f"  Tokens: ~{filtered.estimated_tokens}/{self.config.llm.token_budget}"
        )

        classify_result = await self._run_classify(filtered)
        if classify_result is None:
            result.error = "Classification failed"
            return result
        result.classify = classify_result
        result.completed_stages.append(Stage.CLASSIFY)
        self._print_classify_summary(classify_result)

        # 3. Solve (사용자 확인 후)
        console.print(f"\n[bold cyan][ Stage 3: Solve ][/]")
        console.print(f"  Strategy: {classify_result.strategy}")

        solve_result = await self._run_solve(analysis, classify_result)
        result.solve = solve_result
        result.completed_stages.append(Stage.SOLVE)

        # 4. Verify
        if solve_result.success:
            console.print(
                f"\n[bold green][ FLAG FOUND ][/] {solve_result.flag}"
            )
            result.completed_stages.append(Stage.VERIFY)
        else:
            console.print(
                f"\n[bold red][ SOLVE FAILED ][/] "
                f"Attempts: {solve_result.attempts}, Error: {solve_result.error}"
            )

        return result

    async def _run_triage(self, binary_path: str) -> Optional[AnalysisResult]:
        if self._analysis_tools is None:
            console.print("  [yellow]No analysis tools registered[/]")
            return None
        return await self._analysis_tools.analyze(binary_path)

    async def _run_classify(self, filtered) -> Optional[ClassifyResult]:
        if self._classifier is None:
            console.print("  [yellow]No classifier registered[/]")
            return None
        try:
            return await self._classifier.classify(filtered)
        except Exception as e:
            console.print(f"  [red]Classify error: {e}[/]")
            return None

    async def _run_solve(
        self, analysis: AnalysisResult, classify: ClassifyResult
    ) -> SolveResult:
        if self._solvers is None:
            return SolveResult(error="No solvers registered")

        solver = self._solvers.get(classify.problem_type)
        if solver is None:
            return SolveResult(
                error=f"No solver for type: {classify.problem_type}"
            )

        errors_so_far: list[str] = []

        async def attempt():
            return await solver.solve(analysis, classify, errors_so_far)

        async def on_failure(error: str):
            errors_so_far.append(error)
            console.print(f"  [yellow]Retry — previous error: {error}[/]")

        retry_result = await self.retry.execute(
            attempt, on_failure=on_failure
        )

        if retry_result.success:
            return retry_result.final_result
        return SolveResult(
            success=False,
            attempts=retry_result.num_attempts,
            error="; ".join(retry_result.errors),
        )

    def _print_triage_summary(self, analysis: AnalysisResult) -> None:
        t = analysis.triage
        console.print(f"  Type: {t.file_type}")
        console.print(f"  Arch: {t.arch} ({t.bits}-bit)")
        console.print(f"  Packed: {'Yes — ' + t.packer if t.is_packed else 'No'}")
        console.print(
            f"  Tools: {len(analysis.available_tools)} ok, "
            f"{len(analysis.skipped_tools)} skipped"
        )
        console.print(f"  Strings: {len(analysis.strings)} found")
        console.print(f"  Functions: {len(analysis.disassembly)} disassembled")

    def _print_classify_summary(self, classify: ClassifyResult) -> None:
        console.print(f"  Type: {classify.problem_type.value}")
        console.print(f"  Confidence: {classify.confidence:.0%}")
        console.print(f"  Key functions: {', '.join(classify.key_functions)}")
        console.print(f"  Reasoning: {classify.reasoning}")

