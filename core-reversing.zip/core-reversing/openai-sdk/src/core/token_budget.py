"""토큰 예산 관리 — AnalysisResult를 LLM 토큰 한도 내로 필터링."""

from dataclasses import dataclass, field
from typing import Optional

from src.models.analysis_result import AnalysisResult


# 함수 우선순위 키워드
PRIORITY_KEYWORDS = [
    "main", "flag", "key", "check", "verify", "validate",
    "encrypt", "decrypt", "encode", "decode", "password",
    "secret", "compare", "auth",
]


@dataclass
class FilteredResult:
    """토큰 예산 내로 필터링된 분석 결과."""
    triage_summary: str = ""
    strings: list[str] = field(default_factory=list)
    disassembly: dict[str, str] = field(default_factory=dict)
    function_summary: list[str] = field(default_factory=list)
    dynamic_summary: str = ""
    tool_status: dict[str, str] = field(default_factory=dict)
    estimated_tokens: int = 0


class TokenBudgetManager:
    def __init__(self, max_tokens: int = 6000):
        self.max_tokens = max_tokens

    def filter(self, result: AnalysisResult) -> FilteredResult:
        filtered = FilteredResult(tool_status=result.tool_status)
        budget = self.max_tokens

        # 1. Triage 요약 (항상 포함, 비용 낮음)
        filtered.triage_summary = self._format_triage(result)
        budget -= self._estimate_tokens(filtered.triage_summary)

        # 2. 우선순위 높은 함수의 디스어셈블리
        priority_funcs, other_funcs = self._split_functions(result.disassembly)
        for fname, asm in priority_funcs.items():
            tokens = self._estimate_tokens(asm)
            if budget - tokens < 500:  # 나머지 항목용 여유
                break
            filtered.disassembly[fname] = asm
            budget -= tokens

        # 3. 나머지 함수는 시그니처만
        filtered.function_summary = [
            f for f in other_funcs.keys()
            if f not in filtered.disassembly
        ]
        budget -= self._estimate_tokens("\n".join(filtered.function_summary))

        # 4. 문자열 (flag 관련 우선)
        filtered.strings = self._filter_strings(result.strings, budget // 3)
        budget -= self._estimate_tokens("\n".join(filtered.strings))

        # 5. 동적 분석 요약
        if result.dynamic.ltrace or result.dynamic.stdout:
            filtered.dynamic_summary = self._format_dynamic(result, budget // 2)
            budget -= self._estimate_tokens(filtered.dynamic_summary)

        filtered.estimated_tokens = self.max_tokens - budget
        return filtered

    def _split_functions(
        self, disasm: dict[str, str]
    ) -> tuple[dict[str, str], dict[str, str]]:
        priority = {}
        other = {}
        for fname, asm in disasm.items():
            if any(kw in fname.lower() for kw in PRIORITY_KEYWORDS):
                priority[fname] = asm
            else:
                other[fname] = asm
        return priority, other

    def _filter_strings(self, strings: list[str], token_budget: int) -> list[str]:
        flag_keywords = ["flag", "ctf", "key", "pass", "secret", "correct", "wrong"]
        priority = []
        rest = []
        for s in strings:
            if any(kw in s.lower() for kw in flag_keywords):
                priority.append(s)
            elif len(s) > 3:
                rest.append(s)

        result = priority[:]
        tokens_used = self._estimate_tokens("\n".join(result))
        for s in rest:
            t = self._estimate_tokens(s)
            if tokens_used + t > token_budget:
                break
            result.append(s)
            tokens_used += t
        return result

    def _format_triage(self, result: AnalysisResult) -> str:
        t = result.triage
        lines = [
            f"File: {t.file_type}",
            f"Arch: {t.arch} ({t.bits}-bit, {t.endian})",
            f"Packed: {t.is_packed} ({t.packer})" if t.is_packed else "Packed: No",
            f"Protections: {t.protections}",
            f"Imports: {', '.join(result.imports[:20])}",
            f"Tools OK: {', '.join(result.available_tools)}",
            f"Tools Skipped: {', '.join(result.skipped_tools)}",
        ]
        return "\n".join(lines)

    def _format_dynamic(self, result: AnalysisResult, token_budget: int) -> str:
        lines = []
        if result.dynamic.stdout:
            lines.append(f"stdout: {result.dynamic.stdout[:200]}")
        if result.dynamic.ltrace:
            ltrace_lines = result.dynamic.ltrace[:30]
            lines.append("ltrace:\n" + "\n".join(ltrace_lines))
        summary = "\n".join(lines)
        max_chars = token_budget * 4
        return summary[:max_chars]

    @staticmethod
    def _estimate_tokens(text: str) -> int:
        return len(text) // 4 + 1

