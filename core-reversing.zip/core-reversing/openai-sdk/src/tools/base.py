"""도구 기본 클래스 — 모든 분석 도구가 상속. graceful skip 포함."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
import shutil
import subprocess
from typing import Any

from src.models.analysis_result import ToolResult, ToolStatus


class BaseTool(ABC):
    """분석 도구 기본 클래스. 하위 클래스는 name과 run()만 구현하면 됨."""

    name: str = "base"

    def execute(self, binary_path: str) -> ToolResult:
        """graceful skip 래퍼. 도구 실패/미설치 시 파이프라인 중단 없이 skip."""
        try:
            data = self.run(binary_path)
            return ToolResult(tool_name=self.name, status=ToolStatus.OK, data=data)
        except FileNotFoundError:
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.SKIPPED,
                reason=f"{self.name} not installed",
            )
        except subprocess.TimeoutExpired:
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.ERROR,
                reason=f"{self.name} timed out",
            )
        except Exception as e:
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.ERROR,
                reason=str(e),
            )

    @abstractmethod
    def run(self, binary_path: str) -> dict[str, Any]:
        """실제 도구 실행. 하위 클래스에서 구현.

        Returns:
            도구 실행 결과 딕셔너리. 키/값은 도구마다 다름.

        Raises:
            FileNotFoundError: CLI 도구가 설치되지 않은 경우
            subprocess.TimeoutExpired: 실행 시간 초과
            Exception: 기타 실행 오류
        """
        ...

    def is_available(self) -> bool:
        """CLI 도구 설치 여부 확인."""
        return shutil.which(self.name) is not None

    @staticmethod
    def run_command(
        cmd: list[str],
        timeout: int = 10,
        input_data: str | None = None,
    ) -> subprocess.CompletedProcess:
        """subprocess 실행 헬퍼. 모든 CLI 도구가 공통으로 사용."""
        return subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            input=input_data,
        )


class ToolRunner:
    """등록된 도구들을 순차 실행하고 결과를 수집."""

    def __init__(self, tools: list[BaseTool] | None = None):
        self.tools: list[BaseTool] = tools or []

    def register(self, tool: BaseTool) -> None:
        self.tools.append(tool)

    def run_all(self, binary_path: str) -> list[ToolResult]:
        results = []
        for tool in self.tools:
            result = tool.execute(binary_path)
            results.append(result)
        return results

    def get_status_dict(self, results: list[ToolResult]) -> dict[str, str]:
        return {r.tool_name: r.status.value for r in results}

