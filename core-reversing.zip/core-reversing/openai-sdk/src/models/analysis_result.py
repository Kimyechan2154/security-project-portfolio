"""분석 결과 데이터 모델 — 전체 파이프라인의 공통 인터페이스."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class ToolStatus(str, Enum):
    OK = "ok"
    SKIPPED = "skipped"
    ERROR = "error"


@dataclass
class ToolResult:
    """개별 도구 실행 결과."""
    tool_name: str
    status: ToolStatus
    data: dict[str, Any] = field(default_factory=dict)
    reason: str = ""


@dataclass
class TriageResult:
    """Triage 단계 결과 (file, checksec, entropy 등)."""
    file_type: str = ""
    arch: str = ""
    bits: int = 0
    endian: str = ""
    protections: dict[str, bool] = field(default_factory=dict)
    is_packed: bool = False
    packer: str = ""
    entropy: dict[str, float] = field(default_factory=dict)


@dataclass
class DynamicResult:
    """동적 분석 결과 (실행 캡처, ltrace, strace)."""
    stdout: str = ""
    stderr: str = ""
    exit_code: Optional[int] = None
    ltrace: list[str] = field(default_factory=list)
    strace: list[str] = field(default_factory=list)


class ProblemType(str, Enum):
    KEY_VALIDATION = "key_validation"
    CRYPTO_ENCODING = "crypto_encoding"
    ALGORITHM = "algorithm"
    UNKNOWN = "unknown"


@dataclass
class ClassifyResult:
    """LLM 분류 결과."""
    problem_type: ProblemType = ProblemType.UNKNOWN
    confidence: float = 0.0
    strategy: str = ""
    key_functions: list[str] = field(default_factory=list)
    reasoning: str = ""


@dataclass
class SolveResult:
    """Solver 실행 결과."""
    success: bool = False
    flag: str = ""
    solver_type: str = ""
    solver_code: str = ""
    error: str = ""
    attempts: int = 0


@dataclass
class AnalysisResult:
    """전체 분석 결과 — 파이프라인의 핵심 데이터 객체."""
    binary_path: str = ""
    triage: TriageResult = field(default_factory=TriageResult)
    strings: list[str] = field(default_factory=list)
    disassembly: dict[str, str] = field(default_factory=dict)
    imports: list[str] = field(default_factory=list)
    exports: list[str] = field(default_factory=list)
    dynamic: DynamicResult = field(default_factory=DynamicResult)
    tool_results: list[ToolResult] = field(default_factory=list)
    tool_status: dict[str, str] = field(default_factory=dict)

    @property
    def available_tools(self) -> list[str]:
        return [name for name, status in self.tool_status.items() if status == "ok"]

    @property
    def skipped_tools(self) -> list[str]:
        return [name for name, status in self.tool_status.items() if status != "ok"]

