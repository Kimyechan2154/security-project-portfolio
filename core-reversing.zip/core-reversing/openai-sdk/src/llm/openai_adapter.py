"""OpenAI SDK 어댑터. 키는 OPENAI_API_KEY 환경변수로 전달."""

import math
from typing import AsyncIterator

from src.llm.adapter import LLMAdapter, LLMConfig, LLMResponse


class OpenAIAdapter(LLMAdapter):
    def __init__(self, config: LLMConfig, *, client=None):
        super().__init__(config)
        if config.provider != "openai":
            raise ValueError("OpenAIAdapter requires provider='openai'")
        if not isinstance(config.model, str) or not config.model.strip():
            raise ValueError("model must be a non-empty string")
        if type(config.max_tokens) is not int or config.max_tokens <= 0:
            raise ValueError("max_tokens must be a positive integer")
        if (isinstance(config.temperature, bool) or
                not isinstance(config.temperature, (float, int)) or
                not math.isfinite(config.temperature) or not 0 <= config.temperature <= 2):
            raise ValueError("temperature must be between 0 and 2")
        self._owns_client = client is None
        if client is None:
            from openai import AsyncOpenAI
            # SDK가 환경변수를 읽습니다. 오류 본문/키는 이 모듈에서 출력하지 않습니다.
            client = AsyncOpenAI(timeout=30.0, max_retries=0)
        self._client = client

    def _request(self, messages: list[dict]) -> dict:
        if not isinstance(messages, list) or not messages:
            raise ValueError("messages must be a non-empty list")
        copied = []
        for message in messages:
            if (not isinstance(message, dict) or
                    message.get("role") not in {"system", "user", "assistant"} or
                    not isinstance(message.get("content"), str)):
                raise ValueError("Each message needs a supported role and string content")
            copied.append({"role": message["role"], "content": message["content"]})
        request = dict(model=self.config.model, messages=copied,
                       max_completion_tokens=self.config.max_tokens)
        # o1/o3 및 날짜가 붙은 모델 ID에서는 temperature를 보내지 않습니다.
        # 새 모델도 기본은 생략하고 GPT-4o 계열에만 명시적으로 적용합니다.
        if self.config.model == "gpt-4o" or self.config.model.startswith("gpt-4o-"):
            request["temperature"] = self.config.temperature
        return request

    async def chat(self, messages: list[dict]) -> LLMResponse:
        response = await self._client.chat.completions.create(**self._request(messages))
        if not response.choices:
            raise ValueError("OpenAI returned no choices")
        choice = response.choices[0]
        if getattr(choice.message, "refusal", None):
            raise ValueError("OpenAI refused this request")
        if choice.finish_reason != "stop":
            raise ValueError(f"Incomplete completion: {choice.finish_reason}")
        content = choice.message.content
        if not isinstance(content, str) or not content.strip():
            raise ValueError("OpenAI returned empty text")
        usage = response.usage
        return LLMResponse(
            content=content, model=response.model,
            usage={"input_tokens": usage.prompt_tokens if usage else 0,
                   "output_tokens": usage.completion_tokens if usage else 0},
        )

    async def stream(self, messages: list[dict]) -> AsyncIterator[str]:
        stream = await self._client.chat.completions.create(
            **self._request(messages), stream=True)
        finish_reason = None
        has_text = False
        try:
            async for chunk in stream:
                if not chunk.choices:
                    continue
                choice = chunk.choices[0]
                if getattr(choice.delta, "refusal", None):
                    raise ValueError("OpenAI refused this request")
                content = choice.delta.content
                if content:
                    has_text = has_text or bool(content.strip())
                    yield content
                if choice.finish_reason is not None:
                    finish_reason = choice.finish_reason
            if finish_reason != "stop" or not has_text:
                raise ValueError(f"Incomplete stream: {finish_reason}")
        finally:
            await stream.close()

    async def close(self) -> None:
        """자체 생성한 SDK 연결만 닫습니다. 주입한 client는 호출자가 관리합니다."""
        if self._owns_client:
            await self._client.close()

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, traceback):
        await self.close()
