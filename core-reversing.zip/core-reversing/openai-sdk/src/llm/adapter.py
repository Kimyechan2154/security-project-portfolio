"""LLM 추상 인터페이스 — 모든 provider가 상속. 모델 독립 레이어."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import AsyncIterator


@dataclass
class LLMResponse:
    """LLM 응답 결과."""
    content: str
    model: str
    usage: dict  # {"input_tokens": N, "output_tokens": N}


@dataclass
class LLMConfig:
    """LLM 설정. config.yaml에서 로드."""
    provider: str = "openai"       # openai | anthropic
    model: str = "gpt-4o"
    max_tokens: int = 8192
    temperature: float = 0.2


class LLMAdapter(ABC):
    """LLM provider 추상 인터페이스. 하위 클래스는 chat()과 stream()을 구현.

    사용 예시:
        adapter = create_adapter(LLMConfig(provider="openai", model="gpt-4o"))
        response = await adapter.chat([
            {"role": "system", "content": "You are a CTF solver."},
            {"role": "user", "content": "Analyze this binary..."},
        ])
        print(response.content)
    """

    def __init__(self, config: LLMConfig):
        self.config = config

    @abstractmethod
    async def chat(self, messages: list[dict]) -> LLMResponse:
        """메시지 리스트를 받아 응답 반환.

        Args:
            messages: [{"role": "system"|"user"|"assistant", "content": "..."}]

        Returns:
            LLMResponse with content, model, usage
        """
        ...

    @abstractmethod
    async def stream(self, messages: list[dict]) -> AsyncIterator[str]:
        """스트리밍 응답. MVP에서는 선택적 — chat()만 구현해도 됨.

        Yields:
            응답 텍스트 청크
        """
        ...


def create_adapter(config: LLMConfig) -> LLMAdapter:
    """config의 provider에 따라 적절한 Adapter 반환.

    Raises:
        ValueError: 지원하지 않는 provider
        ImportError: provider SDK 미설치
    """
    if config.provider == "openai":
        from src.llm.openai_adapter import OpenAIAdapter
        return OpenAIAdapter(config)
    elif config.provider == "anthropic":
        from src.llm.anthropic_adapter import AnthropicAdapter
        return AnthropicAdapter(config)
    else:
        raise ValueError(
            f"Unsupported provider: {config.provider}. "
            f"Supported: openai, anthropic"
        )

