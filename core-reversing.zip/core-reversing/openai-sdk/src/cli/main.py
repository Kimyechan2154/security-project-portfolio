"""CLI 진입점 — typer + rich 기반."""

import asyncio
from pathlib import Path

import typer
from rich.console import Console

from src.core.agent import Agent
from src.core.config import load_config

app = typer.Typer(
    name="revagent",
    help="AI-powered CTF Reversing Agent",
    no_args_is_help=True,
)
console = Console()


@app.command()
def analyze(
    binary: Path = typer.Argument(..., help="분석할 바이너리 파일 경로"),
    config: Path = typer.Option(
        "config/config.yaml", "--config", "-c", help="설정 파일 경로"
    ),
    provider: str = typer.Option(
        None, "--provider", "-p", help="LLM provider (openai/anthropic)"
    ),
    model: str = typer.Option(None, "--model", "-m", help="LLM 모델명"),
):
    """바이너리를 분석하고 CTF flag를 찾습니다."""
    app_config = load_config(str(config))

    if provider:
        app_config.llm.provider = provider
    if model:
        app_config.llm.model = model

    agent = Agent(app_config)
    asyncio.run(agent.analyze(str(binary)))


@app.command()
def info(
    binary: Path = typer.Argument(..., help="바이너리 파일 경로"),
):
    """바이너리의 기본 정보만 출력합니다 (Triage only)."""
    if not binary.exists():
        console.print(f"[red]Error: {binary} not found[/]")
        raise typer.Exit(1)

    console.print(f"[bold]Target:[/] {binary.name}")
    console.print(f"[bold]Size:[/] {binary.stat().st_size:,} bytes")
    console.print("[yellow]Triage-only mode — not yet implemented[/]")


@app.command()
def version():
    """버전 정보를 출력합니다."""
    console.print("reversing-agent v0.1.0")


if __name__ == "__main__":
    app()

