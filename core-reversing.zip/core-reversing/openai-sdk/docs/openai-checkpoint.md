# C 첫 체크: OpenAI SDK 어댑터

Issue #14의 최소 1개 어댑터 구현입니다. Anthropic/Classifier/전용 Solver는 이 변경에 포함하지 않습니다.
기존 LLMAdapter를 상속하며 create_adapter(LLMConfig(provider="openai"))에서 자동 선택됩니다.
chat()은 LLMResponse(content, model, usage)를 반환하고 stream()은 실제 텍스트 청크를 전달합니다.
stream()을 끝까지 소비하기 전까지 일부 텍스트는 완성된 응답이 아닙니다.
GPT-4o는 temperature를 사용하고 o1/o3는 생략하며, max_completion_tokens를 사용합니다.
요청 타임아웃 30초, SDK 자동 재시도 0회입니다. 오류/취소는 호출자에게 전달합니다.

## 설치와 테스트

저장소 루트에서 실행합니다. Python 3.11 이상이 필요합니다.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
.\.venv\Scripts\python.exe -m unittest tests.test_openai_adapter -v
```

전체 분석 도구 설치 없이 첫 체크만 할 경우:

```powershell
python -m pip install "openai>=1.54.0"
python -m unittest tests.test_openai_adapter -v
```

## 실제 API 호출 (소액의 API 사용 비용 발생)

키를 채팅/소스/커밋에 붙이지 않습니다. PowerShell에서 화면에 표시되지 않게 입력합니다.

```powershell
$adapterKey = Read-Host "OpenAI API key" -AsSecureString
$env:OPENAI_API_KEY = [System.Net.NetworkCredential]::new('', $adapterKey).Password
python -m scripts.check_openai --model gpt-4o
Remove-Item Env:OPENAI_API_KEY
Remove-Variable adapterKey
```

가상환경을 쓴 경우 python 대신 .\.venv\Scripts\python.exe를 사용합니다.
스크립트는 OPENAI_API_KEY 환경변수만 읽습니다(.env 자동 로드 없음).
키가 없으면 호출하지 않고 종료 코드 2로 종료합니다.
실제 응답이 adapter-ok이고 passed=true, 종료 코드 0이면 호출 확인 완료입니다.
실패 시 오류 종류와 HTTP 상태만 출력합니다. 401은 인증, 429는 한도/잔액,
404는 모델 접근권한/모델 ID를 확인합니다. 모델 접근 가능 여부는 계정에 따라 다릅니다.

스크립트는 B팀 분석기 없이 독립적으로 실행합니다. 모델 비교는 --model o1 또는 --model o3로
개별 실행할 수 있습니다. 추론 모델에서 출력 한도가 부족하면 --max-tokens 값을 조정하세요.

## 완료 여부

- 코드: OpenAI SDK 어댑터, 기존 팩토리 연결, 스트리밍, 호출 확인 스크립트 포함.
- 로컬 검증: 모의 SDK 테스트. 실제 HTTP/계정 모델 접근을 증명하지 않습니다.
- 실제 API 데모: OPENAI_API_KEY가 설정되지 않아 미실시. 위 명령의 성공 결과가 추가로 필요합니다.
- #14 전체 완료 아님: Anthropic 어댑터는 후속 작업입니다.

설치 설정의 잘못된 setuptools backend를 setuptools.build_meta로 수정하고,
패키지 탐색 대상을 src/scripts로 명시했습니다. SDK 최소 버전도 요청 옵션에 맞춰 조정했습니다.

참고: https://github.com/openai/openai-python
